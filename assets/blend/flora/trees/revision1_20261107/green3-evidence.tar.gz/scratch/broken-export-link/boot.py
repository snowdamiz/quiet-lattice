import importlib.util, os, sys
from pathlib import Path
p=Path(__file__).parent/'packages/tools/blender/flora_trees/run.py'
s=importlib.util.spec_from_file_location('runner',p)
m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
m.BLENDER=str(Path(__file__).parent/'producer')
if os.environ.get('DENY_SIGNAL'):
 def deny(*args): raise PermissionError(1,'controlled killpg denial')
 m.os.killpg=deny
if os.environ.get('FIXED_ATTEMPT'):
 m.time.strftime=lambda *_:'20000101T000000'
 class Fixed: hex='aaaaaaaa'
 m.uuid.uuid4=lambda:Fixed()
sys.exit(m.main())
