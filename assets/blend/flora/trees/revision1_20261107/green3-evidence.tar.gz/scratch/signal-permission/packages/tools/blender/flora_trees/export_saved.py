import os,time
from pathlib import Path
r=Path(__file__).resolve().parents[4]
(r/'child.pid').write_text(str(os.getpid()))
print('child-ready',flush=True)
time.sleep(12)
