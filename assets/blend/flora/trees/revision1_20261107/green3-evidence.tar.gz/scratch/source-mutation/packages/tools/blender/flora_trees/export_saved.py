import sys
from pathlib import Path
root = Path(__file__).resolve().parents[4]
kind = sys.argv[-2]
src = root / "assets/blend/flora" / f"tree_{kind}_t04.blend"
dst = root / "packages/client/public/models/flora" / f"tree_{kind}_t04.glb"
dst.write_bytes(b"PUBLISHED-GLB")
src.write_bytes(b"MUTATED-SOURCE")
print("child-published", flush=True)
