import os,sys,time,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[4]
(r/'child.pid').write_text(str(os.getpid()))
dst=r/'packages/client/public/models/flora/tree_round_t04.glb'
src=r/'assets/blend/flora/tree_round_t04.blend'
print('child-ready',flush=True)
sys.exit(9)
