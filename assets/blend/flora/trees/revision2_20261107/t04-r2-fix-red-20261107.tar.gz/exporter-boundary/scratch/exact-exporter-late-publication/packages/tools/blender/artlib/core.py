import json,os,time
from pathlib import Path
from types import SimpleNamespace
def validate_path(rules,candidate,**kw):
 root=Path.cwd()
 (root/'child.pid').write_text(str(os.getpid()))
 (root/'validation-entered').write_text('ready')
 print('child-ready',flush=True)
 deadline=time.monotonic()+20
 while not (root/'release-publish').exists() and time.monotonic()<deadline: time.sleep(.02)
 if not (root/'release-publish').exists(): raise TimeoutError('review barrier')
 return SimpleNamespace(status='PASS')
def write_and_print(check,path): path.write_text(json.dumps({'status':check.status,'fixture':True})+'\n')
