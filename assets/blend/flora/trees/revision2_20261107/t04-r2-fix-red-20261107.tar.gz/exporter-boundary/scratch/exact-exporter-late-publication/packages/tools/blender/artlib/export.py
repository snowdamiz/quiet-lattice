from pathlib import Path
def main(family,args):
 r=Path.cwd()
 (r/'packages/client/public/models/flora/tree_round_t04.glb').write_bytes(b'LATE-EXACT-EXPORTER-GLB')
 return 0
