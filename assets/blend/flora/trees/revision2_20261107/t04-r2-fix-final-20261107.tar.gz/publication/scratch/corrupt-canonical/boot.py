import importlib.util, os, sys
from pathlib import Path
p=Path(__file__).parent/'packages/tools/blender/flora_trees/run.py'
s=importlib.util.spec_from_file_location('runner',p)
m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
m.BLENDER=str(Path(__file__).parent/'producer')
if os.environ.get('DENY_SIGNAL'):
 def deny(*args): raise PermissionError(1,'controlled killpg denial')
 m.os.killpg=deny
if os.environ.get('FIXED_ATTEMPT'):
 m.time.strftime=lambda *_:'20000101T000000'
 class Fixed: hex='aaaaaaaa'
 m.uuid.uuid4=lambda:Fixed()
if os.environ.get('FAIL_RECEIPT_FSYNC'):
 real_fsync=m.os.fsync
 def fail_fsync(fd):
  # Fail at the real receipt I/O boundary, after the JSON bytes were written.
  target=m.subprocess.check_output(['lsof','-a','-p',str(os.getpid()),'-d',str(fd),'-Fn'],text=True)
  if '.receipt.json.pending' in target: raise OSError(5,'controlled receipt fsync failure')
  return real_fsync(fd)
 m.os.fsync=fail_fsync

original_link=m.os.link
def publication_link(src,dst,*args,**kw):
 canonical=Path(dst).suffix=='.glb' and '/public/models/' in str(dst)
 case=os.environ.get('PUBLICATION_CASE')
 if canonical and case=='promotion-denied':raise PermissionError(13,'controlled canonical promotion denial')
 result=original_link(src,dst,*args,**kw)
 if canonical:
  if case=='signal-during-promotion':os.kill(os.getpid(),2)
  if case=='source-during-promotion':(m.ROOT/'assets/blend/flora/tree_round_t04.blend').write_bytes(b'CHANGED-SOURCE')
  if case=='corrupt-canonical':Path(dst).write_bytes(b'CORRUPTED-CANONICAL')
  if case=='private-changes-after-copy':(Path(src).parent/'producer/tree_round_t04.glb').write_bytes(b'CHANGED-PRIVATE-ONLY')
 return result
m.os.link=publication_link
original_unlink=Path.unlink
def publication_unlink(p,*args,**kw):
 if os.environ.get('PUBLICATION_CASE')=='receipt-postlink-unlink-fails' and p.name=='.receipt.json.pending':raise PermissionError(13,'controlled postlink unlink failure')
 return original_unlink(p,*args,**kw)
Path.unlink=publication_unlink
original_fsync=m.os.fsync
def publication_fsync(fd):
 if os.environ.get('PUBLICATION_CASE')=='promotion-copy-fsync-fails':
  found=m.subprocess.check_output(['lsof','-a','-p',str(os.getpid()),'-d',str(fd),'-Fn'],text=True,timeout=2)
  if 'supervisor-publication.glb' in found:raise OSError(5,'controlled publication-copy fsync failure')
 return original_fsync(fd)
m.os.fsync=publication_fsync

sys.exit(m.main())
