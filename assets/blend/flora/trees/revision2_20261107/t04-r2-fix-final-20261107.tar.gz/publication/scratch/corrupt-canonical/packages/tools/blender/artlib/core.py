import atexit,json,os,time
from pathlib import Path
from types import SimpleNamespace
root=Path.cwd(); case=os.environ['PUBLICATION_CASE']; output=None
def validate_path(rules,candidate,**kw):
 global output
 output=candidate
 assert candidate.parent.name=='producer'
 if case=='late-validation':
  (root/'barrier-entered').write_text('validation');print('child-ready',flush=True)
  until=time.monotonic()+20
  while not (root/'release-publish').exists() and time.monotonic()<until:time.sleep(.02)
  if not (root/'release-publish').exists():raise TimeoutError('validation barrier')
 return SimpleNamespace(status='FAIL' if case=='validation-failure' else 'PASS')
def write_and_print(check,path):
 path.write_text(json.dumps({'status':check.status,'fixture':True}))
 if case=='mutate-during-validation':output.write_bytes(b'CHANGED-DURING-VALIDATION')
 if case=='source-during-validation':(root/'assets/blend/flora/tree_round_t04.blend').write_bytes(b'CHANGED-SOURCE')
def adverse():
 if output is None:return
 private=output.parent; ready=private/'ready.json'
 if not ready.exists():return
 if case=='output-after-ready':output.write_bytes(b'CHANGED-AFTER-READY')
 if case=='report-after-ready':(private/'final-stock-validation.json').write_text('{"status":"FAIL"}')
 if case=='source-after-ready':(root/'assets/blend/flora/tree_round_t04.blend').write_bytes(b'CHANGED-SOURCE')
 if case=='missing-ready':ready.unlink()
 if case in ('wrong-source','wrong-attempt','wrong-kind'):
  value=json.loads(ready.read_text())
  if case=='wrong-source':value['source']['sha256']='0'*64
  elif case=='wrong-kind':value['kind']='cactus'
  else:value['attempt']=str(root/'other-attempt')
  ready.write_text(json.dumps(value))
 if case=='symlink-output':
  backing=private/'backing.glb';output.rename(backing);output.symlink_to(backing)
 if case=='hardlink-output':os.link(output,private/'another-link.glb')
atexit.register(adverse)
