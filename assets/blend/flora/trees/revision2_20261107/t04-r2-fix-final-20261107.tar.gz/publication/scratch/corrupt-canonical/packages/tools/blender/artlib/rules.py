def load(): return {}
