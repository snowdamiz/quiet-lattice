import json,os,tempfile,time
from pathlib import Path
def main(family,args):
 root=Path.cwd(); case=os.environ['PUBLICATION_CASE']
 (root/'child.pid').write_text(str(os.getpid()))
 output=Path(args[args.index('--out-dir')+1])
 private=output.parent
 assert output.is_relative_to(private) and private.name=='producer'
 temporary=Path(tempfile.gettempdir()).resolve()
 assert temporary==private/'tmp'
 (root/'stock-call.json').write_text(json.dumps({'argv':args,'output':str(output),'tmpdir':str(temporary)}))
 if case=='late-stock':
  (root/'barrier-entered').write_text('stock');print('child-ready',flush=True)
  until=time.monotonic()+20
  while not (root/'release-publish').exists() and time.monotonic()<until:time.sleep(.02)
  if not (root/'release-publish').exists():raise TimeoutError('stock barrier')
 if case=='stock-failure':return 7
 dst=output/'flora/tree_round_t04.glb';dst.parent.mkdir(parents=True);dst.write_bytes(b'VALIDATED-FIXTURE-GLB')
 return 0
