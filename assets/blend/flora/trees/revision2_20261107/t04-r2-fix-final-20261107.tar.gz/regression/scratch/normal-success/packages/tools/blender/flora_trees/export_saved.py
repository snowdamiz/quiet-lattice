import os,sys,time,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[4]
(r/'child.pid').write_text(str(os.getpid()))
dst=r/'packages/client/public/models/flora/tree_round_t04.glb'
src=r/'assets/blend/flora/tree_round_t04.blend'
print('child-ready',flush=True)
import atexit,hashlib,json
attempt=Path(sys.argv[-1]); private=attempt/'producer'; dst=private/'tree_round_t04.glb'
def binding(p):
 data=p.read_bytes()
 return {'path':str(p),'resolved_path':str(p.resolve()),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def ready():
 raw=private/'stock/flora/tree_round_t04.glb';raw.parent.mkdir(parents=True);raw.write_bytes(dst.read_bytes())
 report=private/'final-stock-validation.json';report.write_text('{"status":"PASS","fixture":true}')
 precision=private/'precision.json';precision.write_text('fixture')
 (private/'ready.json').write_text(json.dumps({'schema':1,'attempt':str(attempt.resolve()),'kind':'round','source':binding(src),'output':binding(dst),'validation':binding(report),'stock':binding(raw),'precision':binding(precision)}))
atexit.register(ready)
dst.write_bytes(b'NEW-GLB')
sys.exit(0)
