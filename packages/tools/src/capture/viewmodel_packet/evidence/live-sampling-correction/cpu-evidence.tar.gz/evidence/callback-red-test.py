"""Live browser-tree races through the real VM observer; native ports inert."""
import errno
import json
import os
from pathlib import Path
import shutil
import threading
import unittest
from unittest.mock import patch

import native
from test_revision import RevisionControls, scratch


class LiveUsageTests(unittest.TestCase):
    def adapter_race(self, where='profile', action='delete'):
        directory = []; triggered = []; errors = []
        start = threading.Event(); finished = threading.Event()
        original_mkdir, original_stat = Path.mkdir, os.stat
        def mkdir(path, *args, **kwargs):
            result = original_mkdir(path, *args, **kwargs)
            if path.name == 'playwright_chromiumdev_profile-inert':
                target = path if where == 'profile' else path.parent
                target = target / 'Default' / 'Shared Dictionary'
                original_mkdir(target, parents=True)
                (target/'live-entry.bin').write_bytes(b'cpu-live-payload')
                directory.append(target)
            return result
        def writer():
            try:
                if not start.wait(5): return
                leaf = directory[0]/'live-entry.bin'
                if action == 'delete': leaf.unlink()
                elif action == 'rename': leaf.rename(directory[0]/'renamed.bin')
                elif action == 'subtree': directory[0].rename(directory[0].with_name('Renamed Dictionary'))
                else: raise AssertionError(action)
            except BaseException as error: errors.append(error)
            finally: finished.set()
        def stat(path, *args, **kwargs):
            if str(path).endswith('live-entry.bin') and directory and not triggered:
                triggered.append(str(path)); start.set()
                if not finished.wait(2): raise AssertionError('Owned writer did not finish')
            return original_stat(path, *args, **kwargs)
        worker = threading.Thread(target=writer); worker.start()
        try:
            with patch.object(Path, 'mkdir', mkdir), patch.object(os, 'stat', stat):
                evidence, trace, error, _ = RevisionControls().adapter()
        finally:
            start.set(); worker.join(2)
        self.assertFalse(worker.is_alive()); self.assertEqual(errors, []); self.assertTrue(triggered)
        return evidence, trace, error

    def test_actual_callback_delete_and_rename_are_incomplete_not_work_failures(self):
        for where in ('profile', 'private'):
            for action in ('delete', 'rename', 'subtree'):
                with self.subTest(where=where, action=action):
                    evidence, trace, error = self.adapter_race(where, action)
                    self.assertEqual(evidence['wait'], 'completed')
                    self.assertIn('actual-require-browser-pass', trace)
                    self.assertIn('release unproved', str(error)) # Deliberately refused inert drain.
                    self.assertNotIn('callbackFailure', evidence)
                    self.assertTrue(evidence['usageSampling']['incomplete'])
                    self.assertEqual(trace[-1], 'mandatory-inert-drain')


if __name__ == '__main__': unittest.main()
