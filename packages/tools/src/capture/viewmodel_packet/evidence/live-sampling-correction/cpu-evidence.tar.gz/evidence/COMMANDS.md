# Exact CPU commands

Working directory: `/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8`. Every command used the finite 240-second `run.py` outer bound; test children have 15/20-second bounds. Python bytecode is disabled, Node compile cache disabled, BLAS/OMP one thread, scratch/TMP under this exclusive evidence root. No dependency writes or installs.

## effects-read

Exit 0; 0.08 s; log SHA256 `ffdab775e012ed309ec3cd0da8f44350e66a603997c2311c0f41416784fbc80b`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/effects-read.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## baseline

Exit 0; 12.111 s; log SHA256 `2496eeb1a4d5bd6e556aa1f10dc089797db6e14d174ebbf7fc2fc5eb3d52a7a9`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/audit.py",
    "before"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## callback-red

Exit 1; 0.191 s; log SHA256 `ace90edb5da7f0a15e8a8fe64dd7e33334955dc4c36221b17f5c095b9f66731e`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_live_usage.py",
    "-v"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## callback-green-v1

Exit 1; 0.374 s; log SHA256 `b707bc827c0e9de9e5eec845703ea28b3222e27481d5649526cc45d2cfa6b2c1`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_live_usage.py",
    "-v"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## callback-green-v3

Exit 0; 0.35 s; log SHA256 `277b72937e8c204785d415d66402fbff8ec9bb094b0f73152778ba2ac48e08eb`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_live_usage.py",
    "-v"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## live-controls-v1

Exit 0; 0.52 s; log SHA256 `ef464be52128c9aa523b5f6ea29c80cffca0d7bdf6f60f1d95ebea3f1ba4d456`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_live_usage.py",
    "-v"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## silent-red

Exit 1; 0.045 s; log SHA256 `127851b00353a522db77641fea2ea0656293553e08e1a881d956d617544d2f4d`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/silent-red.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## observer-regressions

Exit 0; 5.527 s; log SHA256 `705a4280cbfa258cc327a5e750b9b04652a56abbffc79691a6df116cd7c0e61c`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-c",
    "import sys,unittest;sys.path.insert(0,\"packages/tools/src/capture/viewmodel_packet\");r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames([\"test_live_usage\",\"test_revision\",\"test_native\",\"test_r2\",\"test_protocol\"]));sys.exit(not r.wasSuccessful())"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## silent-red-final

Exit 1; 0.144 s; log SHA256 `9dacfcc397ec34802a413468e2f65f18d5e1c8a371aa2913a52c58e6ab8a668a`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/silent-red.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## cache-phase

Exit 0; 0.367 s; log SHA256 `753650f1007bf04a33e2b04baf72465be4c2a660d5784c5d26a2f19abc9b90a4`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/cache-probe.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## final-observer-controls

Exit 0; 5.7 s; log SHA256 `ec918dd80fd218668eb5c810a46e079980603de41f472879c7905f2ee0910f0a`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-c",
    "import sys,unittest;sys.path.insert(0,\"packages/tools/src/capture/viewmodel_packet\");r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames([\"test_live_usage\",\"test_revision\",\"test_native\",\"test_r2\",\"test_protocol\"]));sys.exit(not r.wasSuccessful())"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## freeze

Exit 0; 8.672 s; log SHA256 `33d51511caa0b6036873ac834602b9dca3dc8668cd694ac6654553d5977123f6`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/freeze.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## static

Exit 0; 0.196 s; log SHA256 `a5896e373cd12e3ccbeb4a699468ce6e9739abea5d51d68e8cce9a71ad5615f6`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/static.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## auth-check

Exit 0; 6.374 s; log SHA256 `d5f4e2e42c7b31ffcfd72090ce3162db1dd3a3768fc6979ed6a4f55f9273a8a6`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/auth-check.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## partial-publication

Exit 0; 0.367 s; log SHA256 `58abd876cc7dc384c395029cbb4375057899770b2ed7e15312af4e5bc149f530`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/partial-probe.py"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

## preservation

Exit 0; 9.525 s; log SHA256 `2496eeb1a4d5bd6e556aa1f10dc089797db6e14d174ebbf7fc2fc5eb3d52a7a9`.

```json
{
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-live-sampling-qsu7czb1/audit.py",
    "after"
  ],
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-live-sampling-qsu7czb1/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-live-sampling-qsu7czb1/tmp"
  }
}
```

