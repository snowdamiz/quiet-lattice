import sys,json,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/P1-E07-T14-effects/packages/tools/src/capture/effects_packet');sys.path.insert(0,str(P));import evidence
p=Path('/private/tmp/egp-164a9dca1cd5400c8f734587e449adeb/result.json');result=evidence.capture_snapshot(p);v=result['value']
(E/'effects-decoded-result.json').write_text(json.dumps(v,indent=2)+'\n')
record={'reader':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (P/'evidence.py',P/'contract.py')},'envelopeSha256':result['sha256'],'keys':list(v),'errors':v.get('errors'),'parts':[{'path':str(x.get('path')),'sha256':x['sha256'],'bytes':x['bytes']} for x in result['parts']]};(E/'effects-read.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
