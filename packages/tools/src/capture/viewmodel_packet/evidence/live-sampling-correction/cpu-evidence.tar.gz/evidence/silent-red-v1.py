import sys,importlib.util,unittest,hashlib,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path.cwd()/'packages/tools/src/capture/viewmodel_packet';sys.path.insert(0,str(P))
file=E/'base/packages/tools/src/capture/viewmodel_packet/native.py';assert file.read_bytes()==subprocess.check_output(['git','show','032fe44cd6ebdbeb61c21a89014704f66b194950:'+str(file.relative_to(E/'base')))])
spec=importlib.util.spec_from_file_location('native',file);native=importlib.util.module_from_spec(spec);sys.modules['native']=native;spec.loader.exec_module(native)
suite=unittest.defaultTestLoader.loadTestsFromNames(['test_live_usage.LiveUsageTests.test_actual_callback_records_subtree_that_old_walk_silently_skips']);result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())
