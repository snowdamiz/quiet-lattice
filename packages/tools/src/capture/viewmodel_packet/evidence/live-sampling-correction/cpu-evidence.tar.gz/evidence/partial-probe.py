import os,sys,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P))
from test_protocol import repository
root,repo=repository();cache=root/'live-cache';temp=cache/'deps_temp_a4ff6522';temp.mkdir(parents=True);(temp/'module.js').write_text('CPU ONLY\n')
repo.ready['bindings']['generatedCaches']=[str(cache)];repo.ready_path.write_text(json.dumps(repo.ready));repo.grant(0)
argv=[sys.executable,'-B',str(E/'partial-child.py'),'--inert-cpu-fixture',str(root),'0','success'];child=subprocess.run(argv,capture_output=True,timeout=20,env={**os.environ,'VM_PACKET_UNDER_TEST':str(P)})
(E/'partial-child.stdout').write_bytes(child.stdout);(E/'partial-child.stderr').write_bytes(child.stderr)
(E/'partial-command.json').write_text(json.dumps({'argv':argv,'exit':child.returncode,'root':str(root)},indent=2)+'\n')
assert child.returncode==0,(child.stdout,child.stderr)
facts=json.loads((root/'cache-probe.json').read_text());(E/'partial-probe.json').write_text(json.dumps(facts,indent=2)+'\n')
assert facts['renamed'] and facts['actualCacheBytes']==9
print(json.dumps({'status':'PASS_NO_REACHING_LIVE_GENERATED_CACHE_READ','childExit':child.returncode,'cachePhases':sorted(set(e['phase'] for e in facts['cacheEvents'])),'sampleEvents':facts['sampleEvents'],'strictSizePhases':sorted(set(e['phase'] for e in facts['sizeEvents'])),'trace':facts['trace']}))

import boundary
from test_r2 import graph_decode
paths=repo.ready['paths']['review-thalune'];result,result_hash=boundary.json_snapshot(Path(paths['evidence'])/'result.json',20*boundary.MIB);consumed,consumed_hash=boundary.json_snapshot(paths['consumption'])
observed=graph_decode(result['observations']);sampling=observed['native']['usageSampling'];assert result['checksPassed'] and result['released'] and result['primaryFailure'] is None
assert sampling['last'] is sampling['incomplete'][0]
assert sampling['incomplete'][0]['losses'][0]['errno']==2
assert observed['unknownCycle']['self'] is observed['unknownCycle']
repo.previous.append({'unit':'review-thalune','callerExit':child.returncode,'resultSha256':result_hash,'consumptionSha256':consumed_hash})
spec,paths,grant=repo.grant(1);repo.admit(1,(spec,paths,grant))
assert not Path(paths['consumption']).exists()
record={'exit':child.returncode,'resultSha256':result_hash,'consumptionSha256':consumed_hash,'resultBytes':Path(repo.ready['paths']['review-thalune']['evidence'],'result.json').stat().st_size,'successorAdmittedWithoutDispatch':True,'partialCoverage':sampling['incomplete'][0]['coverage'],'rawLossFacts':boundary.raw(sampling['incomplete'][0]['losses']),'samplingLastAliasPreserved':True,'unknownCyclePreserved':True,'nativeLaunched':False}
(E/'partial-authenticated.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
