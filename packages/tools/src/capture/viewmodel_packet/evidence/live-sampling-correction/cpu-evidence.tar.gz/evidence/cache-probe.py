import os,sys,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P))
from test_protocol import repository
root,repo=repository();cache=root/'live-cache';temp=cache/'deps_temp_a4ff6522';temp.mkdir(parents=True);(temp/'module.js').write_text('CPU ONLY\n')
repo.ready['bindings']['generatedCaches']=[str(cache)];repo.ready_path.write_text(json.dumps(repo.ready));repo.grant(0)
argv=[sys.executable,'-B',str(E/'cache-child.py'),'--inert-cpu-fixture',str(root),'0','success'];child=subprocess.run(argv,capture_output=True,timeout=20,env={**os.environ,'VM_PACKET_UNDER_TEST':str(P)})
(E/'cache-child.stdout').write_bytes(child.stdout);(E/'cache-child.stderr').write_bytes(child.stderr)
(E/'cache-command.json').write_text(json.dumps({'argv':argv,'exit':child.returncode,'root':str(root)},indent=2)+'\n')
assert child.returncode==0,(child.stdout,child.stderr)
facts=json.loads((root/'cache-probe.json').read_text());(E/'cache-probe.json').write_text(json.dumps(facts,indent=2)+'\n')
assert facts['renamed'] and facts['actualCacheBytes']==9
print(json.dumps({'status':'PASS_NO_REACHING_LIVE_GENERATED_CACHE_READ','childExit':child.returncode,'cachePhases':sorted(set(e['phase'] for e in facts['cacheEvents'])),'sampleEvents':facts['sampleEvents'],'strictSizePhases':sorted(set(e['phase'] for e in facts['sizeEvents'])),'trace':facts['trace']}))
