import ast,hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path.cwd();P=R/'packages/tools/src/capture/viewmodel_packet'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
compiled={}
for f in P.glob('*.py'):compile(f.read_text(),str(f),'exec');compiled[f.name]=sha(f)
protected=json.loads((P/'evidence/capture-revision-r1/protected-audit.txt').read_text())
for name,h in protected['reports'].items():assert sha(name)==h,name
for name,h in protected['helpers'].items():assert sha(R/name)==h,name
base='032fe44cd6ebdbeb61c21a89014704f66b194950';base_files={}
for name in ('entry.mjs','fixture.mjs','boundary.py','bindings.py','inspect_packet.py','inventory.json','resolve.mjs','protocol_child.py','test_protocol.py'):
 old=subprocess.check_output(['git','show',base+':'+str((P/name).relative_to(R))]);assert old==(P/name).read_bytes();base_files[name]=sha(P/name)
ready=json.loads((P/'readiness.json').read_text());prior=json.loads((E/'base/packages/tools/src/capture/viewmodel_packet/readiness.json').read_text())
for key in ('sourceDigest','ignoredInventorySha256','trees','node','python','pythonKernel','tsxApi','playwright','esbuild','browserBinary','decoderPython','decoderSite'):assert ready['bindings'][key]==prior['bindings'][key],key
patch=subprocess.check_output(['git','diff','--full-index','--binary','38b6c4b58db43146df20cd760808d1461d7a667b^','38b6c4b58db43146df20cd760808d1461d7a667b']);adopt=subprocess.check_output(['git','diff','--full-index','--binary','dea07963^','dea07963']);assert patch==adopt
old_native=(E/'base/packages/tools/src/capture/viewmodel_packet/native.py').read_text();current=(P/'native.py').read_text();marker='        # Cleanup gets one finite phase';assert old_native[old_native.index(marker):]==current[current.index(marker):];old_tree=ast.parse(old_native);new_tree=ast.parse(current);old_size=next(n for n in old_tree.body if isinstance(n,ast.FunctionDef) and n.name=='size');new_size=next(n for n in new_tree.body if isinstance(n,ast.FunctionDef) and n.name=='size');assert ast.dump(old_size)==ast.dump(new_size)
record={'strictFinalSegmentSha256':hashlib.sha256(current[current.index(marker):].encode()).hexdigest(),'compiled':compiled,'unchangedTaskRuntimeAndProtocol':base_files,'protectedReports':protected['reports'],'helpers':protected['helpers'],'t15PatchSha256':hashlib.sha256(patch).hexdigest(),'shared':{n:sha(R/n) for n in ['packages/tools/src/capture/capture.ts','packages/tools/src/capture/capture.lifecycle.test.ts','packages/client/src/entities/Multitool.js']},'historicalProof':'R5 independent retained byte-for-byte; unchanged shared lifecycle100/client110/TS/static/PNG/timeline controls are historical, not fresh counts','base':base}
(E/'static-reuse.json').write_text(json.dumps(record,indent=2)+'\n');subprocess.run(['git','diff','--check'],check=True);print(json.dumps({'pythonSources':len(compiled),'unchangedRuntime':base_files,'t15':record['t15PatchSha256']}))
