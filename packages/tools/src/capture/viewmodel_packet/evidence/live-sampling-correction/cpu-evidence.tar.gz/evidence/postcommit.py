import gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path.cwd();P=R/'packages/tools/src/capture/viewmodel_packet';D=P/'evidence/live-sampling-correction';sys.path.insert(0,str(P));import caller
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
base='032fe44cd6ebdbeb61c21a89014704f66b194950';assert git('rev-parse','HEAD^')==base;assert git('status','--porcelain=v1','--untracked-files=all')==''
assert git('branch','--show-current')=='task/P1-E05-T03'
ready=json.loads((P/'readiness.json').read_text());f=json.loads((E/'freeze.json').read_text());assert sha(P/'readiness.json')==f['sha256']
for n,row in json.loads((E/'source-closure.json').read_text()).items():assert sha(P/n)==row['sha256'],n
argv=[sys.executable,'-B',str(P/'caller.py'),'--check',str(P/'readiness.json')];env={**os.environ,'PATH':ready['bindings']['path']}
p=subprocess.run(argv,env=env,capture_output=True,timeout=45);(E/'postcommit-check.stdout').write_bytes(p.stdout);(E/'postcommit-check.stderr').write_bytes(p.stderr);assert p.returncode==0,(p.returncode,p.stdout,p.stderr)
assert json.loads(p.stdout)=={'status':'ENABLED_AWAITING_PARENT_GRANT','runtimeEnabled':True,'entryEnabled':True,'allUnitsQualified':False,'nativeQualified':False}
for path in f['absent']:assert not Path(path).exists() and not Path(path).is_symlink(),path
index=json.loads((D/'archive-index.json').read_text());assert sha(D/index['archive']['name'])==index['archive']['sha256'];assert hashlib.sha256(gzip.decompress((D/index['manifest']).read_bytes())).hexdigest()==index['manifestSha256']
patch=subprocess.check_output(['git','diff','--binary','--full-index',base,'HEAD']);(E/'source.patch').write_bytes(patch)
protected=json.loads((P/'evidence/capture-revision-r1/protected-audit.txt').read_text())
record={'status':'ENABLED_SOURCE_CPU_CORRECTION_AWAITING_INDEPENDENT_REVIEW','base':base,'baseTree':git('rev-parse',base+'^{tree}'),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'branch':git('branch','--show-current'),'clean':True,'readinessSha256':sha(P/'readiness.json'),'inventorySha256':sha(P/'inventory.json'),'sourcePatchSha256':hashlib.sha256(patch).hexdigest(),'check':{'argv':argv,'env':{'PATH':env['PATH'],'PYTHONDONTWRITEBYTECODE':env.get('PYTHONDONTWRITEBYTECODE'),'NODE_DISABLE_COMPILE_CACHE':env.get('NODE_DISABLE_COMPILE_CACHE')},'exit':p.returncode,'stdoutSha256':sha(E/'postcommit-check.stdout'),'stderrSha256':sha(E/'postcommit-check.stderr')},'prospectiveAbsent':f['absent'],'protectedManifestSha256':sha(P/'evidence/capture-revision-r1/protected-audit.txt'),'protectedCounts':{k:len(v) for k,v in protected['groups'].items()},'assetHashes':{k:v for k,v in protected['groups'].items() if k in ('accepted_bodies','viewmodels')},'helpers':protected['helpers'],'sourceDigest':ready['bindings']['sourceDigest'],'ignoredInventorySha256':ready['bindings']['ignoredInventorySha256'],'dependencyTrees':ready['bindings']['trees'],'archive':index,'nativeJobs':0,'realGrantIssued':False,'originalUnit':'FAILED/SPENT: exit1, zero images; immutable parent/raw evidence retained'}
(E/'POST-COMMIT.json').write_text(json.dumps(record,indent=2)+'\n')
paths=ready['paths']['review-thalune'];spec=caller.plan()['units'][0]
launch={'kind':'DATA_ONLY_NOT_A_GRANT_OR_DISPATCH','requires':'Fresh independent source PASS, parent capacity/GPU slot decision and new one-use parent grant','sourceHead':record['head'],'sourceTree':record['tree'],'readinessSha256':record['readinessSha256'],'unit':spec,'cwd':str(R),'argv':[sys.executable,'-B',str(P/'caller.py'),'--ready',paths['ready'],'--unit','review-thalune','--grant',paths['grant']],'env':{'PATH':ready['bindings']['path'],'PYTHONDONTWRITEBYTECODE':'1','NODE_DISABLE_COMPILE_CACHE':'1'},'readinessCopy':{'source':str(P/'readiness.json'),'absentDestination':paths['ready'],'sha256':record['readinessSha256']},'paths':paths,'derivedTerminalPaths':[str(p) for p in caller.terminal_paths(paths)],'previous':[],'grantIssued':False,'allProspectivePathsAbsent':True,'originalAuthorizationReusable':False,'afterDispatch':'Parent observes actual OS exit before authenticating result/consumption; no automatic retry or later-unit dispatch.'}
(E/'unit1-launch.json').write_text(json.dumps(launch,indent=2)+'\n')
assert git('status','--porcelain=v1','--untracked-files=all')==''
print(json.dumps({k:record[k] for k in ('head','tree','clean','readinessSha256','sourcePatchSha256','nativeJobs','realGrantIssued')},indent=2))
