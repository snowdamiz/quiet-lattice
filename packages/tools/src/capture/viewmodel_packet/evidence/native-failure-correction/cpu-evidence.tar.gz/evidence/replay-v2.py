"""CPU reachable failure replay, not reconstruction of discarded native memory."""
import sys,os,json,subprocess,tempfile,contextlib,hashlib,runpy
from pathlib import Path
from unittest.mock import patch
E=Path(__file__).resolve().parent;R=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8');P=R/'packages/tools/src/capture/viewmodel_packet'; mode=sys.argv[1];SOURCE=E/'base-tree/packages/tools/src/capture/viewmodel_packet' if mode=='red' else P
sys.path.insert(0,str(SOURCE));import bindings;bindings.HELPERS=R/'assets/blend/stations/_authoring';sys.path.insert(0,str(bindings.HELPERS))
import caller,boundary,native
sys.path.insert(0,str(P));from test_boundary import Repo
import round4_job_boundary as jb,run_round4_browser_proof as proof,run_round4_remaining8 as stages
case=Path(tempfile.mkdtemp(prefix=mode+'-replay-',dir=E/'tmp')); frozen=json.loads((P/'readiness.json').read_text());caller.HERE=P
repo=Repo(case);repo.ready['bindings']={**frozen['bindings'],**repo.ready['bindings']};repo.ready_path.write_text(json.dumps(repo.ready));spec,paths,_=repo.grant(0)
original=Path('/private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus/review-thalune/job'); facts=json.loads((original/'boundary.json').read_text());observed=json.loads((original/'observed_execution.json').read_text());rows=list(facts['identities'].values());owned={r['pid']:r for r in rows};binaries={r['kernel']['pid']:r['binary'] for r in observed['processes']};mtl='/System/Library/Frameworks/Metal.framework/Versions/A/XPCServices/MTLCompilerService.xpc/Contents/MacOS/MTLCompilerService'
# Keep the exact old process binding even on GREEN: replay the original refusal.
repo.ready['bindings']['process_binary_sha256'].pop(mtl,None);repo.ready_path.write_text(json.dumps(repo.ready));spec,paths,_=repo.grant(0)
pid_count=len(Path('/private/tmp/space-vm-parent-unit1-r5-kghan_6a/process-admission.txt').read_text().splitlines())-1
# All parent PID rows include other users; this is an explicit upper-shaped control,
# not an assertion of the original per-user scan or its lost observation count.
unrelated=list(range(900000,900000+pid_count)); allpids=unrelated+list(owned);trace=[];captured=[];ports=(subprocess.run,subprocess.check_output,subprocess.Popen);temp=tempfile.mkdtemp

def start(job):
 trace.append('inert-start');job.root=facts['root'];job.coalition_id=facts['coalition_id'];private=Path(json.loads((job.scratch/'request.json').read_text())['env']['TMPDIR']);profile=private/'playwright_chromiumdev_profile-inert';profile.mkdir(mode=0o700)
 (job.scratch/'capture_stdout.txt').write_text(f'<launching> {frozen["bindings"]["browserBinary"]} --use-angle=metal --user-data-dir={profile}\n<launched> pid=54622\n')

def drain(job,*_):
 trace.append('mandatory-inert-drain')
 for _ in range(4):job.members()
 job.state.update(drained=False,clean=False);return job.state

def command(port):
 def call(argv,**kw):
  if argv[0]=='git':
   with patch.object(subprocess,'run',ports[0]),patch.object(subprocess,'check_output',ports[1]),patch.object(subprocess,'Popen',ports[2]):return port(argv,**kw)
  raise AssertionError('NO_NATIVE_COMMAND '+repr(argv))
 return call

def forbidden(*a,**kw):raise AssertionError('NO_NATIVE_PROCESS')
def mktemp(*a,**kw):kw['dir']=str(case);return temp(*a,**kw)
def runner(ready,spec,paths,record):
 captured.append(record)
 return caller.run_unit(ready,spec,paths,record,capture=native.capture,cache_copy=lambda r,e,rec:rec.update(initialCacheBytes=0),decoder=forbidden,final_verify=lambda _: {})
# Execute the actual CLI body; only admission filesystem pins and process ports inert.
actual_main=caller.main
with contextlib.ExitStack() as s:
 for owner,name,value in [(tempfile,'mkdtemp',mktemp),(jb.StationJob,'start',start),(jb.StationJob,'status',lambda job: {}),(jb.StationJob,'drain',drain),(jb,'user_pids',lambda:allpids),(stages,'current_commands',lambda rs:{r['pid']:binaries.get(r['pid'],frozen['bindings']['node']) for r in rs}),(stages,'executable_path',lambda pid:binaries.get(pid,mtl if pid==55005 else frozen['bindings']['node'])),(subprocess,'run',command(ports[0])),(subprocess,'check_output',command(ports[1])),(subprocess,'Popen',forbidden),(caller,'HERE',repo.packet)]:s.enter_context(patch.object(owner,name,value))
 for module in (jb,proof,stages):
  for name,value in [('identity',lambda pid:owned.get(pid)),('coalition',lambda pid:[facts['coalition_id'],42832] if pid in owned else [2,3]),('kernel_tasks',lambda _:{'live':0})]:
   if hasattr(module,name):s.enter_context(patch.object(module,name,value))
 try:code,result=actual_main(repo.ready_path,spec['id'],Path(paths['grant']),enabled=True,verifier=lambda _:{},runner=runner,emit=lambda b:sys.stderr.buffer.write(b))
 except BaseException as error:code=1;result={'durable':False,'record':captured[0]};print(type(error).__name__,str(error),file=sys.stderr)
record=result['record']; attempts=record.get('persistenceErrors',[]); encoding={}
for key,value in [('primaryFailure',record['primaryFailure']),('observations',{k:v for k,v in record.items() if k not in boundary.RESULT_FIELDS|boundary.FAILURE_FIELDS}),('whole',record)]:
 try:encoding[key]={'bytes':len(boundary.encoded(value))}
 except BaseException as error:encoding[key]={'error':str(error),'type':type(error).__name__}
summary={'mode':mode,'case':str(case),'exit':code,'durable':result['durable'],'parentAllPidCount':pid_count,'helperCalls':len(record['native']['helperCalls']),'helperObservationBytes':record['native']['helperObservationBytes'],'trace':trace,'primary':record['native']['primaryFailure'],'secondary':record['native']['secondaryFailures'],'persistenceErrors':attempts,'encoding':encoding,'resultExists':(Path(paths['evidence'])/'result.json').exists(),'fallbackExists':Path(paths['consumption']+'.fallback.json').exists()}
(E/(mode+'-measurement.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));sys.exit(code)
