import ast
import hashlib
import json
from pathlib import Path

out = Path(__file__).parent
source = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def function(text, name):
    return ast.get_source_segment(text, next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name))
old = (out / 'bindings.old.py').read_text()
new = (out / 'bindings.new.py').read_text()
assert function(old, 'apple_encoder_binding') == function(new, 'apple_encoder_binding')
assert (out / 'final-head.txt').read_text().strip() == '84d7098432de296b1db916849804c912d1558cd3'
assert (out / 'final-branch.txt').read_text().strip() == 'task/P1-E05-T03'
assert (out / 'red/exit.txt').read_text().strip() == '1'
assert (out / 'red/replay.exit.txt').read_text().strip() == '1'
assert (out / 'green-final/exit.txt').read_text().strip() == '0'
assert (out / 'green-final/replay.exit.txt').read_text().strip() == '0'
assert (out / 'diff-check.exit').read_text().strip() == '0'
assert (out / 'protection-after.exit').read_text().strip() == '0'
for name in ('bindings.py', 'test_encoder.py'):
    assert digest(source / name) == digest(out / name.replace('.py', '.new.py'))
red = json.loads((out / 'red/retained-replay.json').read_text())
green = json.loads((out / 'green-final/retained-replay.json').read_text())
assert red['sources'][str(source / 'bindings.py')] == digest(out / 'bindings.old.py')
assert green['sources'][str(source / 'bindings.py')] == digest(out / 'bindings.new.py')
assert green['sources'][str(source / 'test_encoder.py')] == digest(out / 'test_encoder.new.py')
assert green['python']['dont_write_bytecode'] is True and green['python']['version'].startswith('3.14.')
proof = json.loads((out / 'protection-after.json').read_text())
assert proof['unchanged'] and not proof['changes']
discoveries = [json.loads(p.read_text()) for p in sorted((out / 'green-final').glob('vm-mtl-*/discovery.json'))]
binding = discoveries[0]['appleMetalCompiler']
assert all(d['appleMetalCompiler'] == binding for d in discoveries)
(out / 'current-mtl-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
controls = []
for path in sorted((out / 'green-final').glob('vm-mtl-*/control.json')):
    row = json.loads(path.read_text())
    admitted = [r for r in row['receipt']['processes'] if r['admitted']]
    assert len(admitted) == (1 if row['mode'] == 'bound' else 0)
    controls.append({'path': str(path), 'mode': row['mode'], 'admitted': len(admitted), 'failure': row['failure']})
(out / 'observer-controls.json').write_text(json.dumps(controls, indent=2) + '\n')
original_test = (out / 'test_encoder.new.py').read_text().replace(
    "raise RuntimeError('No runtime or kernel process probe permitted')", "raise AssertionError('No runtime or kernel process probe permitted')").replace(
    "raise RuntimeError('No native command permitted')", "raise AssertionError('No native command permitted')").replace(
    "            if receipt is not None and any(row['admitted'] for row in receipt['processes']):\n                raise RuntimeError('Refused observation admitted a process') from error\n", '')
assert hashlib.sha256(original_test.encode()).hexdigest() == red['sources'][str(source / 'test_encoder.py')]
(out / 'test_encoder.red.py').write_text(original_test)
report = f'''MTLCompilerService narrow binding: CPU PASS; native attempt remains FAILED/SPENT

Workspace: {source.parents[4]}
Branch: task/P1-E05-T03
HEAD: 84d7098432de296b1db916849804c912d1558cd3
Uncommitted patch: {out / 'patch.diff'}
Only bindings.py and test_encoder.py changed. No commit, readiness update, new grant, runtime rerun,
cleanup, dependency installation, other worktree modification, or nested agent. Parent owns the separate
terminal receipt issue. This lane is finished; no more edits after handoff.

Retained actual run
- Original parent: /private/tmp/space-vm-parent-unit1-r5-kghan_6a
- Raw packet: /private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus/review-thalune
- Parent exit 1; release report accepted=false, outputFiles=[], callerResultPresent=false,
  callerFallbackPresent=false; helper drained=true, clean=false; terminal coalition absent/live=0.
- Spent consumption receipt was read, not regenerated or reused.
- Owned job root PID54608 UID501 birth [1794046925,254462], coalition 42831.
- PID54994: UID501 birth [1794046927,934671], coalition [42831,42832], ppid1 pgid54994.
  Executable: /System/Library/Frameworks/VideoToolbox.framework/Versions/A/XPCServices/VTEncoderXPCService.xpc/Contents/MacOS/VTEncoderXPCService
  Role apple-video-encoder-xpc; admitted=true; prelaunch_sha256
  a3af9d8f1d6423de4d6303c323f5132122181e01367155d325fc9bde3ed872b5.
- PID55005: UID501 birth [1794046928,112755], coalition [42831,42832], ppid1 pgid55005.
  Executable: /System/Library/Frameworks/Metal.framework/Versions/A/XPCServices/MTLCompilerService.xpc/Contents/MacOS/MTLCompilerService
  Role owned-launch-helper; admitted=false; no prelaunch hash retained for this process.
- boundary.json identities and observed_execution.json kernel/coalition records agree exactly.
  These are retained observations, not fresh observations of those PIDs. Parent prelaunch process
  listing has unrelated MTL instances; it is not evidence that PID54994 was MTL.
- Boundary error: AssertionError: Unbound owned executable: {binding['executable']['path']}

Current exact file (CPU codesign only)
- SHA256 {binding['executable']['sha256']}; bytes {binding['executable']['bytes']}.
- Identifier com.apple.MTLCompilerService; platform 26; CDHash {binding['signature']['CDHash']}.
- Requirement {binding['requirement']}.
- Strict verification exit0 and display exit0; canonical regular file plus all {len(binding['protectedRoute'])} route
  entries UID0 and not group/world writable. Device/inode/owner/mode rechecked; executable and
  codesign bytes rechecked after verification. Full argv/stdout/stderr/hash/protection in current-mtl-binding.json.
- This current file hash/signature does not retrospectively prove PID55005's bytes during the failed run.

Change
- Adds exactly this path, hardcoded SHA256/byte count, root-owner/nonwritable/canonical route checks,
  Apple designated signature/platform identity, and before/after checks following the existing VT model.
- discover() includes the file in readiness bindings, stores appleMetalCompiler evidence, and populates
  exactly one additional process_binary_sha256 entry. verify() still requires full discover() equality.
- Existing apple_encoder_binding source text is byte-identical. All four helper files remain unchanged.
  StageReceipts/StationJob ownership checks, unknown-executable refusal, role classification and
  Storemember rules are untouched. No Apple namespace or other service path is admitted.

RED and GREEN
- red/: exact HEAD bindings bytes plus the new matching regression. Actual StageReceipts.observe()
  failed at run_round4_remaining8.py:334 with Unbound owned executable; exit1. No prerequisite failure.
- red/replay.*: same unchanged bindings, exact retained PID55005 UID/birth/coalition facts injected
  through actual StationJob.members and StageReceipts.observe; same intended failure, exit1.
- green-final/: all 8 tests pass (3 existing VT tests + 5 MTL tests), exit0. Retained-identity replay
  passes, exit0, preserving the original retained admitted=false record separately from CPU output.
- Tested refusals: binding hash/size, root owner, parent owner, file/parent writability, symlink route,
  failed signature, wrong identifier/platform/designated requirement; StageReceipts missing binding,
  wrong UID/birth/coalition, wrong executable despite MTL command text, birth/coalition race;
  actual StationJob.members PID reuse; nonmember never admitted. All rejection control receipts
  have zero admitted rows. Matching row retains role owned-launch-helper.
- Initial green/ also passed. Tests were then hardened so forbidden process launches raise RuntimeError
  rather than matching expected ownership AssertionError, and reject any admission on a failed observation.
  green-final/ proves that final test source. test_encoder.red.py reconstructs only those guard changes
  and was verified against the SHA256 recorded at the original RED; no production code changed between greens.

Proof limits
- CPU tests inject kernel/process observations and isolate unrelated discovery (resolver, trees, source
  inventory and self-kernel probe); they do not validate fresh runtime discovery or produce new readiness.
  Real Apple files and /usr/bin/codesign are used. No compiler/encoder/browser service was launched.
- Wrong hash is rejected by the binding/discovery boundary BEFORE StageReceipts. The unchanged generic
  StageReceipts path does not rehash arbitrary owned services on every observation; it trusts the frozen
  process map, as it did for VTEncoder. Tests do not claim malformed caller maps are rejected by that helper.
- No new native/browser/GPU/codec/Blender/service/server/DB/grant/cleanup/install run. No Node process needed.
  Tests ran serially, at most one small Python3.14 -B test process in this lane (codesign subprocesses only).
- Original unit stays FAILED/SPENT, zero images. No claim of native success, complete process observation,
  external XPC ownership, publication readiness, or resolution of the parent's terminal receipt issue.

Protection and provenance
- protection-before/after.json: {len(proof['inventory'])} entries unchanged, including retained parent/raw packet
  directory/file identity, modes, owners, mtimes and file SHA256; exact spent grant/consumption/readiness
  files and four helpers unchanged. Directory/file access times are intentionally not claimed.
- git diff --check exit0. The saved final-git-status.txt snapshot immediately after lane tests listed
  only the two owned source paths. A later handoff-git-status.txt also shows concurrent parent edits
  to boundary.py and caller.py; this lane did not edit those files. The CPU results precede those parent
  edits and do not qualify the combined parent patch. Assets/runtime/shared helpers/history had no
  tracked changes at these observations; no exhaustive hashing of all shared dependencies is claimed.
- Source snapshots, exact hashes, commands/exits and failure tails are retained here. Commands in commands.txt.

Source SHA256
{(out / 'source-sha256.txt').read_text()}
RED test SHA256: {red['sources'][str(source / 'test_encoder.py')]}
Python: {green['python']}
'''
(out / 'REPORT.txt').write_text(report)
print(json.dumps({'report': str(out / 'REPORT.txt'), 'protected_entries': len(proof['inventory']),
                  'observer_controls': len(controls), 'route_entries': len(binding['protectedRoute']),
                  'source_hashes_match': True, 'existing_encoder_unchanged': True}))
