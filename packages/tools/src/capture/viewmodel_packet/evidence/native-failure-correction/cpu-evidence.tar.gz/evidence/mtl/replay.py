"""CPU replay of retained facts, never a fresh native process observation."""
import hashlib
import json
import os
from pathlib import Path
import sys

SOURCE = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet')
sys.path.insert(0, str(SOURCE))
import test_encoder

out = Path(os.environ['VM_REVISION_TMP'])
raw = Path('/private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus/review-thalune/job')
boundary = json.loads((raw / 'boundary.json').read_text())
observed = json.loads((raw / 'observed_execution.json').read_text())
records = {r['kernel']['pid']: r for r in observed['processes'] if r['kernel']['pid'] in (54994, 55005)}
proof = {'scope': 'Retained native facts plus CPU replay with injected observations; no live PID query',
         'python': {'executable': sys.executable, 'version': sys.version, 'dont_write_bytecode': sys.dont_write_bytecode},
         'sources': {str(SOURCE / n): hashlib.sha256((SOURCE / n).read_bytes()).hexdigest()
                     for n in ('bindings.py', 'test_encoder.py')},
         'raw': {str(raw / n): hashlib.sha256((raw / n).read_bytes()).hexdigest()
                 for n in ('boundary.json', 'observed_execution.json')},
         'root': boundary['root'], 'coalition_id': boundary['coalition_id'], 'identities': {}}
for pid, record in records.items():
    identity = boundary['identities'][str(pid)]
    assert all(record['kernel'][k] == identity[k] for k in record['kernel'])
    assert identity['coalition'] == record['coalition']
    assert identity['uid'] == boundary['root']['uid'] == 501
    assert identity['coalition'][0] == boundary['coalition_id'] == 42831
    proof['identities'][str(pid)] = {'boundary': identity, 'observer': record}
assert records[54994]['binary'] == test_encoder.bindings.VT_ENCODER
assert records[54994]['admitted'] is True
assert records[55005]['binary'] == test_encoder.MetalCompilerTests.binary
assert records[55005]['admitted'] is False
test = test_encoder.MetalCompilerTests()
try:
    discovered = test.discover_cpu()
    proof['replay'] = test.observe_cpu(discovered, retained=boundary['identities']['55005'])
    assert proof['replay']['processes'][0]['admitted'] is True
except BaseException as error:
    proof['failure'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    (out / 'retained-replay.json').write_text(json.dumps(proof, indent=2) + '\n')
print('PASS retained PID55005 CPU replay; PID54994 retained VTEncoder identity separately verified')
