import hashlib
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
OUT = Path(__file__).parent
paths = [Path('/private/tmp/space-vm-parent-unit1-r5-kghan_6a'),
         Path('/private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus/review-thalune'),
         Path('/private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus-readiness.json'),
         Path('/private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus-review-thalune.grant.json'),
         Path('/private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus-review-thalune.consumed.json'),
         ROOT / 'packages/tools/src/capture/viewmodel_packet/readiness.json']
paths += [ROOT / 'assets/blend/stations/_authoring' / name for name in
          ('round4_job_boundary.py', 'round4_capture_children.py', 'run_round4_browser_proof.py', 'run_round4_remaining8.py')]

def inventory():
    result = {}
    for root in paths:
        for p in [root, *sorted(root.rglob('*'))] if root.is_dir() else [root]:
            st = p.lstat()
            row = dict(device=st.st_dev, inode=st.st_ino, uid=st.st_uid, mode=stat.S_IMODE(st.st_mode),
                       mtime_ns=st.st_mtime_ns, size=st.st_size)
            if p.is_symlink():
                row['link'] = os.readlink(p)
            elif p.is_file():
                row['sha256'] = hashlib.sha256(p.read_bytes()).hexdigest()
            result[str(p)] = row
    return result

current = inventory()
if sys.argv[1] == 'before':
    with (OUT / 'protection-before.json').open('x') as f:
        json.dump(current, f, indent=2)
else:
    old = json.loads((OUT / 'protection-before.json').read_text())
    changes = [p for p in old.keys() | current.keys() if old.get(p) != current.get(p)]
    with (OUT / 'protection-after.json').open('w') as f:
        json.dump(dict(unchanged=not changes, changes=changes, inventory=current), f, indent=2)
    assert not changes, changes
print(json.dumps(dict(mode=sys.argv[1], entries=len(current), unchanged=sys.argv[1] != 'before')))
