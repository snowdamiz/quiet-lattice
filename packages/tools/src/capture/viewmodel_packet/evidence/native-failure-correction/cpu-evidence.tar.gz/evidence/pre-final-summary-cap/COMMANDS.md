# Exact CPU commands

```json
{
  "name": "before",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/audit.py",
    "before"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 9.214325040986296,
  "logSha256": "637040a719b78e54f87e2ac17f9de3ded650c0a1952af9f851b7534b5b815e4f",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "replay-red",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/replay.py",
    "red"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 1,
  "seconds": 0.08618887496413663,
  "logSha256": "178ed363553d09d6c7fe6a0a804757225331eba72d4f6c46bd1547781481c6f3",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "replay-red-v2",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/replay.py",
    "red"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 1,
  "seconds": 1.533970040967688,
  "logSha256": "4ab4eee58d930c9872d767e1da23748df45015ee695cfe33c121cdb783e9503c",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "replay-red-alias",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/replay.py",
    "red"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 1,
  "seconds": 2.0548472920199856,
  "logSha256": "4e0b5c08ad002f68f40971b8706b72b3cc14d8f2862c65af2c3a57d8fb212601",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "replay-red-cli",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/replay.py",
    "red"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 1,
  "seconds": 2.036886041983962,
  "logSha256": "3a7383aa1db88e5fb890f4b38c5a2c5b4a823138ae85dfbeab07b78f6b07161f",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "replay-green-cli",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/replay.py",
    "green"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 1,
  "seconds": 1.646609666000586,
  "logSha256": "7ebbdf797b7ec793de8a53e2da21993a142edbceac87e85c3817570729b2109e",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "publication-v1",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_publication.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 4.098368083010428,
  "logSha256": "462bd5167cf43beda128d4fa8d20ddf45872b0d59fdffd546f2e7e4cacc53ccf",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "focused-v1",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_p*.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 8.725048708030954,
  "logSha256": "b7638d54e85df8dcf115ea023197f3332d15e3b685834f825445ffe1292903c4",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "boundary-regressions",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_boundary.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 4.291697832988575,
  "logSha256": "c4e7709f5cb0a944ecd316e40e9c2e8cf98c6bd08b1ef8ebc95d6a08bb774717",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "cyclic-regressions",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_r2.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 0.40546920895576477,
  "logSha256": "8dd0838a17872bce7bb67e3e39f4b688c3a6b34e64c95a5f88eedf5bdf001878",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "publication-final",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_publication.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 4.36125312501099,
  "logSha256": "43b09ff6e47b07899751fd33ea05502a244bcce43d972ef401a35273efeb8674",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "metal-combined",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_encoder.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 0.44731487496756017,
  "logSha256": "8a86c8893bc10113b63262e8f48f9b6f63740981ae7b4320043e3e9a71c27329",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "publication-final-v2",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_publication.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 5.3020635829889216,
  "logSha256": "87cdf2c701652132b7b82d4752391c7618e5babb710bef654fc07c8ff47942d8",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "replay-green-final",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/replay.py",
    "green"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 1,
  "seconds": 1.3813902089605108,
  "logSha256": "3b485cd91a8e4a98bb802abd93faf26b2db9b652dfa1935e2b17a9a87fac83f8",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "freeze",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/freeze.py"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 9.071127542003524,
  "logSha256": "212717de10e0e5cf09c11818ea47ef62cace127748494fa09e5aa06d28b23135",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "static",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/static.py"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 0.1415536659769714,
  "logSha256": "77e41c78f97cf2cd3a3b7d5776feea1922512350724e7772edcd2634824065bb",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "protocol-final",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "-m",
    "unittest",
    "discover",
    "-s",
    "packages/tools/src/capture/viewmodel_packet",
    "-p",
    "test_protocol.py",
    "-v"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 4.9809904580470175,
  "logSha256": "233b6b6f1affdf016f626d8eb58b99231ec0a6557054d22e7ac79c30688599f4",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "auth-check",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/auth-check.py"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 1,
  "seconds": 0.1372640829649754,
  "logSha256": "576470379f47248febccde1dc9b85340c98508c8b4b339ddbd4fa3cc27b3c1fa",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "auth-check-final",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/auth-check.py"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 9.915680082980543,
  "logSha256": "d5f4e2e42c7b31ffcfd72090ce3162db1dd3a3768fc6979ed6a4f55f9273a8a6",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "preservation",
  "argv": [
    "/opt/homebrew/opt/python@3.14/bin/python3.14",
    "-B",
    "/private/tmp/vm-native-fix-ydkbvouf/audit.py",
    "after"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 10.461029959027655,
  "logSha256": "637040a719b78e54f87e2ac17f9de3ded650c0a1952af9f851b7534b5b815e4f",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "format",
  "argv": [
    "/Users/andreyyurlov/.local/share/fnm/node-versions/v26.12.1/installation/bin/node",
    "node_modules/.pnpm/prettier@3.9.10/node_modules/prettier/bin/prettier.cjs",
    "--write",
    "packages/tools/src/capture/viewmodel_packet/README.md",
    "packages/tools/src/capture/viewmodel_packet/NATIVE-FAILURE-CORRECTION.md"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 0.08094991702819243,
  "logSha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "format-explicit",
  "argv": [
    "/Users/andreyyurlov/.local/share/fnm/node-versions/v26.12.1/installation/bin/node",
    "node_modules/.pnpm/prettier@3.9.10/node_modules/prettier/bin/prettier.cjs",
    "--ignore-path",
    "/dev/null",
    "--write",
    "packages/tools/src/capture/viewmodel_packet/README.md",
    "packages/tools/src/capture/viewmodel_packet/NATIVE-FAILURE-CORRECTION.md"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 0.1365713330451399,
  "logSha256": "f74ecdd81f250e3f8a18db3685e4999416499550aed7453ead5f8249e90f1e41",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

```json
{
  "name": "format-check",
  "argv": [
    "/Users/andreyyurlov/.local/share/fnm/node-versions/v26.12.1/installation/bin/node",
    "node_modules/.pnpm/prettier@3.9.10/node_modules/prettier/bin/prettier.cjs",
    "--ignore-path",
    "/dev/null",
    "--check",
    "packages/tools/src/capture/viewmodel_packet/README.md",
    "packages/tools/src/capture/viewmodel_packet/NATIVE-FAILURE-CORRECTION.md"
  ],
  "cwd": "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8",
  "exit": 0,
  "seconds": 0.137782082951162,
  "logSha256": "17aa973d3f004560237d9a95171210b0671deff23d61628eecf7322ff5938f20",
  "env": {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/private/tmp/vm-native-fix-ydkbvouf/tmp",
    "NODE_DISABLE_COMPILE_CACHE": "1",
    "VM_REVISION_TMP": "/private/tmp/vm-native-fix-ydkbvouf/tmp"
  }
}
```

