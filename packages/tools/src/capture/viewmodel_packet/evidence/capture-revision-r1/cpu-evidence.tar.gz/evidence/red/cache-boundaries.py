import json,sys,os,time,subprocess,tempfile,hashlib,contextlib
from pathlib import Path
from unittest.mock import patch
E=Path(__file__).resolve().parent;R=Path('/private/tmp/vmrev-hrgu6g4e/original');P=R/'packages/tools/src/capture/viewmodel_packet';sys.path.insert(0,str(P))
import caller,boundary,bindings
results=[]
root=Path(tempfile.mkdtemp(prefix='cache-',dir=E)); cache=root/'cache';cache.mkdir();f=cache/'leaf';f.write_bytes(b'x');evidence=root/'e';evidence.mkdir();record={'ledger':[]}
real_tree=bindings.tree_binding; real_fdopen=os.fdopen; reads=[]; changed=[]
class Stream:
 def __init__(self,stream):self.s=stream
 def __enter__(self):return self
 def __exit__(self,*a):self.s.close()
 def read(self,n):
  value=self.s.read(n);reads.append({'asked':n,'returned':len(value)});return value
 def __getattr__(self,k):return getattr(self.s,k)
def grow(path,**kw):
 if Path(path)==cache and not changed:
  with f.open('wb') as s:s.truncate(64*boundary.MIB+1)
  changed.append(True)
 return real_tree(path,**kw)
with patch.object(bindings,'tree_binding',grow),patch.object(os,'fdopen',lambda *a,**kw:Stream(real_fdopen(*a,**kw))):
 try:caller.snapshot_caches({'bindings':{'generatedCaches':[str(cache)]}},evidence,record);raise AssertionError('accepted')
 except ValueError as error:failure=boundary.raw(error)
assert sum(r['returned'] for r in reads)==64*boundary.MIB+1
assert record['ledger'][0]['attemptedBytes']==0
results.append({'case':'growth-before-first-hash','root':str(root),'payloadReadBytes':sum(r['returned'] for r in reads),'reads':reads,'error':failure,'record':record,'timerAfter':__import__('signal').getitimer(__import__('signal').ITIMER_REAL)})
# FIFO at the same first content-open boundary stays nonblocking and closes.
root=Path(tempfile.mkdtemp(prefix='cache-',dir=E));cache=root/'cache';cache.mkdir();f=cache/'leaf';f.write_bytes(b'x');ev=root/'e';ev.mkdir();real_open=os.open;fds=[]
def swap(path,flags,*a,**kw):
 if Path(path)==f and not fds:
  f.rename(f.with_suffix('.original'));os.mkfifo(f)
  fd=real_open(path,flags,*a,**kw);fds.append(fd);return fd
 return real_open(path,flags,*a,**kw)
with patch.object(os,'open',swap),boundary.deadline(.5):
 try:caller.snapshot_caches({'bindings':{'generatedCaches':[str(cache)]}},ev,{'ledger':[]});raise AssertionError('accepted')
 except ValueError as error:failure=boundary.raw(error)
assert len(fds)==1
try:os.fstat(fds[0]);raise AssertionError('descriptor leaked')
except OSError:pass
results.append({'case':'cache-FIFO-preopen','error':failure,'descriptorClosed':True})
# Real harmless owner retains open descriptor; actual cache owner probe refuses it.
root=Path(tempfile.mkdtemp(prefix='owner-',dir=E));cache=root/'cache';cache.mkdir();f=cache/'leaf';f.write_text('owned')
child=subprocess.Popen([sys.executable,'-B','-c','import sys;f=open(sys.argv[1],"r+b");print("READY",flush=True);sys.stdin.read(1)',str(f)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
assert child.stdout.readline().strip()=='READY'
try:
 with patch.object(bindings,'ROOT',root),patch.object(bindings,'HERE',root/'packet'),patch.object(bindings,'CACHES',[cache]),patch.object(bindings,'discover',return_value={'syntheticBindingOnly':True}):
  try:bindings.verify({'bindings':{'syntheticBindingOnly':True}});raise AssertionError('live owner accepted')
  except ValueError as error:failure=boundary.raw(error)
 assert child.poll() is None
finally:
 child.stdin.write('x');child.stdin.flush();out,err=child.communicate(timeout=5)
assert child.returncode==0
results.append({'case':'competing-real-owner','pid':child.pid,'refusal':failure,'exit':child.returncode,'root':str(root)})
(E/'cache-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'cases':3,'growthReadBeforeBudget':results[0]['payloadReadBytes'],'fifo':'REFUSED','liveOwner':'REFUSED','childExit':child.returncode}))
