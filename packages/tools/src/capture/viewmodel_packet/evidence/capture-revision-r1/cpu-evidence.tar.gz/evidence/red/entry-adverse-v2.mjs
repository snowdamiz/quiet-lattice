import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {registerHooks,stripTypeScriptTypes,syncBuiltinESMExports} from 'node:module';
import {pathToFileURL} from 'node:url';
import cp from 'node:child_process';
const root='/private/tmp/vmrev-hrgu6g4e/original', packet=root+'/packages/tools/src/capture/viewmodel_packet';
const E=fs.realpathSync('/private/tmp/vmrev-hrgu6g4e/red'), ready=JSON.parse(fs.readFileSync(packet+'/readiness.json'));
const plan=JSON.parse(fs.readFileSync(packet+'/inventory.json'));
for (const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) cp[name]=()=>{throw new Error('NO_CHILD_PROCESS:'+name)};
syncBuiltinESMExports();
const primary=new Error('PRIMARY_PAGE_GOTO');primary.partial=Buffer.from([0,255]);primary.unknown={original:true};
const secondary=new Error('SECONDARY_BROWSER_CLOSE');
const trace=[];let cleanupFails=false;
const page={on:()=>{},addInitScript:async()=>{},goto:async()=>{trace.push('actual-openReview-goto');throw primary;},evaluate:async()=>{throw new Error('UNEXPECTED evaluate')}};
const browser={newPage:async()=>page,close:async()=>{trace.push('browser.close');if(cleanupFails)throw secondary;}};
globalThis.__inertChrome={launch:async()=>{trace.push('inert-launch-port');return browser;}};
globalThis.__inertVite={listen:async()=>{},close:async()=>{trace.push('vite.close')}};
globalThis.__inertNet=()=>({listen(_port,_host,cb){cb()},address(){return {port:12345}},close(cb){cb()}});
registerHooks({
 resolve(spec,ctx,next){
  if(spec==='@playwright/test')return {url:'inert:pw',shortCircuit:true};
  if(spec==='vite')return {url:'inert:vite',shortCircuit:true};
  if(spec==='node:net' && ctx.parentURL?.endsWith('/capture.ts'))return {url:'inert:net',shortCircuit:true};
  return next(spec,ctx);
 },
 load(url,ctx,next){
  if(url==='inert:pw'||url===pathToFileURL(ready.bindings.playwright).href)return {format:'module',source:'export const chromium=globalThis.__inertChrome;',shortCircuit:true};
  if(url==='inert:vite')return {format:'module',source:'export const createServer=async()=>globalThis.__inertVite;',shortCircuit:true};
  if(url==='inert:net')return {format:'module',source:'export const createServer=globalThis.__inertNet;',shortCircuit:true};
  if(url===pathToFileURL(ready.bindings.tsxApi).href)return {format:'commonjs',source:'exports.register=()=>()=>{};',shortCircuit:true};
  if(url.endsWith('/capture/classes.ts'))return {format:'module',source:'export const farRanges=()=>[];export const loadClassRules=()=>({});export const reviewClass=()=>"viewmodel";',shortCircuit:true};
  if(url.endsWith('/capture/screens.ts'))return {format:'module',source:'export const SCREENS={};',shortCircuit:true};
  if(url.endsWith('/capture/capture.ts'))return {format:'module',source:stripTypeScriptTypes(fs.readFileSync(new URL(url),'utf8')),shortCircuit:true};
  return next(url,ctx);
 }
});
const {execute,productionCapture}=await import(pathToFileURL(packet+'/entry.mjs'));
const results=[];
for(const mode of ['goto-only','goto-plus-close']){
 cleanupFails=mode==='goto-plus-close';trace.length=0;
 browser.newPage=async()=>({on:()=>{},addInitScript:async()=>{},goto:async()=>{trace.push('actual-openReview-goto');throw primary;},evaluate:async()=>{throw new Error('UNEXPECTED evaluate')}});
 const dir=fs.mkdtempSync(E+'/entry-');const output=dir+'/output';fs.mkdirSync(output);
 const context={ready,spec:plan.units[0],paths:{output,evidence:dir}};
 const result=await execute(context,{capture:productionCapture,receipt:(name,r)=>fs.writeFileSync(dir+'/'+name,JSON.stringify(r),{flag:'wx'}),emit:()=>{throw new Error('unexpected stderr')}});
 const row={mode,trace:[...trace],result,root:dir};
 results.push(row);
 assert.equal(result.code,1);
 assert.equal(trace.filter(x=>x==='actual-openReview-goto').length,1);
 assert.equal(result.record.primaryFailure.message,cleanupFails?'SECONDARY_BROWSER_CLOSE':'PRIMARY_PAGE_GOTO');
 if(cleanupFails)assert.equal(JSON.stringify(result.record).includes('PRIMARY_PAGE_GOTO'),false);
 else assert.equal(result.record.primaryFailure.partial.base64,'AP8=');
}
fs.writeFileSync(E+'/entry-adverse-v2-results.json',JSON.stringify(results,null,2));
console.log(JSON.stringify({cases:results.length,originalPrimaryLostWithClose:true,realCaptureReview:true,nativeProcesses:0}));
