import client from '/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/client/vitest.config.ts';
export default {...client,
 root:'/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/client',
 cacheDir:'/private/tmp/vmrev-hrgu6g4e/vite-cache',
 test:{...client.test,cache:false,fsModuleCache:false,fsModuleCachePath:'/private/tmp/vmrev-hrgu6g4e/module-cache',maxWorkers:2,fileParallelism:false,maxConcurrency:2}
};
