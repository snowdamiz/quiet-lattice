// The UI screens `pnpm capture -- --ui <screen>` knows how to reach. Each later UI task adds its screen here, so the
// grader always gets its 16:9 and 21:9 captures and a 60 fps clip the same way.
import type { Page } from '@playwright/test';
import { EVENTS } from '@astra/shared/events';
import { darkAt, edgeAt, seasonOpening } from '@astra/shared/seasons';
import { EDGE_X, GALAXY_SEED, Galaxy, galaxyTiers, homeSystems } from '@astra/shared/world';

export interface ScreenDef {
  /** dev scenario hash to open the client with */
  hash?: string;
  /** drive the page to the screen and let it settle */
  open(page: Page): Promise<void>;
  /**
   * Start the motion the clip should show (a panel opening, a hover, a toast), right before its frames are taken.
   * Without it the clip shows the settled screen.
   */
  motion?(page: Page): Promise<void>;
  /** Which clip frames go on the clip sheet (all are written to _frames/). Default: twenty spread evenly. */
  sheetFrames?: readonly number[];
  /** Extra 16:9 stills, taken after the main one and before the clip: `16x9-<name>.png` after `pose` drives the page. */
  stills16x9?: Record<string, (page: Page) => Promise<void>>;
  /** Extra stills taken at both aspects, after `stills16x9`: `16x9-<name>.png` and `21x9-<name>.png`. */
  stills?: Record<string, (page: Page) => Promise<void>>;
  /** The aspect the clip is taken at. Default 16:9. */
  clipAspect?: '16x9' | '21x9';
  /** Regions of the page (CSS selectors, padded by `pad` px) whose clip frames go on 4x sheets of their own,
   * `crops-<name>.png`, each frame of `sheetFrames` cropped from a lossless capture. */
  crops?: readonly { name: string; selector: string; pad?: number }[];
  /** Draw scrollbars (headless Chromium hides them by default), for screens whose scroll affordance is being judged. */
  showScrollbars?: boolean;
  /** How long the clip runs (s; 60 frames a second): long enough for the whole motion. Default 1. */
  clipSeconds?: number;
  /** Run the HUD's clock and timers (game.hud.now / later / cancel) on the clip's clock, so toasts and fades last as long
   * in the clip as in play. */
  hudClock?: boolean;
  /** Text written to `readout.txt` beside the clip sheet (its first line printed under the sheet), read once the last frame
   * is in (the cost of the UI the clip shows, say). */
  readout?(page: Page): Promise<string>;
  /** Console errors the screen causes on purpose (the browser reports a refused request, say), not counted against it. */
  expectedErrors?: RegExp[];
}

/** Steps the game by hand, then waits out the HUD's CSS transitions (they run on real time, not game time). */
const settle = async (page: Page, frames = 60) => {
  await page.evaluate((n) => (window as unknown as { step(n: number): Promise<void> }).step(n), frames);
  await page.waitForTimeout(1200);
};

interface InventoryApi {
  state: { suit: unknown[]; pods: unknown[][] };
  restore(saved: unknown): boolean;
  add(id: string, n: number, to?: 'auto' | 'suit' | 'cargo'): number;
  setLoadout(l: { ship: { hull: string; modules: Record<string, string>; cargoPods: number; livery: number } | null; skills?: string[] }): boolean;
}

/** What the HUD captures drive of the game: the walker's multitool meter and the ship's Charge (P1.E07.T02). */
interface MeterGame {
  mode: string;
  multitool: { meter: { heat: number; overheated: boolean; charge: number } };
  ship: {
    charge: number;
    mode: string;
    speed: number;
    throttle: number;
    tryPulse(): void;
    state: { frame: unknown; pos: { set(x: number, y: number, z: number): void }; quat: { setFromRotationMatrix(m: { elements: number[] }): void } };
  };
  system: { homePlanet: { radius: number; position: { x: number; y: number; z: number } } };
  cam: { frame: unknown };
  hud: { toast(text: string, tone?: string): void };
}
interface MeterWindow {
  game: MeterGame;
  dev: { boot(): Promise<void>; button(b: number, down: boolean): void };
  THREE?: unknown;
}

/** The walker's heat meter at `heat`, locked out or not, with the beam held (the mouse button down) or let go. */
async function heatAt(page: Page, heat: number, overheated: boolean, held: boolean): Promise<void> {
  await page.evaluate(
    ({ heat, overheated, held }) => {
      const w = window as unknown as MeterWindow;
      w.game.multitool.meter = { heat, overheated, charge: 0 };
      w.dev.button(0, held);
    },
    { heat, overheated, held },
  );
}

/**
 * Parks the page's own frame loop (its requestAnimationFrame callbacks are dropped), so the game moves only as frames are
 * stepped: the meter a still is taken at is the one it was stepped to, however long the CSS waits run.
 */
async function parkLoop(page: Page): Promise<void> {
  await page.evaluate(async () => {
    const w = window as unknown as { __holdRaf?: boolean };
    const raf = window.requestAnimationFrame.bind(window);
    w.__holdRaf = true;
    window.requestAnimationFrame = (cb) => (w.__holdRaf ? 0 : raf(cb));
    // (the callback already queued runs once more, then parks)
    await new Promise((r) => setTimeout(r, 100));
  });
}

/** On foot beside the landed ship on the home world: the #foot scenario, which lands the ship and steps out after 1.5 s of
 * real time, on foot for good, out of the camera's glide, and settled. */
async function standingByShip(page: Page): Promise<void> {
  // (on the world: getting out of the sandbox's first ship, still by the Waystation, is on foot too, in its hangar)
  const onFoot = () =>
    page.waitForFunction(async () => {
      const w = window as unknown as { step(n: number): Promise<void>; game: { mode: string; player: { state: { frame?: { sampler?: unknown } } } } };
      await w.step(4);
      return w.game.mode === 'foot' && !!w.game.player.state.frame?.sampler;
    });
  await onFoot();
  await page.waitForTimeout(2500);
  await onFoot();
  // (where the scenario sets the ship down turns with the world under real time: a loaded machine can put it in the sea)
  const inSea = await page.evaluate(() => {
    const p = (window as unknown as { game: { player: { state: { frame: { ocean?: boolean; radius: number }; pos: { length(): number } } } } }).game.player;
    return !!p.state.frame.ocean && p.state.pos.length() < p.state.frame.radius;
  });
  if (inSea) throw new Error('the #foot scenario set the ship down in the sea: capture again');
  // the camera's ease from the ship into the walker's head (4 s of game time) can outlast that on a loaded machine: stepped
  // out, so the multitool is up and the view still before anything is taken
  for (let i = 0; i < 60; i++) {
    const gliding = await page.evaluate(async () => {
      const w = window as unknown as { step(n: number): Promise<void>; game: { director: { pose: unknown; blend: unknown } } };
      await w.step(10);
      return !!(w.game.director.pose || w.game.director.blend);
    });
    if (!gliding) break;
  }
  await settle(page, 90);
  // and the arrival banners run out (each, and the band under it, lasts 7 s of the page's own time), the multitool raised
  await page.waitForFunction(
    async () => {
      const w = window as unknown as {
        step(n: number): Promise<void>;
        game: { hud: { bannerUntil?: number; bannerQueue?: unknown[] }; multitool: { raise?: number } };
      };
      await w.step(4);
      const hud = w.game.hud;
      return !hud.bannerQueue?.length && performance.now() > (hud.bannerUntil ?? 0) + 1000 && (w.game.multitool.raise ?? 0) >= 1;
    },
    null,
    { timeout: 60_000, polling: 100 },
  );
}

/**
 * Turns the walker to the heading nearest its own (5° steps either way) whose crosshair is on a plant or rock under 3 m tall,
 * 4 to 25 m off, so the beam's impact glare sits right behind the crosshair. Where the #foot scenario leaves the walker
 * facing varies with how fast the machine runs its landing, and the flora's hit spheres miss a tall tree's trunk at eye
 * level, so the beam can strike a rock hidden behind one.
 */
async function faceFlora(page: Page): Promise<void> {
  const found = await page.evaluate(async () => {
    type V = { copy(v: V): V; clone(): V; normalize(): V; applyAxisAngle(axis: V, a: number): V; distanceTo(v: V): number };
    const w = window as unknown as {
      step(n: number): Promise<void>;
      game: {
        player: { heading: V; state: { pos: V } };
        cam: { pos: V };
        multitool: { target: { point: V; scale: number; sp: { height: number } } | null };
      };
    };
    const g = w.game;
    const up = g.player.state.pos.clone().normalize();
    const start = g.player.heading.clone();
    for (let i = 0; i <= 72; i++) {
      const turn = (((i + 1) >> 1) * (i % 2 ? 1 : -1) * Math.PI) / 36;
      g.player.heading.copy(start).applyAxisAngle(up, turn);
      await w.step(2);
      const t = g.multitool.target;
      const d = t ? t.point.distanceTo(g.cam.pos) : 0;
      if (t && t.sp.height * t.scale < 3 && d >= 4 && d <= 25) return true;
    }
    return false;
  });
  if (!found) throw new Error('no plant or rock 4 to 25 m off in any direction from where the walker stands');
}

/** The heat meter runs `k` times as fast as the game for the clip, so a whole overheat cycle fits a few seconds of it. */
async function hastenHeat(page: Page, k: number): Promise<void> {
  await page.evaluate((k) => {
    const mt = (window as unknown as { game: { multitool: { stepHeat(dt: number, held: boolean): void } } }).game.multitool;
    const step = mt.stepHeat.bind(mt);
    mt.stepHeat = (dt, held) => step(dt * k, held);
  }, k);
}

/** The client's ability model and clocks as a capture drives them: no server, so the screen says what one would. */
interface AbilityWindow {
  game: MeterGame & {
    time: number;
    abilities: {
      skills(view: unknown): void;
      state(m: unknown): void;
      answer(m: unknown): void;
      pending: Map<number, { bar: string; slot: number; node: string; at: number }>;
      now(): number;
    };
    hud: { later(fn: () => void, ms: number): number };
  };
}

/** The bars as the server's skills view would hold them, the ship bar working `shipSlots` slots. */
async function slotAbilities(page: Page, ground: (string | null)[], ship: (string | null)[], shipSlots: number): Promise<void> {
  await page.evaluate(
    ({ ground, ship, shipSlots }) => {
      // (no named functions in here: the page has no helper for their names)
      const slots = { ground: [...ground, ...Array(6 - ground.length).fill(null)], ship: [...ship, ...Array(5 - ship.length).fill(null)] };
      (window as unknown as AbilityWindow).game.abilities.skills({ state: { slots }, shipSlots });
    },
    { ground, ship, shipSlots },
  );
}

/** The server's cooldowns: each node ready again `left` seconds from the game's world time now; `on` the toggles on. */
async function coolingDown(page: Page, left: Record<string, number>, on: string[] = []): Promise<void> {
  await page.evaluate(
    ({ left, on }) => {
      const g = (window as unknown as AbilityWindow).game;
      g.abilities.state({ t: 'abilities', cooldowns: Object.entries(left).map(([node, s]) => ({ node, readyAt: g.time + s })), on });
    },
    { left, on },
  );
}

/**
 * A key press's round trip as a server would answer it, on the HUD's clock from now: the cast sent at `at` ms, answered
 * `rtt` ms later, carried out (its cooldown running `cooldownS` from then, the meter paid `pay`: heat on the ground bar,
 * Charge on the ship's) or refused for `refused`.
 */
async function castRoundTrip(
  page: Page,
  c: { bar: 'ground' | 'ship'; slot: number; node: string; at: number; rtt?: number; cooldownS?: number; pay?: number; refused?: string; seq: number },
): Promise<void> {
  await page.evaluate((c) => {
    const g = (window as unknown as AbilityWindow).game;
    const a = g.abilities;
    g.hud.later(() => {
      a.pending.set(c.seq, { bar: c.bar, slot: c.slot, node: c.node, at: a.now() });
      g.hud.later(() => {
        if (c.refused) {
          const readyAt = (a as unknown as { cooldowns: Map<string, number> }).cooldowns.get(c.node);
          a.answer({ t: 'cast', seq: c.seq, node: c.node, slot: c.slot, result: 'refused', reason: c.refused, readyAt });
          return;
        }
        const cooldowns = [...(a as unknown as { cooldowns: Map<string, number> }).cooldowns].map(([node, readyAt]) => ({ node, readyAt }));
        a.state({ t: 'abilities', cooldowns: [...cooldowns.filter((x) => x.node !== c.node), { node: c.node, readyAt: g.time + c.cooldownS! }], on: [] });
        a.answer({ t: 'cast', seq: c.seq, node: c.node, slot: c.slot, result: 'cast', readyAt: g.time + c.cooldownS! });
        if (c.bar === 'ground') g.multitool.meter = { ...g.multitool.meter, heat: g.multitool.meter.heat + (c.pay ?? 0) };
        else g.ship.charge -= c.pay ?? 0;
      }, c.rtt ?? 60);
    }, c.at);
  }, c);
}

/**
 * The ship in open flight off the home world, nose just past it, `side` 1 on its day side (in sunlight, inside the habitable band:
 * Charge regenerates) or −1 on its night side (in its shadow: nothing), with Charge at `charge`.
 */
async function shipOffHome(page: Page, side: 1 | -1, charge: number): Promise<void> {
  await page.evaluate(
    ({ side, charge }) => {
      const w = window as unknown as MeterWindow;
      const g = w.game;
      const ship = g.ship;
      const home = g.system.homePlanet;
      const p = home.position;
      const l = Math.hypot(p.x, p.y, p.z);
      // three radii sunward of the planet (the star at the origin), a little to one side and above; on the night side close
      // enough to the sun line to stay in the planet's shadow
      const r = home.radius * 3;
      const sx = (-p.x / l) * side;
      const sz = (-p.z / l) * side;
      const across = side > 0 ? 0.35 : 0.12;
      const x = p.x + sx * r + sz * r * across;
      const y = p.y + r * (side > 0 ? 0.22 : 0.1);
      const z = p.z + sz * r - sx * r * across;
      ship.state.frame = null;
      ship.state.pos.set(x, y, z);
      // the nose (−Z forward) past the planet's limb, so the planet fills one side of the frame and the reticle and its
      // readouts sit over open space, as they do in flight
      const fx = p.x - sz * r * 0.75 - x;
      const fy = p.y - y;
      const fz = p.z + sx * r * 0.75 - z;
      const fl = Math.hypot(fx, fy, fz);
      const f = [fx / fl, fy / fl, fz / fl];
      // right = f × up(0,1,0), up' = right × f
      const rx = -f[2];
      const rz = f[0];
      const rl = Math.hypot(rx, rz);
      const right = [rx / rl, 0, rz / rl];
      const up = [right[1] * f[2] - right[2] * f[1], right[2] * f[0] - right[0] * f[2], right[0] * f[1] - right[1] * f[0]];
      // the rotation whose columns are right, up and −forward (a Matrix4's column-major elements: setFromRotationMatrix
      // reads nothing else)
      ship.state.quat.setFromRotationMatrix({ elements: [...right, 0, ...up, 0, -f[0]!, -f[1]!, -f[2]!, 0, 0, 0, 0, 1] });
      ship.mode = 'flying';
      ship.speed = 0;
      ship.charge = charge;
      g.cam.frame = undefined;
    },
    { side, charge },
  );
}

/** One inventory capture: the ship (its pods aboard), the skills, and what the cargo holds. */
interface InventoryScene {
  hull: string;
  pods: number;
  skills?: string[];
  /** The modules fitted, by hardpoint (default: Pulse Lasers on s1). */
  modules?: Record<string, string>;
  /** Added to the cargo pods in order, filling them pod by pod. */
  cargo: [string, number][];
  /** Or each pod's stacks laid out exactly, pod by pod. */
  podStacks?: [string, number][][];
}

/** A mining trip's haul in the suit, the same in every scene. */
const SUIT_HAUL: [string, number][] = [
  ['ferrite', 12480],
  ['carbon', 386],
  ['oxygen', 92],
  ['sodium', 45],
  ['dihydrogen', 210],
  ['copper', 64],
  ['tritium', 2200],
  ['cobalt', 18],
  ['gold', 31],
];

const INVENTORY_SCENES: Record<string, InventoryScene> = {
  // the Lark every pilot starts in: one pod
  lark: {
    hull: 'lark',
    pods: 1,
    cargo: [
      ['tritium', 9999],
      ['gold', 140],
      ['cobalt', 75],
      ['mining_laser', 1],
    ],
  },
  // the Lark with Pack Mule learned: a second pod in the bay it adds, and stacks of 15,000
  packMule: {
    hull: 'lark',
    pods: 2,
    skills: ['pack_mule'],
    cargo: [
      ['tritium', 15000 + 6400],
      ['gold', 140],
      ['cobalt', 75],
      ['mining_laser', 1],
      ['copper', 820],
      ['carbon', 2600],
      ['ferrite', 15000],
      ['dihydrogen', 900],
      ['flak_ammo', 300],
    ],
  },
  // a Mule hauler: four pods, two of them empty
  mule: {
    hull: 'mule',
    pods: 4,
    cargo: [
      ['tritium', 9999 * 3 + 4120],
      ['gold', 640],
      ['cobalt', 375],
      ['copper', 1210],
      ['ferrite', 9999 + 2760],
      ['carbon', 4400],
      ['mining_laser', 1],
      ['flak_ammo', 300],
    ],
  },
  // a Longhaul freighter with every pod in use: the pod list scrolls
  longhaulFull: {
    hull: 'longhaul',
    modules: { m1: 'flak_cannon' },
    pods: 16,
    cargo: [],
    podStacks: [
      [
        ['tritium', 9999],
        ['tritium', 9999],
        ['tritium', 9999],
        ['tritium', 4120],
      ],
      [
        ['ferrite', 9999],
        ['ferrite', 9999],
        ['ferrite', 3100],
      ],
      [
        ['carbon', 9999],
        ['carbon', 2600],
      ],
      [
        ['copper', 1210],
        ['cobalt', 375],
        ['gold', 640],
      ],
      [
        ['oxygen', 1800],
        ['sodium', 950],
      ],
      [
        ['dihydrogen', 9999],
        ['dihydrogen', 4200],
      ],
      [
        ['tritium', 9999],
        ['tritium', 9999],
        ['tritium', 6100],
      ],
      [
        ['ferrite', 9999],
        ['copper', 820],
      ],
      [
        ['gold', 210],
        ['cobalt', 160],
        ['copper', 400],
      ],
      [
        ['carbon', 9999],
        ['carbon', 9999],
        ['carbon', 1400],
      ],
      [
        ['frostglass', 120],
        ['cinderglass', 85],
      ],
      [
        ['tritium', 9999],
        ['tritium', 2500],
      ],
      [
        ['dihydrogen', 900],
        ['oxygen', 640],
        ['sodium', 300],
      ],
      [
        ['ferrite', 9999],
        ['ferrite', 9999],
        ['ferrite', 9999],
        ['ferrite', 750],
      ],
      [
        ['cobalt', 90],
        ['gold', 75],
      ],
      [
        ['mining_laser', 1],
        ['tritium', 3300],
        ['flak_ammo', 300],
      ],
    ],
  },
  // a Longhaul freighter: sixteen pods, two in use, the empty fourteen as one line
  longhaul: {
    hull: 'longhaul',
    modules: { m1: 'flak_cannon' },
    pods: 16,
    cargo: [
      ['tritium', 9999 * 6 + 5200],
      ['ferrite', 9999 * 2 + 3100],
      ['gold', 640],
      ['carbon', 4400],
      ['cobalt', 375],
      ['flak_ammo', 300],
    ],
  },
};

/** Boots a game, fits the scene's ship, loads the suit and the cargo, opens the inventory and hovers the ferrite stack:
 * the detail line names it, its count against the stack cap, and where it comes from. */
async function openInventory(page: Page, scene: InventoryScene): Promise<void> {
  await page.evaluate(() => (window as unknown as { dev: { boot(): Promise<void> } }).dev.boot());
  await page.evaluate(
    ({ scene, suit }) => {
      const g = (window as unknown as { game: { inventory: InventoryApi; menus: { openInventory(): void } } }).game;
      const inv = g.inventory;
      inv.setLoadout({
        ship: { hull: scene.hull, modules: scene.modules ?? { s1: 'pulse_lasers' }, cargoPods: scene.pods, livery: 0 },
        skills: scene.skills ?? [],
      });
      for (const [id, n] of suit) inv.add(id, n, 'suit');
      for (const [id, n] of scene.cargo) inv.add(id, n, 'cargo');
      if (scene.podStacks) {
        const pods = inv.state.pods.map((pod, p) =>
          pod.map((_, i) => (scene.podStacks![p]?.[i] ? { item: scene.podStacks![p]![i]![0], count: scene.podStacks![p]![i]![1] } : null)),
        );
        inv.restore({ ...inv.state, pods });
      }
      g.menus.openInventory();
    },
    { scene, suit: SUIT_HAUL },
  );
  await settle(page, 60);
  const slot = page.locator('.inv-slot[data-c="suit"][data-i="1"]');
  const box = await slot.boundingBox();
  if (box) await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.waitForTimeout(500);
}

/**
 * The inventory's motion for the clip: the panel opens again (it rises 8 px as it fades in, 0.36 s), then, 0.3 s of
 * animation time later, a click sends the carbon stack across to the cargo through the screen's own pointer handlers: a
 * tile flies from the suit slot to the cargo slot (0.18 s, ease-out), the slot it lands on settles back, and on a merge
 * (the Mule's and the Longhaul's carbon) the count ticks up to the new total. Page timers run on real time while the clip
 * slows CSS and Web Animations tenfold, hence 3000 ms: the flight spans about frames 18 to 29.
 */
async function inventoryMotion(page: Page): Promise<void> {
  await page.evaluate(() => {
    const menus = (window as unknown as { game: { menus: { closeAll(): void; openInventory(): void } } }).game.menus;
    menus.closeAll();
    menus.openInventory();
    setTimeout(() => {
      const slot = document.querySelector('.inv-slot[data-c="suit"][data-i="3"]');
      if (!slot) return;
      const at = slot.getBoundingClientRect();
      const init = { bubbles: true, button: 0, clientX: at.x + at.width / 2, clientY: at.y + at.height / 2, pointerId: 1, isPrimary: true };
      slot.dispatchEvent(new PointerEvent('pointerdown', init));
      slot.dispatchEvent(new PointerEvent('pointerup', init));
    }, 3000);
  });
}

/** The open (every third frame), every frame of the flight, then the landing settling. */
const INVENTORY_SHEET = [0, 3, 6, 9, 12, 15, ...Array.from({ length: 13 }, (_, k) => 18 + k), 33, 36, 40, 45, 50, 59];

const inventoryScreen = (scene: InventoryScene, extra: Partial<ScreenDef> = {}): ScreenDef => ({
  open: (page) => openInventory(page, scene),
  motion: inventoryMotion,
  sheetFrames: INVENTORY_SHEET,
  ...extra,
});

/** All nineteen resources (DESIGN 15.3, P1.E13.T02), a stack of each, by family: the suit holds the warp cell, the plants,
 * the rock and deposit finds and the hostile worlds' six; the Lark's pod the asteroids' two, the Count's, the Hollow's
 * and the Cartographers' leavings, and the mining laser. */
const NINETEEN_SUIT: [string, number][] = [
  ['warp_cell', 1],
  ['carbon', 386],
  ['sodium', 45],
  ['oxygen', 92],
  ['ferrite', 9999],
  ['dihydrogen', 210],
  ['copper', 64],
  ['cobalt', 18],
  ['gold', 31],
  ['frostglass', 120],
  ['acidsalt', 85],
  ['cinderglass', 64],
  ['stormquartz', 38],
  ['gamma_crystal', 22],
  ['murkpearl', 12],
  ['ferrite', 2481],
];
const NINETEEN_POD: [string, number][] = [
  ['tritium', 9999],
  ['iridium', 46],
  ['count_residue', 140],
  ['husk_alloy', 6],
  ['glyphstone', 3],
  ['mining_laser', 1],
];

/** Lays the nineteen out (16x9-resources.png) and hovers the frostglass stack, so the detail line says where it comes
 * from. */
async function showNineteen(page: Page): Promise<void> {
  await page.evaluate(
    ({ suit, pod }) => {
      const g = (window as unknown as { game: { inventory: InventoryApi; menus: { renderInventory(): void } } }).game;
      const inv = g.inventory;
      // (no named functions in here: the bundler would wrap them in a helper the page does not have)
      inv.restore({
        ...inv.state,
        suit: inv.state.suit.map((_, i) => (suit[i] ? { item: suit[i]![0], count: suit[i]![1] } : null)),
        pods: inv.state.pods.map((p, k) => p.map((_, i) => (!k && pod[i] ? { item: pod[i]![0], count: pod[i]![1] } : null))),
      });
      g.menus.renderInventory();
    },
    { suit: NINETEEN_SUIT, pod: NINETEEN_POD },
  );
  await settle(page, 30);
  const slot = page.locator(`.inv-slot[data-c="suit"][data-i="${NINETEEN_SUIT.findIndex(([id]) => id === 'frostglass')}"]`);
  const box = await slot.boundingBox();
  if (box) await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.waitForTimeout(500);
}

/** The cargo list scrolled to its end: the last pod and the footer both in view. */
async function scrollPodsToEnd(page: Page): Promise<void> {
  await page.evaluate(() => {
    const pods = document.querySelector('.inv-pods');
    if (pods) pods.scrollTop = pods.scrollHeight;
  });
  await page.waitForTimeout(300);
}

/** What the fabricator screens reach of the page. */
interface FabricatorPage {
  game: {
    inventory: InventoryApi;
    fabricator: { open(at: 'waystation' | 'ship'): void };
    station: { pads: { x: number; z: number }[] };
    ship: { state: { pos: { clone(): { set(x: number, y: number, z: number): unknown } } } };
    player: { spawn(frame: unknown, at: unknown, heading: unknown): void };
    system: { homePlanet: unknown };
    dockOnPad(near: unknown): void;
    debugGoto(planet: unknown, opts: { sunAngle: number; alt: number; azimuth: number }): void;
    mode: string;
    cam: { frame: unknown };
  };
  dev: { boot(): Promise<void> };
}

/** A mining trip's haul as it reaches a fabricator: enough for a warp cell, a pulse fuel cell and two sodium cartridges,
 * short of oxygen and of ferrite for flak, and a torpedo recipe found on the way (to learn). */
const FAB_SUIT: [string, number][] = [
  ['dihydrogen', 64],
  ['tritium', 41],
  ['cobalt', 7],
  ['oxygen', 12],
  ['sodium', 46],
  ['ferrite', 18],
  ['carbon', 37],
  ['copper', 22],
  ['recipe_torpedo', 1],
];

/** Lays the haul out in the suit (the Lark's pod holding a little more), then opens fabricator `at`. */
async function stockAndOpen(page: Page, at: 'waystation' | 'ship', suit: [string, number][], pod: [string, number][]): Promise<void> {
  await page.evaluate(
    ({ at, suit, pod }) => {
      const g = (window as unknown as FabricatorPage).game;
      const inv = g.inventory;
      // (no named functions in here: the bundler would wrap them in a helper the page does not have)
      inv.restore({
        ...inv.state,
        suit: inv.state.suit.map((_, i) => (suit[i] ? { item: suit[i]![0], count: suit[i]![1] } : null)),
        pods: inv.state.pods.map((p, k) => p.map((_, i) => (!k && pod[i] ? { item: pod[i]![0], count: pod[i]![1] } : null))),
      });
      g.fabricator.open(at);
    },
    { at, suit, pod },
  );
  await settle(page, 30);
}

/** Clicks a control of the fabricator screen (a recipe row, Craft, a stepper button) through its own click handler. */
async function fabClick(page: Page, selector: string): Promise<void> {
  await page.evaluate((s) => document.querySelector<HTMLElement>(s)?.click(), selector);
  await page.waitForTimeout(400);
}

/**
 * The Waystation's fabricator (P1.E13.T05): the pilot on foot at the fabricator terminal on the trade deck, its ship on
 * a pad behind, after a mining trip. The five recipes it starts with: three it can make, two short of materials; a
 * torpedo recipe to learn. The oxygen cartridge selected and Craft pressed: refused, "not enough oxygen", the short
 * material flashing.
 */
async function openStationFabricator(page: Page): Promise<void> {
  await stationFabricator(page);
  await fabClick(page, '.fab-row[data-recipe="oxygen_cartridge"]');
  await fabClick(page, '[data-make]');
  await page.waitForTimeout(800);
}

/** The same scene at the Waystation, the fabricator opened on the warp cell it can make, nothing pressed yet. */
async function stationFabricator(page: Page): Promise<void> {
  await page.evaluate(() => (window as unknown as FabricatorPage).dev.boot());
  await page.evaluate(() => {
    const g = (window as unknown as FabricatorPage).game;
    const pad = g.station.pads[3]!;
    g.dockOnPad(g.ship.state.pos.clone().set(pad.x, 0, pad.z));
    // a couple of metres back from the terminal (the kiosk at x −30, z −80 on the 7 m deck), turned to it
    g.player.spawn(g.station, g.ship.state.pos.clone().set(-28.6, 7.05, -77.4), g.ship.state.pos.clone().set(-0.5, 0, -0.866));
    g.mode = 'foot';
    g.cam.frame = undefined;
  });
  await settle(page, 120);
  await stockAndOpen(page, 'waystation', FAB_SUIT, [
    ['tritium', 380],
    ['carbon', 240],
  ]);
}

/** The ship's fabricator: in the Lark landed on the home world, the haul aboard, flak ammo selected, three crafts. */
async function openShipFabricator(page: Page): Promise<void> {
  await page.evaluate(() => (window as unknown as FabricatorPage).dev.boot());
  await page.evaluate(() => {
    const g = (window as unknown as FabricatorPage).game;
    g.debugGoto(g.system.homePlanet, { sunAngle: 40, alt: 0, azimuth: 20 });
    g.mode = 'ship';
    g.cam.frame = undefined;
  });
  await settle(page, 150);
  await stockAndOpen(
    page,
    'ship',
    FAB_SUIT.map(([id, n]) => [id, id === 'ferrite' ? 96 : n]),
    [
      ['tritium', 380],
      ['carbon', 240],
    ],
  );
  await fabClick(page, '.fab-row[data-recipe="flak_ammo"]');
  await fabClick(page, '[data-q="1"]');
  await fabClick(page, '[data-q="1"]');
}

/**
 * A craft's motion for the clip: 0.2 s of animation time after the clip starts, Craft is pressed through the screen's
 * own handler; the fabrication runs across the button (0.56 s, ease-in-out), then what was made shows in the line under
 * the columns, the material counts drop and the rows that changed settle back (0.7 s). Page timers run on real time while
 * the clip slows CSS and Web Animations tenfold, hence 2000 ms.
 */
const fabricatorMotion =
  (select: string | null) =>
  async (page: Page): Promise<void> => {
    if (select) await fabClick(page, `.fab-row[data-recipe="${select}"]`);
    await page.evaluate(() => setTimeout(() => document.querySelector<HTMLElement>('[data-make]')?.click(), 2000));
  };

/**
 * A lesson's motion for the clip: 0.2 s in, LEARN is pressed on the torpedo recipe (the haul's find); its row eases up out
 * of "Recipes to learn" into the recipe list (0.38 s) and flashes once, the heading fades out (0.2 s), the controls
 * dimmed by the press come back, and the torpedo's details come in beside it (0.28 s).
 */
async function learnMotion(page: Page): Promise<void> {
  await page.evaluate(() => setTimeout(() => document.querySelector<HTMLElement>('[data-learn="torpedo"]')?.click(), 2000));
}

/**
 * The stepper at its limits, then a refusal, for the clip (each step 0.15 s of animation time apart; page timers run on
 * real time while the clip slows CSS and Web Animations tenfold, hence 1500 ms): + and MAX pressed on the warp cell at 1
 * of 1 (both dimmed: nothing happens), the flak ammo picked (it can make none), + and MAX pressed there (nothing), then
 * Enter: refused, "not enough ferrite", the line under the columns cross-fading to it and the short ferrite flashing red.
 */
async function limitsMotion(page: Page): Promise<void> {
  await page.evaluate(() => {
    const press = [
      () => document.querySelector<HTMLElement>('[data-q="1"]')?.click(),
      () => document.querySelector<HTMLElement>('[data-q="max"]')?.click(),
      () => document.querySelector<HTMLElement>('.fab-row[data-recipe="flak_ammo"]')?.click(),
      () => document.querySelector<HTMLElement>('[data-q="1"]')?.click(),
      () => document.querySelector<HTMLElement>('[data-q="max"]')?.click(),
      () => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Enter', bubbles: true })),
    ];
    press.forEach((fn, k) => setTimeout(fn, 2000 + k * 1500));
  });
}

/** The stepper at a maximum above one: the pulse fuel cell (the haul makes six) set to 6 of 6 with MAX, + and MAX dimmed
 * and − lit. */
async function stepperAtSix(page: Page): Promise<void> {
  await stationFabricator(page);
  await fabClick(page, '.fab-row[data-recipe="pulse_fuel_cell"]');
  await fabClick(page, '[data-q="max"]');
}

/**
 * Its clip, each step 0.2 s of animation time apart (page timers run on real time, the clip's animations tenfold slower):
 * − to 5 (+ and MAX light up), + back to 6 (they dim), then + and MAX pressed at 6, which do nothing.
 */
async function stepperMotion(page: Page): Promise<void> {
  await page.evaluate(() => {
    const press = ['[data-q="-1"]', '[data-q="1"]', '[data-q="1"]', '[data-q="max"]'];
    press.forEach((sel, k) => setTimeout(() => document.querySelector<HTMLElement>(sel)?.click(), 2000 + k * 2000));
  });
}

/** The press (every third frame), the fabrication's run across the button, the result and the rows settling. */
const FABRICATOR_SHEET = [0, 6, 12, 18, 24, 30, 36, 42, 48, 54, 60, 66, 72, 78, 84, 90, 96, 104, 112, 119];

/** What the cutscene screens reach of the page. */
interface CutscenePage {
  game: {
    cutscenes: { load(id: string): Promise<unknown>; stage(def: unknown): boolean; play(id: string): Promise<unknown>; stop(): void };
    hud: { clearBanners(): void };
  };
  dev: { boot(): Promise<void> };
  step(n: number): Promise<void>;
  __holdRaf?: boolean;
}

/**
 * Boots a game with the ship where the cutscene stages it and the world settled, then parks the page's own frame loop
 * (its requestAnimationFrame callbacks are dropped), so the cutscene's clock moves only as frames are stepped: a still
 * is taken where it was stepped to, however long the CSS waits run.
 */
async function stageCutscene(page: Page, id: string): Promise<void> {
  await page.evaluate(() => (window as unknown as CutscenePage).dev.boot());
  await page.evaluate(async (id) => {
    const w = window as unknown as CutscenePage;
    w.game.cutscenes.stage(await w.game.cutscenes.load(id));
  }, id);
  await settle(page, 120);
  await page.evaluate(async () => {
    const w = window as unknown as CutscenePage & { requestAnimationFrame(cb: FrameRequestCallback): number };
    const raf = window.requestAnimationFrame.bind(window);
    w.__holdRaf = true;
    window.requestAnimationFrame = (cb) => (w.__holdRaf ? 0 : raf(cb));
    // (the callback already queued runs once more, then parks)
    await new Promise((r) => setTimeout(r, 100));
  });
}

/** What the remote-ships screens reach of the page (three's objects as the page has them). */
/* eslint-disable @typescript-eslint/no-explicit-any */
interface RemotePage {
  game: {
    traffic: { station: unknown; ships: { obj: { visible: boolean } }[] };
    ship: { speed: number; state: { pos: any; quat: any } };
    station: unknown;
    system: { homePlanet: unknown };
    hud: { clearBanners(): void };
    remotes: { view: { prepare(hull: string): Promise<unknown> } };
    hints?: Record<string, boolean>;
    cam: { frame: unknown };
    dockOnPad(near: unknown, quat: unknown): void;
    debugGoto(planet: unknown, opts: Record<string, unknown>): void;
  };
  dev: { boot(): Promise<void> };
  step(n: number): Promise<void>;
  __holdRaf?: boolean;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/**
 * Boots a game with its frame loop parked (as stageCutscene does) and the demo's station traffic out of the shot, puts the
 * ship where the scene wants it (`space`: off the Waystation, as the sandbox starts; `pads`: docked on its hangar pad at
 * (30, -22), facing the mouth; `surface`: hovering 40 m over lowland on the home world, in the morning sun) and lets the
 * world settle (its ground streams in from the workers), then plays
 * one of the remote layer's recorded scenes (packages/client/src/remote/replay.js SCENES: `flypast`, `crowd`, `pads`,
 * `surface`) as a snapshot stream through the wire's encoding with a 60 ms trip and 40 ms of jitter, offline, so the
 * capture is hermetic. `seconds` of it are stepped before the still.
 */
async function openRemotes(
  page: Page,
  scene: 'flypast' | 'crowd' | 'pads' | 'surface' | 'bay',
  seconds: number,
  stage: 'space' | 'pads' | 'surface' = 'space',
): Promise<void> {
  await page.evaluate(() => (window as unknown as RemotePage).dev.boot());
  await page.evaluate(async () => {
    const w = window as unknown as RemotePage & { requestAnimationFrame(cb: FrameRequestCallback): number };
    const raf = window.requestAnimationFrame.bind(window);
    w.__holdRaf = true;
    window.requestAnimationFrame = (cb) => (w.__holdRaf ? 0 : raf(cb));
    await new Promise((r) => setTimeout(r, 100));
  });
  await page.evaluate(
    async ({ scene, seconds, stage }) => {
      const w = window as unknown as RemotePage;
      const g = w.game;
      // (these are the server's ships: the demo's client-side traffic round the Waystation stays out of the shot)
      g.traffic.station = null;
      for (const s of g.traffic.ships) s.obj.visible = false;
      g.ship.speed = 0;
      // (the hover hint has been read)
      g.hints = { ...g.hints, vtol: true };
      const pos = g.ship.state.pos;
      if (stage === 'pads') {
        const V = pos.constructor;
        g.dockOnPad(new V(30, 2.4, -22), new g.ship.state.quat.constructor().setFromAxisAngle(new V(0, 1, 0), Math.PI));
      } else if (stage === 'surface') g.debugGoto(g.system.homePlanet, { sunAngle: 38, alt: 40, azimuth: 0 });
      g.cam.frame = undefined;
      await g.remotes.view.prepare('lark');
      // (the ground streams in from the workers, a few frames at a time, finest last)
      for (let i = 0; i < (stage === 'surface' ? 60 : 15); i++) {
        await w.step(6);
        await new Promise((r) => setTimeout(r, 150));
      }
      const url = '/src/remote/replay.js';
      const replay = await import(/* @vite-ignore */ url);
      replay.play(g, scene);
      await w.step(Math.round(seconds * 60));
      // (the system's name, shown on arrival, has had its moment)
      g.hud.clearBanners();
    },
    { scene, seconds, stage },
  );
  // (the HUD's transitions run on real time)
  await page.waitForTimeout(1200);
}

/**
 * A dev overlay over the remote-ships screens, drawn after every frame: for each other pilot, how the local ship's sensors
 * read it (its distance against its reach, the sensor range × its signature, and what raised or lowered the signature:
 * boosting, the pulse drive, cover) and whether they pick it up; and what the HUD made of it (its mark where it should be,
 * or nudged off the HUD, or none and why; its name, on which side, or dropped for want of room and what took it). A tag
 * under each pilot in view, and a table of them all (those out of view too) down the right. Tells a pilot undetected by
 * design (past its reach) from one the HUD left unmarked.
 */
async function sensorsOverlay(page: Page): Promise<void> {
  // (tsx names the functions below with a helper the page does not have)
  await page.evaluate('window.__name ??= (f) => f');
  await page.evaluate(() => {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const g = (window as any).game;
    const layer = document.createElement('div');
    layer.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:50;font:500 10px/12px ui-monospace,Menlo,monospace;color:#e9e7e2';
    document.body.append(layer);
    const tags = document.createElement('div');
    const table = document.createElement('div');
    table.style.cssText = 'position:absolute;right:12px;top:64px;padding:6px 8px;background:rgba(8,9,12,0.78);border:1px solid #3a3d44;white-space:pre';
    layer.append(tags, table);
    const V = g.camWorld.constructor;
    const v = new V();
    const km = (m: number) => (m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`);
    const ways = ['', 'nudged out', 'nudged up', 'nudged down', 'nudged left', 'nudged right'];
    const draw = () => {
      const W = window.innerWidth;
      const H = window.innerHeight;
      const rows: string[] = [];
      let html = '';
      const pilots = g.remotes.list.filter((r: any) => r.kind === 'player').sort((a: any, b: any) => (a.sense?.distance ?? 0) - (b.sense?.distance ?? 0));
      for (const r of pilots) {
        const s = r.sense;
        const p = g.hud.pilots.get(r.id);
        const marked = p && !p.goneAt;
        v.copy(r.world).sub(g.camWorld).applyQuaternion(g.camWorldQuatInv);
        const behind = v.z > 0;
        v.applyMatrix4(g.engine.camera.projectionMatrix);
        const x = (v.x * 0.5 + 0.5) * W;
        const y = (-v.y * 0.5 + 0.5) * H;
        const inView = !behind && x >= 0 && x <= W && y >= 0 && y <= H;
        const why = !r.shown ? 'not drawn' : !s ? 'not read' : !s.signature ? 'hidden (signature 0)' : `past its reach`;
        const sensed = s?.detected ? 'DETECTED' : `NOT DETECTED, ${why}`;
        const flags = s ? [s.boosting && 'boost x2', s.pulsing && 'pulse x2', s.inCover && 'cover /2'].filter(Boolean).join(' ') : '';
        const mark = !s?.detected
          ? 'no mark'
          : marked
            ? p.nudged
              ? `mark ${ways[p.nudged]}`
              : 'mark'
            : behind
              ? 'no mark, behind'
              : inView
                ? 'no mark, at the edge'
                : 'no mark, out of view';
        const name = !marked ? '' : p.shown ? `name ${p.side}` : `name dropped${p.why ? ` (${p.why})` : ''}`;
        rows.push(
          `${(r.name ?? 'Pilot').padEnd(14)} ${km(s?.distance ?? 0).padStart(7)} / ${km(s?.reach ?? 0).padStart(6)}  sig ${(s?.signature ?? 0).toFixed(2)} ${flags.padEnd(9)} ${(s?.detected ? 'DETECTED' : 'not detected').padEnd(12)} ${mark}${name ? `, ${name}` : ''}`,
        );
        if (!inView) continue;
        const colour = !s?.detected ? '#ff6b5e' : !marked || (p && !p.shown) ? '#f2b84b' : '#7fe0a0';
        html += `<div style="position:absolute;left:${x.toFixed(0)}px;top:${(y + 10).toFixed(0)}px;transform:translateX(-50%);padding:1px 4px;background:rgba(8,9,12,0.72);border-left:2px solid ${colour};white-space:nowrap">${r.name ?? 'Pilot'} ${km(s?.distance ?? 0)} / ${km(s?.reach ?? 0)}${flags ? ` ${flags}` : ''}<br><span style="color:${colour}">${sensed}</span>${s?.detected ? ` · ${mark}${name ? ` · ${name}` : ''}` : ''}</div>`;
      }
      tags.innerHTML = html;
      const read = pilots.find((r: any) => r.sense?.signature > 0)?.sense;
      table.textContent = `SENSORS: reach = range ${km(read ? read.reach / read.signature : 0)} x signature; held to 1.05 x reach and 0.5 s past it\n${'pilot'.padEnd(14)} ${'dist'.padStart(7)} / ${'reach'.padStart(6)}  signature            HUD\n${rows.join('\n')}`;
    };
    const frame = g.frame.bind(g);
    g.frame = (dt: number) => {
      frame(dt);
      draw();
    };
    draw();
    /* eslint-enable @typescript-eslint/no-explicit-any */
  });
}

/** Plays the cutscene from its start (ending one under way, and any banner) and steps `t` seconds into it. */
async function playCutsceneTo(page: Page, id: string, t: number): Promise<void> {
  await page.evaluate(
    async ({ id, t }) => {
      const w = window as unknown as CutscenePage;
      w.game.cutscenes.stop();
      w.game.hud.clearBanners();
      void w.game.cutscenes.play(id);
      await new Promise((r) => setTimeout(r, 0));
      await w.step(Math.round(t * 60));
    },
    { id, t },
  );
  // (a banner fades in on a CSS animation, which runs on real time)
  await page.waitForTimeout(1200);
}

/**
 * The chat and party UI's stage (P1.E15.T03), as page source (tsx would wrap functions written here in helpers the page
 * does not have): the client's own Net, beacon list and social UI, fed recorded server messages through a socket the
 * page plays the server for, in the offline sandbox, so the captures are hermetic. The socket answers requests as the
 * server would: chat comes back as the player's line, an invite to someone online is sent, accepting joins the
 * inviter's party, an answer to a beacon is refused (`answerCode`). `window.__social` drives it.
 */
/** Times one UI's own work in each frame of the clip that follows (the chat and party UI's moves and redraws, or the whole
 * HUD's update): every update between one captured frame and the next adds to that frame's figure, so the readout and the
 * clip count the same frames. */
async function uiCostProbe(page: Page, of: 'social' | 'hud'): Promise<void> {
  await page.evaluate((of) => {
    type Ui = { update(arg?: unknown): void };
    const w = window as unknown as { __social: { social: Ui }; game: { hud: Ui }; __clip: { frame(dt: number): void }; __uiCost: number[] };
    const ui = of === 'social' ? w.__social.social : w.game.hud;
    const update = ui.update.bind(ui);
    let spent = 0;
    ui.update = (arg?: unknown) => {
      const t = performance.now();
      update(arg);
      spent += performance.now() - t;
    };
    const clip = w.__clip;
    const frame = clip.frame.bind(clip);
    w.__uiCost = [];
    clip.frame = (dt: number) => {
      spent = 0;
      frame(dt);
      w.__uiCost.push(spent);
    };
  }, of);
}

/** What the UI's cost over the clip is held to (ms). */
const UI_BUDGET_MS = 1;

/** The probed UI's per-frame cost over the clip (`uiCostProbe`), as the readout under its sheet: the mean, the 95th
 * percentile and the worst frame, against the 16.7 ms a frame at 60 fps has, and the index of every frame over the 1 ms
 * budget. */
const uiCostReadout =
  (label: string) =>
  async (page: Page): Promise<string> => {
    const ms = await page.evaluate(() => (window as unknown as { __uiCost: number[] }).__uiCost);
    const sorted = [...ms].sort((a, b) => a - b);
    const mean = ms.reduce((a, b) => a + b, 0) / Math.max(1, ms.length);
    const at = (q: number) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * q))] ?? 0;
    const over = ms.flatMap((v, i) => (v > UI_BUDGET_MS ? [`${String(i).padStart(3, '0')} (${v.toFixed(3)} ms)`] : []));
    return [
      `${label} frame cost over ${ms.length} frames: mean ${mean.toFixed(3)} ms, p95 ${at(0.95).toFixed(3)} ms, worst ${(sorted.at(-1) ?? 0).toFixed(3)} ms (of 16.7 ms)`,
      `frames over ${UI_BUDGET_MS} ms: ${over.length ? over.join(', ') : 'none'}`,
    ].join('\n');
  };
const socialCostReadout = uiCostReadout('social UI');
const hudCostReadout = uiCostReadout('HUD');

/** Watches the beacon list over the clip that follows, frame by frame: its rows being built or taken out, its text being
 * rewritten (an age moving on) and its scrollbar and edge fades being written. */
async function socialRestWatch(page: Page): Promise<void> {
  await page.evaluate(() => {
    const w = window as unknown as { __clip: { frame(dt: number): void }; __uiCost: number[]; __rest: { rows: number[]; text: number[]; bar: number[] } };
    const scroller = document.querySelector('.sc-beacons') as HTMLElement;
    const watched = { rows: [] as number[], text: [] as number[], bar: [] as number[] };
    w.__rest = watched;
    const obs = new MutationObserver(() => {});
    obs.observe(scroller, { subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'class'] });
    const clip = w.__clip;
    const frame = clip.frame.bind(clip);
    let i = 0;
    clip.frame = (dt: number) => {
      frame(dt);
      const seen = { rows: false, text: false, bar: false };
      for (const r of obs.takeRecords()) {
        const t = r.target as HTMLElement;
        if (t === scroller && r.type === 'attributes' && r.attributeName === 'style') seen.bar = true;
        else if (r.type === 'childList' && t.classList.contains('sb-meta')) seen.text = true;
        else if (r.type === 'childList' || (r.type === 'attributes' && t.closest('.sb-list'))) seen.rows = true;
      }
      for (const k of ['rows', 'text', 'bar'] as const) if (seen[k]) watched[k].push(i);
      i++;
    };
  });
}

/** The cost readout and what the list did at rest: which frames rebuilt a row, rewrote an age or wrote a scrollbar or edge
 * property. */
async function socialRestReadout(page: Page): Promise<string> {
  const rest = await page.evaluate(() => (window as unknown as { __rest: { rows: number[]; text: number[]; bar: number[] } }).__rest);
  const list = (v: number[]) => (v.length ? `${v.length} (frames ${v.map((n) => String(n).padStart(3, '0')).join(', ')})` : 'none');
  return [
    await socialCostReadout(page),
    `beacon list at rest: rows rebuilt or restyled on ${list(rest.rows)}; age text rewritten on ${list(rest.text)}; scrollbar or edge property written on ${list(rest.bar)}`,
  ].join('\n');
}

export const SOCIAL_STAGE = String.raw`
import { Net } from '/src/net/Net.js';

const game = window.game;
const sockets = [];
const ME = 'Tess Arlo';
const ONLINE = ['Kestrel Vane', 'Bo Tran', 'Ilse Marr', 'Juno Reyes'];
const T0 = 5000;
const later = (fn) => setTimeout(fn, 0);

class FakeSocket {
  constructor(url) {
    this.url = url;
    this.readyState = 0;
    this.sent = [];
    sockets.push(this);
    later(() => {
      this.readyState = 1;
      if (this.onopen) this.onopen();
    });
  }
  send(text) {
    const m = JSON.parse(text);
    this.sent.push(m);
    later(() => stage.reply(m));
  }
  close() {
    this.readyState = 3;
  }
}

const stage = {
  net: null,
  socket: null,
  party: null,
  beacons: [],
  answerCode: 'far',
  raiseCode: 'no_phase',
  get social() {
    return game.hud.social;
  },
  get here() {
    return game.galaxy.current.id;
  },
  async start() {
    const net = new Net({ url: 'ws://capture/ws', token: 'capture', characterId: 'c-me', WebSocket: FakeSocket });
    this.net = net;
    this.social.attach(net);
    net.connect();
    await new Promise((r) => setTimeout(r, 30));
    this.socket = sockets[sockets.length - 1];
    const look = { palette: 0, pattern: 0, head: 0, suit: 0 };
    this.push({
      t: 'welcome',
      accountId: 'a-me',
      character: { id: 'c-me', name: ME, people: 'thalune', look, level: 7, homeSystem: this.here },
      entityId: 1,
      serverTime: T0,
      zone: { id: 'sys:' + this.here, systemSeed: game.system.seed },
      pose: { frame: null, pos: [0, 0, 0], quat: [0, 0, 0, 1], vel: [0, 0, 0] },
      mode: 'ship',
    });
    this.clear();
  },
  push(m) {
    this.socket.onmessage({ data: JSON.stringify(m) });
  },
  /** Forgets the log. */
  clear() {
    const m = this.social.model;
    m.lines.length = 0;
    this.social.rebuild = true;
    m.changed();
  },
  /** Moves every line in the log, and every invite, ms milliseconds into the past. */
  age(ms) {
    const m = this.social.model;
    for (const l of m.lines) l.at -= ms;
    for (const i of m.invites) {
      i.at -= ms;
      i.until -= ms;
    }
    this.social.rebuild = true;
    this.social.model.changed();
  },
  chat(channel, from, text) {
    this.push({ t: 'event', event: { kind: 'chat', channel, from, text, at: T0 } });
  },
  news(what, name) {
    this.push({ t: 'event', event: name ? { kind: 'party', what, name } : { kind: 'party', what } });
  },
  member(name, health = 10, system = this.here, online = true) {
    return { name, online, system: online ? system : null, health: online ? health : null };
  },
  setParty(leader, members) {
    this.party = members ? { leader, members } : null;
    this.push({ t: 'party', party: this.party });
  },
  open(tab) {
    this.social.open();
    if (tab) this.social.setTab(tab);
  },
  close() {
    this.social.close();
  },
  /** Types a line into the open panel and presses Enter in it. */
  type(text) {
    const input = this.social.input;
    input.value = text;
    input.dispatchEvent(new KeyboardEvent('keydown', { code: 'Enter', bubbles: true }));
  },
  /** The server's side of each request. */
  reply(m) {
    if (m.t === 'chat') return this.chat(m.channel, ME, m.text);
    if (m.t === 'party') {
      const op = m.op;
      const named = op.name && ONLINE.find((n) => n.toLowerCase() === op.name.toLowerCase());
      if (op.op === 'invite') return named ? this.news('invited', named) : this.push({ t: 'denied', of: 'invite', code: 'not_found', name: op.name });
      if (op.op === 'accept') {
        this.setParty(named, [this.member(named), this.member(ME), this.member('Bo Tran', 8)]);
        return this.news('joined', ME);
      }
      if (op.op === 'leave') {
        this.setParty(null);
        return this.news('left', ME);
      }
      if (op.op === 'promote' && this.party) {
        this.news('leader', named);
        return this.setParty(named, this.party.members);
      }
      if (op.op === 'kick' && this.party) {
        this.news('kicked', named);
        return this.setParty(this.party.leader, this.party.members.filter((x) => x.name !== named));
      }
      return;
    }
    if (m.t === 'beacon') {
      if (m.op.op === 'answer') return this.push({ t: 'denied', of: 'answer', code: this.answerCode });
      if (m.op.op === 'raise') return this.push({ t: 'denied', of: 'raise', code: this.raiseCode });
      if (m.op.op === 'watch') return this.push({ t: 'beacons', reset: true, beacons: this.beacons, gone: [] });
    }
  },

  // ---------- scenes ----------

  /** Several lines in each channel, the newest last. */
  chatScene() {
    const sys = game.system.name;
    this.chat('shard', 'Kestrel Vane', 'Convoy leaving ' + sys + ' in ten minutes, two escorts wanted');
    this.chat('system', 'Ilse Marr', 'Pirate wing over the north pole, keep clear of it');
    this.chat('shard', 'Juno Reyes', 'Saw a Hollow drifter past the third moon. Nobody aboard.');
    this.chat('party', 'Kestrel Vane', 'Regroup at pad three when you can');
    this.chat('system', 'Bo Tran', 'Waystation traffic is heavy tonight');
    this.chat('shard', 'Bo Tran', 'Anyone selling cobalt near the belt?');
    this.chat('party', 'Bo Tran', 'Hull at thirty percent, give me a minute');
    this.chat('system', 'Juno Reyes', 'Storm front rolling over the southern sea');
    this.chat('shard', ME, 'Heading for the Waystation now');
    this.chat('party', ME, 'Covering you, take your time');
    this.chat('shard', 'Ilse Marr', 'Selling frostglass at the ' + sys + ' board, fair prices');
    this.chat('system', 'Kestrel Vane', 'Docking queue at the Waystation is clear again');
    this.chat('party', 'Ilse Marr', 'Two jumps out, back within the hour');
  },
  /** Four in the party: the leader, the player, one hurt badly, one in another system. */
  partyScene(leader = 'Kestrel Vane') {
    const elsewhere = game.galaxy.systems.find((s) => s.id !== this.here).id;
    this.setParty(leader, [this.member('Kestrel Vane'), this.member(ME), this.member('Bo Tran', 2), this.member('Ilse Marr', 7, elsewhere)]);
  },
  /** Eight calls for aid, more than the panel shows: the three, and five more here and elsewhere. */
  manyBeaconsScene() {
    this.beaconsScene();
    const seed = game.system.seed;
    const others = game.galaxy.systems.filter((s) => s.id !== this.here).slice(0, 3).map((s) => s.id);
    const b = (id, kind, place, from, open, cap, ago, system, frame) =>
      ({ id, kind, system, frame, center: [0, 0, 0], radius: 600, place, from, open, cap, at: T0 - ago, until: T0 - ago + 600 });
    this.beacons = this.beacons.concat([
      b(15, 'event', 'Pirate Convoy Ambush', 'Juno Reyes', 9, 12, 75, this.here, seed + ':station'),
      b(16, 'story', 'Signal in the Static', 'Kestrel Vane', 5, 6, 210, others[0], seed + ':0'),
      b(17, 'raid', 'The Hive Heart', 'Ilse Marr', 6, 12, 300, others[1], seed + ':0'),
      b(18, 'event', 'Stone-touched Herd', 'Bo Tran', 10, 12, 450, others[2], seed + ':0'),
      b(19, 'story', 'Adrift', 'Juno Reyes', 3, 6, 520, this.here, seed + ':station'),
    ]);
    this.push({ t: 'beacons', reset: true, beacons: this.beacons, gone: [] });
  },
  /** Three calls for aid: a raid at the Waystation and a story chapter in this system, an event in another. */
  beaconsScene() {
    const seed = game.system.seed;
    const elsewhere = game.galaxy.systems.find((s) => s.id !== this.here).id;
    // (the story chapter on the ground below the ship, the raid round the Waystation)
    const home = game.system.homePlanet;
    const st = game.ship.state;
    const below = st.frame === home ? st.pos.clone().normalize().multiplyScalar(home.radius).toArray() : [0, 0, 0];
    const b = (id, kind, place, from, open, cap, ago, extra) =>
      Object.assign({ id, kind, system: this.here, frame: seed + ':station', center: [0, 0, 0], radius: 400, place, from, open, cap, at: T0 - ago, until: T0 - ago + 600 }, extra);
    this.beacons = [
      b(12, 'raid', 'Raid on the Waystation', 'Kestrel Vane', 3, 12, 130, {}),
      b(13, 'story', 'The Missing', 'Ilse Marr', 4, 6, 380, { frame: seed + ':' + game.system.planets.indexOf(home), center: below, radius: 2000 }),
      b(14, 'event', 'Ferrite Wreck', 'Bo Tran', 7, 12, 40, { system: elsewhere }),
    ];
    this.push({ t: 'beacons', reset: true, beacons: this.beacons, gone: [] });
  },
};
window.__social = stage;
`;

/** What the captures reach of the stage. */
interface SocialStage {
  start(): Promise<void>;
  clear(): void;
  age(ms: number): void;
  chat(channel: string, from: string, text: string): void;
  news(what: string, name?: string): void;
  setParty(leader: string | null, members?: unknown[]): void;
  open(tab?: string): void;
  close(): void;
  type(text: string): void;
  chatScene(): void;
  partyScene(leader?: string): void;
  beaconsScene(): void;
  answerCode: string;
  social: { model: { answer(id: number): void; submit(text: string): unknown; mutedUntil: number }; update(): void };
}
interface Vec {
  clone(): Vec;
  set(x: number, y: number, z: number): Vec;
}
interface Quat {
  clone(): Quat;
  multiply(q: Quat): Quat;
  setFromAxisAngle(axis: Vec, angle: number): Quat;
}
interface SocialWindow {
  __social: SocialStage;
  dev: { boot(): Promise<void> };
  game: {
    system: { homePlanet: unknown };
    debugGoto(planet: unknown, o: object): void;
    ship: { state: { pos: Vec; quat: Quat } };
    hud: { later(fn: () => void, ms: number): number; clearBanners(): void };
  };
}

/** Boots the sandbox, puts the camera where `view` says (`limb`: low over the sunlit home world, the bright ground behind
 * the chat panel; `space`: the default start by the Waystation, dark sky behind the panel), and starts the stage. */
async function stageSocial(page: Page, view: 'limb' | 'space'): Promise<void> {
  await page.evaluate(() => (window as unknown as SocialWindow).dev.boot());
  // (no named functions in the page code: tsx would wrap them in a helper the page does not have)
  await page.evaluate((view) => {
    const g = (window as unknown as SocialWindow).game;
    const p = g.system.homePlanet as { radius: number };
    // limb: 0.2 radii up in the morning sun, nose down 24°, so the sunlit disc fills the lower half and its limb crosses
    // the picture above the chat panel; space: the start by the Waystation, nose up 43° to the dark sky
    if (view === 'limb') g.debugGoto(p, { sunAngle: 35, alt: p.radius * 0.2, azimuth: 40, land: false });
    const s = g.ship.state;
    s.quat.multiply(s.quat.clone().setFromAxisAngle(s.pos.clone().set(1, 0, 0), view === 'limb' ? -0.42 : 0.75));
  }, view);
  await settle(page, 120);
  await page.evaluate(() => (window as unknown as SocialWindow).game.hud.clearBanners());
  await page.addScriptTag({ type: 'module', content: SOCIAL_STAGE });
  await page.waitForFunction(() => !!(window as unknown as SocialWindow).__social);
  await page.evaluate(() => (window as unknown as SocialWindow).__social.start());
}

/** Runs `fn` on the stage in the page and lets the HUD draw it. */
async function onStage(page: Page, fn: string, frames = 30): Promise<void> {
  await page.evaluate(`(async () => { const s = window.__social; ${fn}; })()`);
  await settle(page, frames);
}

// ---------- the sign-in and character screens (P1.E04.T05) ----------
// Hermetic: the gateway's answers are recorded here and served by the page's own routes (no game server runs), and the
// game socket is answered in the page too: silent (the entering step waits on it), or a welcome after a while.

const ACCOUNT_ID = '5d0c2b7e-8a41-4c39-9f0e-2b6f1d7c9a10';
/** A session token shaped as the server's (only its expiry is read by the client), good until 2100. */
const TOKEN = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${Buffer.from(JSON.stringify({ sub: ACCOUNT_ID, exp: 4102444800 })).toString('base64url')}.capture`;
const LOOK = { palette: 0, pattern: 0, head: 0, suit: 0 };
const homeOf = (people: string) => homeSystems(GALAXY_SEED).find((h) => h.people === people)!.systemIndex;
const CHARACTERS = [
  { id: '0b6e4f1a-3c2d-4e5f-8a9b-1c2d3e4f5a61', name: 'Tess Arlo', people: 'thalune', look: LOOK, level: 7, homeSystem: homeOf('thalune') },
  { id: '0b6e4f1a-3c2d-4e5f-8a9b-1c2d3e4f5a62', name: 'Quill Ventrasse', people: 'ixari', look: LOOK, level: 3, homeSystem: homeOf('ixari') },
  { id: '0b6e4f1a-3c2d-4e5f-8a9b-1c2d3e4f5a63', name: 'Odo Marrow-Kell', people: 'ulgani', look: LOOK, level: 12, homeSystem: homeOf('ulgani') },
];
const NEW_ID = '0b6e4f1a-3c2d-4e5f-8a9b-1c2d3e4f5a64';
/** A full account: the three above and three more, six of six. */
const SIX = [
  ...CHARACTERS,
  { id: '0b6e4f1a-3c2d-4e5f-8a9b-1c2d3e4f5a65', name: 'Mira Okonta', people: 'thalune', look: LOOK, level: 22, homeSystem: homeOf('thalune') },
  { id: '0b6e4f1a-3c2d-4e5f-8a9b-1c2d3e4f5a66', name: 'Sefa Lune', people: 'ixari', look: LOOK, level: 15, homeSystem: homeOf('ixari') },
  { id: '0b6e4f1a-3c2d-4e5f-8a9b-1c2d3e4f5a67', name: "Bram O'Hollow", people: 'ulgani', look: LOOK, level: 9, homeSystem: homeOf('ulgani') },
];
/** What the browser logs for the wrong password, and the taken username, these screens send on purpose. */
const REFUSED_SIGN_IN = /Failed to load resource: the server responded with a status of 401/;
const REFUSED_SIGN_UP = /Failed to load resource: the server responded with a status of 409/;

interface AccountServer {
  /** Sign-ins the server refuses before it takes one (a wrong password). */
  refuseLogins?: number;
  /** How long each answer takes, ms of real time (the clip runs animations ten times slower). */
  delayMs?: number;
  /** The game socket: silent, or a welcome this long (real ms) after the join. */
  welcomeAfterMs?: number | null;
  /** The account's characters (by default the three above). */
  characters?: typeof CHARACTERS;
  /** Usernames another account holds: signing up as one is refused. */
  taken?: string[];
}

/** Serves the account screens' requests from the recorded answers above, and the game socket in the page. */
async function serveAccount(
  page: Page,
  { refuseLogins = 0, delayMs = 0, welcomeAfterMs = null, characters = CHARACTERS, taken = [] }: AccountServer = {},
): Promise<void> {
  const later = () => new Promise((r) => setTimeout(r, delayMs));
  let refused = 0;
  const made: typeof CHARACTERS = [];
  await page.route('**/auth/login', async (route) => {
    await later();
    if (refused++ < refuseLogins) await route.fulfill({ status: 401, json: { error: 'login_failed', message: 'Wrong username or password.' } });
    else await route.fulfill({ status: 200, json: { token: TOKEN, accountId: ACCOUNT_ID } });
  });
  await page.route('**/auth/register', async (route) => {
    await later();
    const body = route.request().postDataJSON() as { username: string };
    if (taken.includes(body.username.toLowerCase()))
      await route.fulfill({ status: 409, json: { error: 'username_taken', message: 'That username is taken.' } });
    else await route.fulfill({ status: 201, json: { token: TOKEN, accountId: ACCOUNT_ID } });
  });
  await page.route('**/characters', async (route) => {
    await later();
    if (route.request().method() === 'POST') {
      const body = route.request().postDataJSON() as { name: string; people: string };
      const c = { id: NEW_ID, name: body.name, people: body.people, look: LOOK, level: 1, homeSystem: homeOf(body.people) };
      made.push(c);
      await route.fulfill({ status: 201, json: c });
    } else await route.fulfill({ status: 200, json: { characters: [...characters, ...made], max: 6 } });
  });
  const galaxy = new Galaxy(GALAXY_SEED);
  await page.routeWebSocket(/\/ws$/, (ws) => {
    ws.onMessage((raw) => {
      const m = JSON.parse(String(raw)) as { t: string; characterId?: string };
      if (m.t !== 'join' || welcomeAfterMs === null) return;
      const character = [...characters, ...made].find((c) => c.id === m.characterId)!;
      const seed = galaxy.systems[character.homeSystem]!.seed;
      const welcome = {
        t: 'welcome',
        accountId: ACCOUNT_ID,
        character,
        entityId: 7,
        serverTime: 3.15e7,
        zone: { id: `sys:${character.homeSystem}`, systemSeed: seed },
        // docked on a hangar pad of its home Waystation, as a new character starts
        pose: { frame: `${seed}:station`, pos: [30, 2.4, 22], quat: [0, 0, 0, 1], vel: [0, 0, 0] },
        mode: 'docked',
      };
      setTimeout(() => ws.send(JSON.stringify(welcome)), welcomeAfterMs);
    });
  });
}

/** The title, ready to play, Play focused (as the title leaves it), the HUD's audio off. */
async function titleReady(page: Page): Promise<void> {
  await page.evaluate(() => {
    (window as unknown as { game: { audio: { start(): void } } }).game.audio.start = () => {};
  });
  await page.waitForFunction(async () => {
    await (window as unknown as { step(n: number): Promise<void> }).step(2);
    const b = document.querySelector<HTMLButtonElement>('.title-screen [data-act="start"]');
    return !!b && !b.disabled;
  });
  await settle(page, 30);
  await page.waitForTimeout(2500);
  await page.focus('.title-screen [data-act="start"]');
}

/** Steps a few frames and waits out the flow's CSS (it runs on real time outside a clip). */
async function settleFlow(page: Page, ms = 1600): Promise<void> {
  await settle(page, 10);
  await page.waitForTimeout(ms);
}

/** Play → sign in as tess_arlo (`password`) → Enter. */
async function signIn(page: Page, password: string): Promise<void> {
  await page.keyboard.press('Enter');
  await page.waitForSelector('.acct [data-form="signin"] input[name="username"]');
  await page.waitForTimeout(400);
  await page.keyboard.type('tess_arlo');
  await page.keyboard.press('Tab');
  await page.keyboard.type(password);
  await page.keyboard.press('Enter');
}

/** Back to the title as a new browser would show it: signed out, the flow closed, nothing typed, Play focused. */
async function resetFlow(page: Page, settleMs = 800): Promise<void> {
  await page.evaluate(() => {
    const flow = (window as unknown as { game: { menus: { account: { flow: { close(): void; set(p: object): void } } } } }).game.menus.account.flow;
    sessionStorage.removeItem('astra-session');
    flow.close();
    flow.set({ username: '' });
  });
  await page.waitForTimeout(settleMs);
  await page.focus('.title-screen [data-act="start"]');
}

/** The mouse captured, as a player's click grants it (headless Chromium refuses the real pointer lock: the game's own
 * fallback), so the world shows without the pause menu. */
async function grantLock(page: Page): Promise<void> {
  await page.evaluate(() => {
    const input = (window as unknown as { game: { input: { fallbackLock: boolean; locked: boolean } } }).game.input;
    input.fallbackLock = true;
    input.locked = true;
    document.dispatchEvent(new Event('pointerlockchange'));
  });
}

/** Play → Create an account → `username` and a password → Enter. */
async function signUpAs(page: Page, username: string): Promise<void> {
  await page.keyboard.press('Enter');
  await page.click('.acct [data-form="signin"] [data-do="to-register"]');
  await page.waitForSelector('.acct [data-form="register"] input[name="username"]');
  await page.waitForTimeout(400);
  await page.keyboard.type(username);
  await page.keyboard.press('Tab');
  await page.keyboard.type('correct-horse');
  await page.keyboard.press('Enter');
}

/** Runs `steps` in the background, each `at` seconds of clip time in (the clip slows the page's animations tenfold, so
 * a clip second is ten real ones): the page is driven as a player drives it, by keys, while the frames are taken. */
function timeline(page: Page, steps: [number, () => Promise<unknown>][]): void {
  const t0 = Date.now();
  void (async () => {
    for (const [at, run] of steps) {
      const wait = t0 + at * 10_000 - Date.now();
      if (wait > 0) await new Promise((r) => setTimeout(r, wait));
      await run();
    }
  })().catch((e) => console.error(`clip timeline: ${e instanceof Error ? e.message : e}`));
}

/** Types as a player does in the clip: `perChar` seconds of clip time a letter. */
const typeIn = (page: Page, text: string, perChar = 0.045) => page.keyboard.type(text, { delay: perChar * 10_000 });
const key = (page: Page, k: string) => () => page.keyboard.press(k);

interface EventPage {
  game: {
    mode: string;
    system: { name: string; homePlanet: unknown };
    station: unknown;
    debugGoto(planet: unknown, at: { sunAngle: number; alt: number; azimuth: number }): void;
    boardShip(): void;
    exitShip(): void;
    player: { pitch: number; heading: { applyAxisAngle(axis: unknown, angle: number): void }; state: { pos: { clone(): { normalize(): unknown } } } };
    hud: {
      clearBanners(): void;
      showBanner(title: string, sub: string): void;
      updateEvents(feed: unknown): void;
      banners: { until: number };
      now(): number;
      band: HTMLElement;
    };
  };
}

/** On foot on the home world (the `#foot` scenario), back aboard and landed again with the sun `sunAngle` degrees from
 * overhead (past 90 it is night), then out, looking along open ground and down a little, so the ground lies behind the
 * HUD's top band. */
function eventGround(sunAngle: number) {
  return async (page: Page) => {
    const onFoot = () =>
      page.waitForFunction(async () => {
        await (window as unknown as { step(n: number): Promise<void> }).step(4);
        return (window as unknown as EventPage).game.mode === 'foot';
      });
    await onFoot();
    // (the scenario lands and steps out on real-time waits: let it finish before landing again)
    await page.waitForTimeout(2500);
    await onFoot();
    await page.evaluate((sunAngle) => {
      const g = (window as unknown as EventPage).game;
      g.boardShip();
      g.debugGoto(g.system.homePlanet, { sunAngle, alt: 0, azimuth: 20 });
    }, sunAngle);
    await settle(page, 60);
    await page.evaluate(() => (window as unknown as EventPage).game.exitShip());
    await onFoot();
    await page.evaluate(() => {
      const { player } = (window as unknown as EventPage).game;
      player.heading.applyAxisAngle(player.state.pos.clone().normalize(), Math.PI * 1.5);
      player.pitch = -0.5;
    });
    // (stepping out blends the view down to the pilot's eyes over 4 s)
    await settle(page, 300);
  };
}

/** The catalog's event announced to the system two minutes before it starts (protocol 17, ARCHITECTURE §26): its news
 * handed to the client's own feed (net/worldEvents.js), and the feed's banner to the HUD, as a connection's would be.
 * It is on the home world, which the feed names as the game does. A banner showing is cleared first, unless `queued`:
 * then the system's own arrival banner is raised first, as Game.js raises it on entry, and the event's waits behind it. */
async function announceEvent(page: Page, queued = false): Promise<void> {
  const def = EVENTS[0]!;
  // (tsx names the stub's functions with esbuild's __name helper, which the page lacks)
  await page.evaluate('window.__name ??= (f) => f');
  await page.evaluate(
    async ({ url, poseUrl, def, queued }) => {
      const { WorldEvents } = await import(/* @vite-ignore */ url);
      const { frameIdOfFrame, frameOfId } = await import(/* @vite-ignore */ poseUrl);
      const { game } = window as unknown as EventPage;
      const frame = frameIdOfFrame(game.system, game.station, game.system.homePlanet);
      const event = {
        id: 1,
        event: def.id,
        name: def.name,
        system: 0,
        frame,
        center: [0, 0, 0],
        radius: def.radius,
        starts: def.announceS,
        ends: def.announceS + def.durationS,
      };
      const on: Record<string, (m: unknown) => void> = {};
      const feed = new WorldEvents({ on: (t: string, fn: (m: unknown) => void) => (on[t] = fn), serverTime: () => 0 });
      feed.worldName = (f: string) => frameOfId(game.system, game.station, f)?.name ?? null;
      on.world_event!({ t: 'world_event', op: 'announced', event });
      const { hud } = game;
      if (queued) hud.showBanner(game.system.name.toUpperCase(), 'Star System');
      else {
        // (the band that held the still goes at once, so the clip's band darkens in with the text)
        hud.band.style.transition = 'none';
        hud.clearBanners();
        void hud.band.offsetWidth;
        hud.band.style.transition = '';
      }
      hud.updateEvents(feed);
    },
    {
      url: '/src/net/worldEvents.js',
      poseUrl: '/src/net/pose.js',
      def: { id: def.id, name: def.name, radius: def.place.radius, announceS: def.schedule.announceS, durationS: def.schedule.durationS },
      queued,
    },
  );
}

/** A world event's banner (P2.E21.T01): the stills with it fully in; the clip from its news, in, held and out. */
function eventBannerScreen(sunAngle: number): ScreenDef {
  return {
    hash: '#foot',
    hudClock: true,
    clipSeconds: 7.5,
    // its fade in (every 6 frames), the hold, its fade out (every 14)
    sheetFrames: [0, 6, 12, 18, 24, 30, 36, 42, 48, 120, 200, 280, 336, 350, 364, 378, 392, 406, 420, 449],
    async open(page) {
      await eventGround(sunAngle)(page);
      await announceEvent(page);
      await page.waitForTimeout(2000);
    },
    motion: (page) => announceEvent(page),
  };
}

/** The same banner reached the way a player entering a system during an event gets it (P2.E21.T01, visual round 1): the
 * system's own arrival banner first, the event's queued behind it, no clearBanners between. The clip runs from the
 * arrival banner fading in until the event's is fully in; its sheet takes a frame every 6 across the hand-off. */
function eventBannerQueuedScreen(): ScreenDef {
  return {
    hash: '#foot',
    hudClock: true,
    clipSeconds: 14,
    // the arrival banner in and held (every 60), its fade out through the event banner's fade in (every 6), the event banner held
    sheetFrames: [0, 30, 60, 120, 180, 240, 300, ...Array.from({ length: 27 }, (_, i) => 330 + i * 6), 500, 600, 720, 839],
    async open(page) {
      await eventGround(40)(page);
      // (the scenario's own arrival banner has run its life by now; wait for any that has not, so the clip starts bare)
      await page.waitForFunction(() => {
        const { hud } = (window as unknown as EventPage).game;
        return hud.banners.until <= hud.now();
      });
      await page.evaluate(() => (window as unknown as EventPage).game.hud.clearBanners());
      await page.waitForTimeout(1500);
    },
    motion: (page) => announceEvent(page, true),
  };
}

// ---------- the Edge following the Count (P2.E22.T02) ----------
// The offline sandbox has no world service, so the capture hands the game the `world` message the server would send for a
// Count, built by the same functions the server uses (edgeAt, galaxyTiers), and the map and the sky draw the Edge from it.

interface EdgeWindow {
  game: {
    net: unknown;
    galaxy: { systems: { id: number; x: number; y: number; z: number }[]; here: { x: number; y: number; z: number } };
    menus: { openMap(): void; setMapTab(tab: string): void; mapView: EdgeMapView };
    universe: { leave(): void; anchor: { set(x: number, y: number, z: number): void } };
    ship: { state: { frame: unknown; pos: { set(x: number, y: number, z: number): void }; quat: { set(x: number, y: number, z: number, w: number): void } } };
    cam: { frame: unknown };
    hud: { clearBanners(): void };
    sky: { reset(): void };
  };
  dev: { boot(): Promise<void> };
  __clip: { frame(dt: number): void };
}
interface EdgeMapView {
  fly: unknown;
  selected: unknown;
  items: { kind: string; sys?: { id: number } }[];
  select(it: unknown): void;
  camera: { position: { set(x: number, y: number, z: number): void } };
  controls: { target: { set(x: number, y: number, z: number): void } };
}

type Opening = 'fed' | 'held' | 'broken' | null;

/** The `world` message for the Count at `count` in the season whose opening is `from` (null: the baseline). */
function worldAtCount(count: number, from: Opening = null) {
  const opening = seasonOpening(from, 5);
  const edgeX = edgeAt(count, opening);
  return {
    t: 'world',
    season: 5,
    seasonStart: 0,
    seasonEnd: 4_838_400,
    opening,
    count,
    edgeX,
    tiers: galaxyTiers(edgeX).map((t) => t.tier),
    dark: [...darkAt(count, opening)],
    serverTime: 1000,
  };
}

/** Hands the page the `world` message the server would send. The game reads it from its connection (`net.world`), and the
 * offline sandbox has none, so the client's own Net, never connected, stands in. */
async function handWorld(page: Page, world: unknown): Promise<void> {
  await page.evaluate(async (world) => {
    const g = (window as unknown as EdgeWindow).game;
    if (!g.net) {
      const module = '/src/net/Net.js';
      const { Net } = await import(/* @vite-ignore */ module);
      g.net = new Net({ url: 'ws://offline.invalid/', token: '', characterId: '' });
    }
    (g.net as { world: unknown }).world = world;
  }, world);
}

/** Hands the page a `world` message for the Count and lets the map and the sky draw it. */
async function setCount(page: Page, count: number, from: Opening = null): Promise<void> {
  await handWorld(page, worldAtCount(count, from));
  await settle(page, 12);
  await clearBanner(page);
}

/** Takes the system banner (staging leaves one up) off the screen before a still: dropped, and given its fade out. */
async function clearBanner(page: Page): Promise<void> {
  await page.evaluate(() => (window as unknown as EdgeWindow).game.hud.clearBanners());
  await page.waitForTimeout(700);
}

/** The galaxy map from the side, the cluster to the left and the wall a little right of the middle, so a wall that moves a few
 * hundred thousand ly is seen to move across the frame. */
async function openEdgeMap(page: Page, count: number): Promise<void> {
  await page.evaluate(() => (window as unknown as EdgeWindow).dev.boot());
  await handWorld(page, worldAtCount(count));
  await page.evaluate(
    ({ at }) => {
      const w = window as unknown as EdgeWindow;
      w.game.menus.openMap();
      w.game.menus.setMapTab('galaxy');
      const v = w.game.menus.mapView;
      v.fly = null;
      v.controls.target.set(at - 1.5e6, 0, 0);
      v.camera.position.set(at - 1.5e6, 8e5, 3.6e6);
    },
    { at: EDGE_X },
  );
  await settle(page, 60);
}

/** The galaxy map at cluster zoom in a season opened Broken, with the Count at `count`: the whole cluster in frame, from above and
 * a little to the side, its dark Waystations marked. */
async function openDarkMap(page: Page, count: number): Promise<void> {
  await page.evaluate(() => (window as unknown as EdgeWindow).dev.boot());
  await handWorld(page, worldAtCount(count, 'broken'));
  await page.evaluate(() => {
    const w = window as unknown as EdgeWindow;
    w.game.menus.openMap();
    w.game.menus.setMapTab('galaxy');
    const v = w.game.menus.mapView;
    v.fly = null;
    const sys = w.game.galaxy.systems;
    const c = { x: 0, y: 0, z: 0 };
    for (const s of sys) {
      c.x += s.x / sys.length;
      c.y += s.y / sys.length;
      c.z += s.z / sys.length;
    }
    v.controls.target.set(c.x, c.y, c.z);
    v.camera.position.set(c.x - 70, c.y + 105, c.z + 120);
  });
  await settle(page, 60);
}

/** Selects the system `id`, or the Edge (`edge`), as a click would, so the map's info panel shows it. */
async function selectOnMap(page: Page, pick: { system: number } | { edge: true } | null): Promise<void> {
  await page.evaluate((pick) => {
    const v = (window as unknown as EdgeWindow).game.menus.mapView;
    v.select(
      pick === null
        ? null
        : 'system' in pick
          ? v.items.find((it) => it.kind === 'system' && it.sys?.id === pick.system)
          : v.items.find((it) => it.kind === 'edge'),
    );
  }, pick);
  await settle(page, 12);
}

/** The sky from deep space 1.2 million ly short of the wall's baseline, the ship nose to +X, the Waystation's system left
 * far behind. */
async function openEdgeSky(page: Page, count: number): Promise<void> {
  await page.evaluate(() => (window as unknown as EdgeWindow).dev.boot());
  await handWorld(page, worldAtCount(count));
  await page.evaluate(
    ({ at }) => {
      const w = window as unknown as EdgeWindow;
      const g = w.game;
      g.ship.state.frame = null;
      g.ship.state.pos.set(0, 0, 0);
      g.ship.state.quat.set(0, -Math.SQRT1_2, 0, Math.SQRT1_2);
      g.cam.frame = undefined;
      g.universe.leave();
      g.universe.anchor.set(at - 1.2e6, 0, 0);
      g.sky.reset();
    },
    { at: EDGE_X },
  );
  await settle(page, 90);
  await clearBanner(page);
}

/** The clip's frames, each handing the page the world for the Count a frame later (0 to 1000, and there and back). The first
 * world is in and drawn before the first frame is taken, so the clip starts on the Count it sweeps from, not on the last still's. */
async function sweepCount(page: Page, frames: number, from: Opening = null, deselect = false): Promise<void> {
  const worlds = Array.from({ length: frames }, (_, i) => {
    const t = i / (frames - 1);
    return worldAtCount(Math.round(1000 * (t < 0.5 ? t * 2 : 2 - t * 2)), from);
  });
  await handWorld(page, worlds[0]);
  if (deselect) await selectOnMap(page, null);
  // (the clip's frame loop has taken over `step` by now, so its own frames draw it: the sky takes a face a frame, and the clip
  // must not start on the picture before)
  await page.evaluate(() => {
    const w = window as unknown as EdgeWindow & { game: { sky: { face: number; edgeAt: number; drawnEdge: number } } };
    for (let i = 0; i < 90 && (i < 12 || w.game.sky.face >= 0 || w.game.sky.edgeAt !== w.game.sky.drawnEdge); i++) w.__clip.frame(1 / 60);
  });
  await page.evaluate((worlds) => {
    const w = window as unknown as EdgeWindow;
    const frame = w.__clip.frame.bind(w.__clip);
    let i = 0;
    w.__clip.frame = (dt) => {
      (w.game.net as { world: unknown }).world = worlds[Math.min(i++, worlds.length - 1)];
      frame(dt);
    };
  }, worlds);
}

export const SCREENS: Record<string, ScreenDef> = {
  title: {
    // the menu's sunrise runs 3 s after a 0.6 s delay (style.css .title-screen)
    clipSeconds: 3.6,
    async open(page) {
      await page.waitForFunction(async () => {
        await (window as unknown as { step(n: number): Promise<void> }).step(2);
        const b = document.querySelector<HTMLButtonElement>('.title-screen [data-act="start"]');
        return !!b && !b.disabled;
      });
      await settle(page, 30);
      // the menu fades in on CSS transitions, which run on real time
      await page.waitForTimeout(2500);
    },
    async motion(page) {
      // replay the title's fade-in: restart every CSS animation in the title screen
      await page.evaluate(() => {
        const el = document.querySelector<HTMLElement>('.title-screen');
        for (const a of el?.getAnimations({ subtree: true }) ?? []) {
          a.cancel();
          a.play();
        }
      });
    },
  },
  // The sign-in and character screens (P1.E04.T05), each still on its step, each clip its motion. `login-error`: a wrong
  // password refused (the clip: back to the title, Play, the password retyped and refused again).
  'login-error': {
    clipSeconds: 2.6,
    expectedErrors: [REFUSED_SIGN_IN],
    async open(page) {
      await serveAccount(page, { refuseLogins: 99, delayMs: 300 });
      await titleReady(page);
      await signIn(page, 'not-my-password');
      await page.waitForSelector('.acct-msgwrap.on');
      await settleFlow(page);
    },
    async motion(page) {
      timeline(page, [
        [0.05, key(page, 'Escape')],
        [0.55, key(page, 'Enter')],
        [1.25, () => typeIn(page, 'still-wrong', 0.035)],
        [1.8, key(page, 'Enter')],
      ]);
    },
  },
  // `register`: a fresh account, its first username refused as taken, landed on its empty character list (a still of the
  // refusal too, 16x9-refused.png; the clip: the whole sign-up from the title, by keyboard but the one link)
  register: {
    clipSeconds: 6.2,
    expectedErrors: [REFUSED_SIGN_UP],
    async open(page) {
      await serveAccount(page, { characters: [], taken: ['tess_arlo'], delayMs: 3000 });
      await titleReady(page);
      await signUpAs(page, 'tess_arlo');
      await page.waitForSelector('.acct-msgwrap.on');
      await page.waitForTimeout(600);
      await page.keyboard.type('ilya_sarn');
      await page.keyboard.press('Tab');
      await page.keyboard.type('correct-horse');
      await page.keyboard.press('Enter');
      await page.waitForSelector('.acct-step:not(.leaving) .acct-list [data-do="new"]');
      await settleFlow(page);
    },
    stills16x9: {
      async refused(page) {
        await resetFlow(page);
        await signUpAs(page, 'tess_arlo');
        await page.waitForSelector('.acct-msgwrap.on');
        await settleFlow(page);
      },
    },
    async motion(page) {
      // (the clip slows the page's animations tenfold already: the title has a while to come back before the first frame)
      await resetFlow(page, 7000);
      timeline(page, [
        [0.3, key(page, 'Enter')],
        [1.0, () => page.click('.acct [data-form="signin"] [data-do="to-register"]')],
        [1.6, () => typeIn(page, 'tess_arlo')],
        [2.1, key(page, 'Tab')],
        [2.2, () => typeIn(page, 'correct-horse', 0.03)],
        [2.7, key(page, 'Enter')],
        [3.6, () => typeIn(page, 'ilya_sarn')],
        [4.1, key(page, 'Tab')],
        [4.2, () => typeIn(page, 'correct-horse', 0.03)],
        [4.7, key(page, 'Enter')],
      ]);
    },
  },
  // `characters`: the account's three, one of each people (the clip: the list loading and rising in, the arrows walking it)
  characters: {
    clipSeconds: 2.6,
    async open(page) {
      await serveAccount(page, { delayMs: 300 });
      await titleReady(page);
      await signIn(page, 'correct-horse');
      await page.waitForSelector('.acct-char[data-id]');
      await settleFlow(page);
    },
    async motion(page) {
      timeline(page, [
        [0.05, key(page, 'Escape')],
        [0.55, key(page, 'Enter')],
        [1.7, key(page, 'ArrowDown')],
        [2.05, key(page, 'ArrowDown')],
      ]);
    },
  },
  // `characters-full`: an account at six of six, New character disabled (the clip: the picked row moving down two and
  // back one, its bar, indent and tint easing together)
  'characters-full': {
    clipSeconds: 1.6,
    async open(page) {
      await serveAccount(page, { characters: SIX });
      await titleReady(page);
      await signIn(page, 'correct-horse');
      await page.waitForSelector('.acct-step:not(.leaving) .acct-char[data-id]');
      await settleFlow(page);
    },
    async motion(page) {
      timeline(page, [
        [0.05, key(page, 'ArrowDown')],
        [0.5, key(page, 'ArrowDown')],
        [1.0, key(page, 'ArrowUp')],
      ]);
    },
  },
  // `create`: a new character named, the Ixari picked and opened on its body, home and saying (the clip: down to the
  // Ulgani and back)
  create: {
    clipSeconds: 1.6,
    async open(page) {
      await serveAccount(page);
      await titleReady(page);
      await signIn(page, 'correct-horse');
      await page.waitForSelector('.acct-char[data-id]');
      await page.waitForTimeout(800);
      await page.keyboard.press('n');
      await page.waitForSelector('.acct [data-form="create"] input[name="name"]');
      await page.waitForTimeout(400);
      await page.keyboard.type('Ilya Sarn');
      await page.keyboard.press('ArrowDown');
      await settleFlow(page);
    },
    async motion(page) {
      timeline(page, [
        [0.05, key(page, 'ArrowDown')],
        [0.8, key(page, 'ArrowUp')],
      ]);
    },
  },
  // `entering`: the character picked, the game socket open and the welcome not yet in (the clip: Esc back to the list,
  // and Enter again)
  entering: {
    clipSeconds: 1.8,
    async open(page) {
      await serveAccount(page);
      await titleReady(page);
      await signIn(page, 'correct-horse');
      await page.waitForSelector('.acct-char[data-id]');
      await page.waitForTimeout(800);
      await page.keyboard.press('Enter');
      await page.waitForSelector('.acct-step[data-step="entering"]');
      await settleFlow(page);
    },
    async motion(page) {
      timeline(page, [
        [0.05, key(page, 'Escape')],
        [0.75, key(page, 'Enter')],
      ]);
    },
  },
  // `account-flow`: the whole of it by keyboard, the still the title it starts from; the clip: Play, a sign-in refused and
  // retried, the list, a new character named and its people picked, made, entered, and the welcome's cut into the world
  'account-flow': {
    clipSeconds: 13,
    expectedErrors: [REFUSED_SIGN_IN],
    sheetFrames: [
      0, 30, 60, 84, 108, 126, 138, 150, 174, 204, 228, 252, 276, 300, 330, 354, 378, 402, 432, 462, 492, 522, 546, 570, 596, 604, 612, 620, 628, 636, 644, 660,
      680, 700, 720, 750, 779,
    ],
    async open(page) {
      await serveAccount(page, { refuseLogins: 1, delayMs: 3000, welcomeAfterMs: 14_000 });
      await titleReady(page);
    },
    async motion(page) {
      timeline(page, [
        [0.3, key(page, 'Enter')],
        [0.9, () => typeIn(page, 'tess_arlo')],
        [1.4, key(page, 'Tab')],
        [1.5, () => typeIn(page, 'wrong-pass', 0.03)],
        [1.9, key(page, 'Enter')],
        [2.8, () => typeIn(page, 'correct-horse', 0.03)],
        [3.3, key(page, 'Enter')],
        [4.9, key(page, 'ArrowDown')],
        [5.2, key(page, 'ArrowDown')],
        [5.6, key(page, 'n')],
        [6.2, () => typeIn(page, 'Ilya Sarn')],
        [6.8, key(page, 'ArrowDown')],
        [7.5, key(page, 'Enter')],
        // (the mouse captured, as the player's click on Resume would: the clip arrives in the world itself)
        [8.4, () => grantLock(page)],
        [8.6, key(page, 'Enter')],
      ]);
    },
  },
  // `arrival`: a new Ixari character arrived, docked in its home Waystation's hangar. The stills: the pause menu that
  // entering leaves up (the mouse is captured only from a click), on its shade over the lit hangar; and 16x9-resumed.png,
  // the mouse captured, the world as the player then sees it, its arrival banner over the top band; 16x9-settled.png, the
  // banner gone, the top line on its own. The clip: that world going on (the hangar's traffic).
  arrival: {
    clipSeconds: 2,
    async open(page) {
      await serveAccount(page, { welcomeAfterMs: 400 });
      await titleReady(page);
      await signIn(page, 'correct-horse');
      await page.waitForSelector('.acct-step:not(.leaving) .acct-char[data-id]');
      await page.waitForTimeout(800);
      await page.keyboard.press('ArrowDown');
      await page.keyboard.press('Enter');
      await page.waitForFunction(async () => {
        await (window as unknown as { step(n: number): Promise<void> }).step(2);
        return (window as unknown as { game: { mode: string } }).game.mode !== 'title';
      });
      await settle(page, 120);
      await page.waitForTimeout(1500);
    },
    stills16x9: {
      async resumed(page) {
        await grantLock(page);
        await settle(page, 60);
      },
      // the arrival banner gone (it and the band under it last 7 s): the top line on its own over the hangar's lights
      async settled(page) {
        await page.waitForTimeout(7500);
        await settle(page, 30);
      },
    },
  },
  // In flight off the home world's day side, in sunlight inside the habitable band: Charge (the right arc and the readout
  // under the altitude) at 58 and regenerating, a bright dash climbing its arc (P1.E07.T02). `16x9-empty.png`: Charge run
  // out on the night side, in the planet's shadow (no regeneration), and the pulse drive refused. The clip: the regen
  // sheen's whole climb, the readout ticking up.
  // Boarding in play with Charge at 60 (the ship's, set while the pilot stood beside it on the home world's day side): the
  // stills are aboard and landed after the glide into the seat, the reticle not yet up; the clip starts as the ship
  // takes off, its first frame the first the reticle (and its Charge arc, readout and regen sheen) is drawn: the arc at 60
  // at once, lilac, the sheen from the next frame.
  'hud-ship-board': {
    hash: '#foot',
    hudClock: true,
    clipSeconds: 1.5,
    sheetFrames: [0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50, 60, 70, 80, 89],
    async open(page) {
      await standingByShip(page);
      // the game moves only as it is stepped from here: Charge regenerates 2/s through the glide's 5 s, 50 to 60
      await parkLoop(page);
      await page.evaluate(() => {
        const g = (window as unknown as { game: { ship: { charge: number }; boardShip(): void } }).game;
        g.ship.charge = 50;
        g.boardShip();
      });
      // the glide into the seat (4.2 s)
      await settle(page, 300);
    },
    async motion(page) {
      await page.evaluate(() => (window as unknown as { game: { ship: { takeOff(): void } } }).game.ship.takeOff());
    },
  },
  'hud-ship': {
    hudClock: true,
    clipSeconds: 2,
    async open(page) {
      await page.evaluate(() => (window as unknown as { dev: { boot(): Promise<void> } }).dev.boot());
      await settle(page, 60);
      await shipOffHome(page, 1, 58);
      await settle(page, 90);
    },
    stills16x9: {
      async empty(page) {
        await shipOffHome(page, -1, 0);
        await settle(page, 90);
        await page.evaluate(() => (window as unknown as MeterWindow).game.ship.tryPulse());
        await settle(page, 6);
      },
    },
    async motion(page) {
      await shipOffHome(page, 1, 58);
      // (the empty still's refusal is not this scene's)
      await page.evaluate(() => (document.querySelector('.toasts') as HTMLElement).replaceChildren());
    },
  },
  // The ability bar on foot (P1.E07.T03), under the prompt: six ground slots, keys 1–6, each a ring with its key and the
  // node's name (Pulse, Pull, Flare, Well, Regrow, Veil); Well cooling with 13 of its 20 s left and Regrow 4 of 10, their
  // rings drawn back in heat's warm with the seconds left in them; heat at 35 on the crosshair's left arc.
  // `*-refused.png` (both aspects): Well pressed again while it cools, refused by the server: its ring edged in danger red
  // and COOLING DOWN on a plate over it. `*-rest.png`: nothing on the bar moved for 4 s, so it rests at 55% with its names
  // hidden. The clip (the bar waking from rest as it starts): key 1 pressed 0.2 s in, the server's answer 60 ms later,
  // Pulse's ring flaring and its cooldown starting (6 s), Pulse's 10 heat easing onto the arc over 250 ms with the new
  // chunk drawn bright; key 1 again 2.2 s in, refused, the red edge and the plate over slot 1 for 1.6 s; Regrow ready
  // about 4 s in and Pulse about 6.3 s in, each ring brightening for a beat as it comes back. The sheet's title (and
  // readout.txt) is the HUD's per-frame cost; `crops-*.png` are 4x crops of the crosshair and slot 1.
  'hud-abilities': {
    hash: '#foot',
    hudClock: true,
    clipSeconds: 6.8,
    readout: hudCostReadout,
    sheetFrames: [0, 12, 14, 16, 18, 20, 22, 26, 30, 34, 60, 120, 132, 136, 150, 200, 240, 246, 252, 300, 376, 382, 388, 407],
    crops: [
      { name: 'reticle', selector: '.crosshair', pad: 24 },
      { name: 'slot', selector: '.ab-row .ab-slot:nth-child(1)', pad: 30 },
    ],
    async open(page) {
      await standingByShip(page);
      await parkLoop(page);
      await slotAbilities(page, ['pulse', 'pull', 'flare', 'well', 'regrow', 'veil'], [], 2);
      await heatAt(page, 35, false, false);
      await coolingDown(page, { well: 13, regrow: 4 });
      await settle(page, 2);
    },
    stills: {
      async refused(page) {
        await castRoundTrip(page, { bar: 'ground', slot: 3, node: 'well', at: 0, rtt: 0, refused: 'cooldown', seq: 1 });
        await settle(page, 2);
      },
      async rest(page) {
        await coolingDown(page, {});
        await settle(page, 2);
        await page.waitForTimeout(4500);
        await settle(page, 2);
      },
    },
    async motion(page) {
      await uiCostProbe(page, 'hud');
      await heatAt(page, 35, false, false);
      await coolingDown(page, { well: 13, regrow: 4 });
      await page.evaluate(() => {
        const a = (window as unknown as AbilityWindow).game.abilities as unknown as { refusal: unknown };
        a.refusal = null;
      });
      await castRoundTrip(page, { bar: 'ground', slot: 0, node: 'pulse', at: 200, cooldownS: 6, pay: 10, seq: 2 });
      await castRoundTrip(page, { bar: 'ground', slot: 0, node: 'pulse', at: 2200, refused: 'cooldown', seq: 3 });
    },
  },
  // A cast's cost on foot at 21:9 (P1.E07.T03, the grader's round-2 request): heat at 20, the same six ground slots, all
  // ready. The clip, at 21:9: key 3 pressed 0.2 s in, the server's answer 60 ms later, Flare's ring flaring and its 12 s
  // cooldown starting, its 30 heat easing onto the crosshair's left arc over 250 ms (20 to 50) with the new chunk drawn
  // bright; key 3 again 1.4 s in, refused while it cools: the red edge and COOLING DOWN on a plate over slot 3, gone 1.6 s
  // later. `crops-reticle.png` and `crops-slot.png` are 4x crops of the crosshair and slot 3; the sheet's title (and
  // readout.txt) is the HUD's per-frame cost.
  'hud-abilities-cost': {
    hash: '#foot',
    hudClock: true,
    clipAspect: '21x9',
    readout: hudCostReadout,
    clipSeconds: 3.4,
    sheetFrames: [0, 12, 15, 16, 17, 18, 19, 20, 22, 24, 26, 28, 31, 36, 48, 84, 88, 89, 90, 92, 96, 110, 150, 180, 203],
    crops: [
      { name: 'reticle', selector: '.crosshair', pad: 24 },
      { name: 'slot', selector: '.ab-row .ab-slot:nth-child(3)', pad: 30 },
    ],
    async open(page) {
      await standingByShip(page);
      await parkLoop(page);
      await slotAbilities(page, ['pulse', 'pull', 'flare', 'well', 'regrow', 'veil'], [], 2);
      await heatAt(page, 20, false, false);
      await coolingDown(page, {});
      await settle(page, 2);
    },
    async motion(page) {
      await uiCostProbe(page, 'hud');
      await heatAt(page, 20, false, false);
      await castRoundTrip(page, { bar: 'ground', slot: 2, node: 'flare', at: 200, cooldownS: 12, pay: 30, seq: 1 });
      await castRoundTrip(page, { bar: 'ground', slot: 2, node: 'flare', at: 1400, refused: 'cooldown', seq: 2 });
    },
  },
  // The ability bar in flight (P1.E07.T03): a Wayfarer's four ship slots, keys 1–4 (Tractor Beam, Deep Sweep, Repair
  // Drones, Inertial Brake), Deep Sweep cooling with 21 of its 30 s left and Inertial Brake 6 of 15, their rings drawn back
  // in the flight deck's warm white with the seconds left in it (lilac is Charge's alone: only the reticle's right arc
  // and a cast's chunk of it wear it); Charge at 72 on that arc. The clip: key 1 pressed 0.2 s in, the server's answer,
  // the ring flaring and Tractor Beam's 12 s cooldown starting, its 15 Charge coming off the arc over 250 ms with the cost
  // drawn bright as it drains; Inertial Brake ready 1.2 s in, its ring brightening for a beat. The sheet's title (and
  // readout.txt) is the HUD's per-frame cost; `crops-*.png` are 4x crops of the reticle and slot 1.
  'hud-abilities-flight': {
    hudClock: true,
    clipSeconds: 2,
    readout: hudCostReadout,
    sheetFrames: [0, 6, 12, 14, 16, 17, 18, 19, 20, 22, 24, 26, 28, 31, 34, 40, 60, 72, 76, 80, 90, 119],
    crops: [
      { name: 'reticle', selector: '.ship-reticle', pad: 24 },
      { name: 'slot', selector: '.ab-row .ab-slot:nth-child(1)', pad: 30 },
    ],
    async open(page) {
      await page.evaluate(() => (window as unknown as { dev: { boot(): Promise<void> } }).dev.boot());
      await settle(page, 60);
      await shipOffHome(page, 1, 72);
      await settle(page, 90);
      await slotAbilities(page, [], ['tractor_beam', 'deep_sweep', 'repair_drones', 'inertial_brake'], 4);
      await coolingDown(page, { deep_sweep: 21, inertial_brake: 6 });
      await settle(page, 2);
    },
    async motion(page) {
      await uiCostProbe(page, 'hud');
      await coolingDown(page, { deep_sweep: 21, inertial_brake: 1.2 });
      await castRoundTrip(page, { bar: 'ship', slot: 0, node: 'tractor_beam', at: 200, cooldownS: 12, pay: 15, seq: 1 });
    },
  },
  // On foot on the home world, mining a plant or rock a few metres off with the beam held, its impact glare behind the
  // crosshair: the heat arc (left of the dot) at 40 of 100, 40% of it lit, warm
  // (P1.E07.T02). `16x9-overheat.png`: the lockout at the top, the arc danger red with a tick where the lockout ends and
  // OVERHEAT under the dot. The clip: a whole cycle with the beam held throughout, the meter at three times the game's
  // pace: from cool it climbs, turns amber at 75, overheats at 100 (about 1.4 s in), cools through the lockout to the tick
  // at 25 (about 2.6 s) and the lockout lifts, the beam heating again.
  'hud-foot': {
    hash: '#foot',
    hudClock: true,
    clipSeconds: 3,
    async open(page) {
      await standingByShip(page);
      await faceFlora(page);
      await parkLoop(page);
      // 38, and five frames of beam at 24/s: 40
      await heatAt(page, 38, false, true);
      await settle(page, 5);
    },
    stills16x9: {
      async overheat(page) {
        await heatAt(page, 100, true, true);
        await settle(page, 3);
      },
    },
    async motion(page) {
      // the overheat still's lockout cleared and settled before the first frame: cool, the button up, the HUD told, and
      // its fades run out (CSS runs at a tenth of real time while the clip records: OVERHEAT's 0.25 s, the arc's 0.4 s)
      await heatAt(page, 0, false, false);
      await page.evaluate(() => (window as unknown as { game: { hud: { update(dt: number): void } } }).game.hud.update(0));
      await page.waitForTimeout(5000);
      // then the beam held from cool
      await page.evaluate(() => (window as unknown as MeterWindow).dev.button(0, true));
      await hastenHeat(page, 3);
    },
  },
  // Leaving the ship on foot with the multitool still warm (heat 50): the stills are aboard and landed; the clip's first
  // frame is the foot HUD's first, the crosshair fading in (150 ms) with its heat arc already at 50 and cooling at 20/s.
  'hud-foot-exit': {
    hash: '#foot',
    hudClock: true,
    clipSeconds: 0.6,
    sheetFrames: [...Array.from({ length: 20 }, (_, i) => i), 24, 29, 35],
    async open(page) {
      await standingByShip(page);
      await parkLoop(page);
      await page.evaluate(() => (window as unknown as { game: { boardShip(): void } }).game.boardShip());
      // aboard: the glide into the seat (4.2 s)
      await settle(page, 300);
    },
    async motion(page) {
      await page.evaluate(() => {
        const g = (window as unknown as { game: MeterGame & { exitShip(): void } }).game;
        g.multitool.meter = { heat: 50, overheated: false, charge: 0 };
        g.exitShip();
      });
    },
  },
  // On foot after mining, the beam let go at 30 heat: the arc cooling idle (20/s on the home world by day). The stills: 30,
  // warm, the button up. The clip: from 30 down to 2 (1.4 s, frame 84), where the empty arc fades out (0.4 s, to frame
  // 108), the crosshair's dot left alone.
  'hud-foot-cool': {
    hash: '#foot',
    hudClock: true,
    clipSeconds: 2,
    sheetFrames: [0, 12, 24, 36, 48, 60, 72, 78, 82, 84, 86, 88, 90, 93, 96, 99, 102, 105, 108, 119],
    async open(page) {
      await standingByShip(page);
      await parkLoop(page);
      // 31, and three frames idle at 20/s: 30
      await heatAt(page, 31, false, false);
      await settle(page, 3);
    },
    async motion(page) {
      await heatAt(page, 30, false, false);
    },
  },
  map: {
    async open(page) {
      await page.evaluate(() => (window as unknown as { dev: { boot(): Promise<void> } }).dev.boot());
      await page.evaluate(() => (window as unknown as { game: { menus: { openMap(): void } } }).game.menus.openMap());
      await settle(page, 60);
    },
  },
  // the inventory (P1.E06.T04): suit stacks beside the ship's cargo pods after a mining trip, the ferrite stack hovered.
  // `inventory` is the Lark every pilot starts in (one pod); `inventory-pack-mule` the Lark with Pack Mule (two pods,
  // stacks of 15,000); `inventory-hauler` a Mule's four pods; `inventory-longhaul` a Longhaul's sixteen. `inventory` adds
  // a still of all nineteen resources' icons (16x9-resources.png, P1.E13.T02), which the clip then shows too.
  inventory: inventoryScreen(INVENTORY_SCENES.lark!, { stills16x9: { resources: showNineteen } }),
  'inventory-pack-mule': inventoryScreen(INVENTORY_SCENES.packMule!),
  'inventory-hauler': inventoryScreen(INVENTORY_SCENES.mule!),
  'inventory-longhaul': inventoryScreen(INVENTORY_SCENES.longhaul!),
  // every one of a Longhaul's sixteen pods in use: the pod list scrolls, with its scrollbar drawn, and a still of it
  // scrolled to the end (16x9-scrolled.png)
  'inventory-longhaul-full': inventoryScreen(INVENTORY_SCENES.longhaulFull!, { showScrollbars: true, stills16x9: { scrolled: scrollPodsToEnd } }),
  // the demo's box station, from outside and from a hangar pad (grader calibration, P1.E14.T09; later the kit-built
  // Waystation of P1.E11.T02)
  'station-exterior': {
    hash: '#station',
    async open(page) {
      await page.waitForFunction(async () => {
        await (window as unknown as { step(n: number): Promise<void> }).step(4);
        return (window as unknown as { game: { mode: string } }).game.mode === 'ship';
      });
      // the scenario parks the ship 200 m off the hangar mouth; hold it there
      await page.evaluate(() => {
        const g = (window as unknown as { game: { ship: { speed: number; throttle?: number } } }).game;
        g.ship.speed = 0;
      });
      await settle(page, 90);
    },
  },
  // the test cutscene (P1.E09.T04; packages/client/public/cutscenes/test.json from assets/blend/cutscenes/
  // test_cutscene.blend): the stills mid-dialogue 6.6 s in (the station shot, its banner, the second line), the approach
  // 2.6 s in and the return 10 s in; the clip the whole of it from the player's chase view, letterbox in, three shots,
  // three lines and the banner, to the letterbox out and the camera back on the ship (11.5 s, then 1.5 s back)
  'cutscene-test': {
    hudClock: true,
    clipSeconds: 13.4,
    // the glide in (every 14 frames), each cut and the frames either side, the banner, the exit (every 20)
    sheetFrames: [0, 14, 28, 42, 56, 96, 170, 240, 262, 268, 300, 340, 420, 476, 484, 560, 640, 688, 700, 720, 740, 760, 780, 803],
    async open(page) {
      await stageCutscene(page, 'test');
      await playCutsceneTo(page, 'test', 6.6);
    },
    stills16x9: {
      approach: (page) => playCutsceneTo(page, 'test', 2.6),
      return: (page) => playCutsceneTo(page, 'test', 10),
    },
    async motion(page) {
      await page.evaluate(async () => {
        const w = window as unknown as CutscenePage;
        w.game.cutscenes.stop();
        w.game.hud.clearBanners();
        void w.game.cutscenes.play('test');
        await new Promise((r) => setTimeout(r, 0));
      });
    },
  },
  // the test cutscene's keys (P1.E09.T04): Space on a line already read jumps to the next behind a short dip (the still
  // 2.2 s in, the first line read; the clip from the key press: the dip, the next shot, the next line revealing)
  'cutscene-test-jump': {
    hudClock: true,
    clipSeconds: 1.5,
    sheetFrames: [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 21, 24, 30, 36, 42, 48, 56, 64, 72, 80, 89],
    async open(page) {
      await stageCutscene(page, 'test');
      await playCutsceneTo(page, 'test', 2.2);
    },
    async motion(page) {
      await page.evaluate(() => {
        window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space', bubbles: true }));
        window.dispatchEvent(new KeyboardEvent('keyup', { code: 'Space', bubbles: true }));
      });
    },
  },
  // and Esc mid-line skips it (the still 2.6 s in, the first line showing; the clip from the key press: the letterbox
  // opening and the camera gliding back to the ship over 1.5 s)
  'cutscene-test-skip': {
    hudClock: true,
    clipSeconds: 1.8,
    sheetFrames: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 100, 107],
    async open(page) {
      await stageCutscene(page, 'test');
      await playCutsceneTo(page, 'test', 2.6);
    },
    async motion(page) {
      await page.evaluate(() => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Escape', bubbles: true })));
    },
  },
  // remote ships (P1.E04.T02): three other pilots' Larks sweeping round in formation in front of the ship by the
  // Waystation, drawn by the remote layer from a recorded snapshot stream played offline (openRemotes); the still 1.2 s
  // into the pass, the clip the 2.5 s after it, interpolated through the stream's jitter at 60 fps
  'remote-ships': {
    hudClock: true,
    clipSeconds: 2.5,
    open: (page) => openRemotes(page, 'flypast', 1.2),
  },
  // the Phase 1 budget's 24 remote players in view at once, each about its own business (heading, speed, turn and climb),
  // a hundred metres to a few kilometres out, each marked with its name and range; one draws away past the 4 km a ship's
  // sensors pick a Lark up at, and its marker drops during the clip (one kit of instanced meshes draws them all, the far
  // ones simplified)
  'remote-ships-crowd': {
    hudClock: true,
    clipSeconds: 2,
    open: (page) => openRemotes(page, 'crowd', 1.2),
  },
  // the crowd with the sensors' and the HUD's reading of each pilot over it (sensorsOverlay, a dev overlay): which pilots
  // the local ship's sensors pick up, and what became of each one's mark and name
  'remote-ships-crowd-sensors': {
    hudClock: true,
    clipSeconds: 2,
    open: async (page) => {
      await openRemotes(page, 'crowd', 1.2);
      await sensorsOverlay(page);
    },
  },
  // the Waystation's hangar from the player's docked ship: two other pilots' Larks docked on the pads beside it, gear
  // down, and two more flying past outside the mouth one after the other, throttles opening (their exhausts lengthen)
  'remote-ships-pads': {
    hudClock: true,
    clipSeconds: 2.5,
    open: (page) => openRemotes(page, 'pads', 1.6, 'pads'),
  },
  // low over the home world, in its turning frame: another pilot's Lark set down on the ground ahead, gear down, and two
  // more flying past low over the ground, following it as it rises and falls, throttles opening (the still as they
  // cross; a third crosses during the clip)
  'remote-ships-surface': {
    hudClock: true,
    clipSeconds: 2.5,
    open: (page) => openRemotes(page, 'surface', 2.2, 'surface'),
  },
  // a Waystation bay phase full, from the player's ship docked on its pad: 24 other pilots' Larks docked round it, gear
  // down (the hangar has 4 pads until the modular Waystation; the others stand on the floor's berths); the worst case of
  // remote ships a bay phase allows, for its look and its perf readout (perf.json)
  'remote-ships-bay': {
    hudClock: true,
    clipSeconds: 2,
    open: (page) => openRemotes(page, 'bay', 1.0, 'pads'),
  },
  // the fabricators (P1.E13.T05, DESIGN 15.7): `fabricator` the Waystation's, at its terminal on the trade deck, with a
  // refusal shown (the oxygen cartridge, short of oxygen), a still of a recipe it can make (16x9-craftable.png), and the
  // clip of a warp cell crafted; `fabricator-learn` the same, and the clip of the torpedo recipe learned;
  // `fabricator-ship` the ship's own, landed on the home world: ammo and cartridges only (the warp cell listed as made at
  // a Waystation), and the clip of three crafts of flak ammo
  fabricator: {
    clipSeconds: 2,
    sheetFrames: FABRICATOR_SHEET,
    open: openStationFabricator,
    stills16x9: { craftable: (page) => fabClick(page, '.fab-row[data-recipe="warp_cell"]') },
    motion: fabricatorMotion('warp_cell'),
  },
  // the stepper at its limits (+ and MAX dimmed at the most the materials make, as − is at one) and a refusal on Enter
  'fabricator-limits': {
    clipSeconds: 2,
    sheetFrames: [0, 12, 21, 30, 39, 48, 57, 60, 62, 64, 66, 68, 70, 74, 80, 88, 96, 104, 112, 119],
    open: stationFabricator,
    motion: limitsMotion,
  },
  // the stepper at a maximum above one: the pulse fuel cell at 6 of 6 (+ and MAX dimmed, − lit), then −, + and + and
  // MAX pressed at the maximum
  'fabricator-limits-max': {
    clipSeconds: 1.2,
    sheetFrames: [0, 6, 11, 12, 13, 15, 20, 23, 24, 25, 27, 32, 35, 36, 37, 44, 47, 48, 49, 71],
    open: stepperAtSix,
    motion: stepperMotion,
  },
  // learning a recipe at the Waystation: LEARN on the torpedo recipe, and the row moving into the list
  'fabricator-learn': {
    clipSeconds: 1.2,
    sheetFrames: [0, 6, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 34, 38, 44, 50, 58, 66, 71],
    open: stationFabricator,
    motion: learnMotion,
  },
  'fabricator-ship': {
    clipSeconds: 2,
    sheetFrames: FABRICATOR_SHEET,
    open: openShipFabricator,
    motion: fabricatorMotion(null),
  },
  // a world event announced (P2.E21.T01, ARCHITECTURE §26): its banner over the home world's ground by day
  // (`event-banner`) and the same ground at night (`event-banner-night`)
  'event-banner': eventBannerScreen(40),
  'event-banner-night': eventBannerScreen(140),
  'event-banner-queued': eventBannerQueuedScreen(),
  'station-hangar': {
    hash: '#dock',
    async open(page) {
      await page.waitForFunction(async () => {
        await (window as unknown as { step(n: number): Promise<void> }).step(4);
        return (window as unknown as { game: { mode: string } }).game.mode === 'foot';
      });
      await settle(page, 90);
    },
  },
  // chat and party (P1.E15.T03), low over the sunlit home world: the panel open on the shard tab with several lines in
  // each channel and the party frame above it; stills of the system and party tabs, and of refusals (the server's, an
  // invite to no one online; the panel's own, a line typed faster than the server would take it, kept in the input).
  // The clip: new lines rising into the closed feed, the panel opening and closing on a line sent, and the lines fading
  // out of the way (each ten seconds after it came, those the panel showed four seconds after it closed).
  social: {
    hudClock: true,
    clipSeconds: 14,
    sheetFrames: [0, 18, 24, 54, 60, 90, 96, 102, 108, 138, 144, 150, 156, 380, 400, 420, 620, 680, 740, 790, 839],
    async open(page) {
      await stageSocial(page, 'limb');
      await onStage(page, "s.partyScene(); s.chatScene(); s.open('shard')", 60);
    },
    stills16x9: {
      system: (page) => onStage(page, "s.social.setTab('system')"),
      party: (page) => onStage(page, "s.social.setTab('party')"),
      refusal: (page) =>
        onStage(
          page,
          "s.social.setTab('shard'); s.social.model.submit('/invite Nobody Here'); s.social.model.pace.level = 0; s.type('Anyone up for the raid?')",
          60,
        ),
      // muted by the server for a flood (75 s, so the hint reads a minute), a line typed anyway held in the input; and the
      // party with a member whose connection is down
      muted: (page) =>
        onStage(
          page,
          "s.setParty('Kestrel Vane', [s.member('Kestrel Vane'), s.member('Tess Arlo'), s.member('Bo Tran', 2), s.member('Juno Reyes', 10, s.here, false)]); " +
            "s.social.model.pace.level = 5; s.push({ t: 'denied', of: 'chat', code: 'muted', retryS: 75 }); s.type('Anyone up for the raid?')",
          60,
        ),
    },
    async motion(page) {
      // the panel the stills left open closes, the stills' mute is lifted and the four of the party are back, and the
      // feed holds three lines from six seconds ago; all of it drawn now, so its fades run out before the first frame
      await page.evaluate(() => {
        const s = (window as unknown as SocialWindow).__social;
        s.social.model.mutedUntil = 0;
        s.close();
        s.partyScene();
        s.clear();
        s.chat('shard', 'Kestrel Vane', 'Convoy leaving in ten minutes, two escorts wanted');
        s.chat('system', 'Ilse Marr', 'Pirate wing over the north pole, keep clear of it');
        s.chat('party', 'Bo Tran', 'Hull at thirty percent, give me a minute');
        s.age(6000);
        s.social.update();
      });
      await page.waitForTimeout(3000);
      await page.evaluate(() => {
        const w = window as unknown as SocialWindow;
        const s = w.__social;
        const hud = w.game.hud;
        hud.later(() => s.chat('shard', 'Juno Reyes', 'Saw a Hollow drifter past the third moon'), 300);
        hud.later(() => s.chat('party', 'Kestrel Vane', 'Regroup at pad three'), 900);
        hud.later(() => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Enter', bubbles: true })), 1500);
        hud.later(() => s.type('On my way'), 2300);
      });
    },
  },
  // the same panel over open space by the Waystation, closed: the feed's lines on their plates against the dark
  'social-space': {
    hudClock: true,
    async open(page) {
      await stageSocial(page, 'space');
      await onStage(page, "s.partyScene(); s.chatScene(); s.open('shard')", 60);
    },
    stills16x9: {
      party: (page) => onStage(page, "s.social.setTab('party')"),
      closed: (page) => onStage(page, 's.close()', 60),
    },
  },
  // the party frame: four members, the leader marked, one badly hurt, one in another system; the panel open on the party
  // tab (invite and leave under the frame); stills with the player leading (promote and remove on each member) and closed
  party: {
    hudClock: true,
    async open(page) {
      await stageSocial(page, 'limb');
      await onStage(page, "s.partyScene(); s.chatScene(); s.open('party')", 60);
    },
    stills16x9: {
      leader: (page) => onStage(page, "s.partyScene('Tess Arlo')"),
      closed: (page) => onStage(page, 's.partyScene(); s.close()', 60),
    },
  },
  // an invite waiting, the panel closed (Enter to answer), its minute running down; a still with the panel open; the
  // clip: the panel opens, Accept, the party frame rises in where the card was, the panel closes
  'party-invite': {
    hudClock: true,
    clipSeconds: 3.5,
    readout: socialCostReadout,
    sheetFrames: [0, 6, 12, 18, 24, 30, 36, 60, 84, 90, 96, 102, 108, 114, 120, 144, 150, 156, 162, 180, 209],
    async open(page) {
      await stageSocial(page, 'limb');
      // (the feed's lines are long gone, so the still is not taken as one fades)
      await onStage(page, "s.chatScene(); s.news('invite', 'Kestrel Vane'); s.age(8000); for (const l of s.social.model.lines) l.at -= 30000", 60);
    },
    stills16x9: {
      open: (page) => onStage(page, "s.open('shard')"),
    },
    async motion(page) {
      await uiCostProbe(page, 'social');
      // (closed, and drawn closed, before the first frame)
      await page.evaluate(() => {
        const s = (window as unknown as SocialWindow).__social;
        s.close();
        s.social.update();
      });
      await page.waitForTimeout(3000);
      await page.evaluate(() => {
        const w = window as unknown as SocialWindow;
        const s = w.__social;
        const hud = w.game.hud;
        hud.later(() => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Enter', bubbles: true })), 400);
        hud.later(() => document.querySelector<HTMLButtonElement>('.sp-invite .btn')?.click(), 1400);
        hud.later(() => s.close(), 2500);
      });
    },
  },
  // the call-for-aid list: three beacons (a raid at the Waystation and a story chapter here, an event in another system)
  // with an answer refused (too far from the raid's place); stills with a raise refused (in no instance) and with the
  // player's own beacon up; the clip: an answer refused, its reason rising in under the beacon
  beacons: {
    hudClock: true,
    clipSeconds: 1.5,
    readout: socialCostReadout,
    showScrollbars: true,
    async open(page) {
      await stageSocial(page, 'limb');
      await onStage(page, "s.chatScene(); s.beaconsScene(); s.open('beacons'); s.social.model.answer(12)", 60);
    },
    stills16x9: {
      'raise-refused': (page) => onStage(page, 's.social.model.raise()'),
      own: (page) =>
        onStage(
          page,
          "const b = Object.assign({}, s.beacons[1], { id: 20, from: 'Tess Arlo', open: 2, cap: 6 }); s.push({ t: 'beacon', op: 'raised', id: 20, beacon: b })",
        ),
    },
    async motion(page) {
      await uiCostProbe(page, 'social');
      await page.evaluate(() => {
        const w = window as unknown as SocialWindow;
        const s = w.__social;
        // (the event is in another star system)
        s.answerCode = 'elsewhere';
        w.game.hud.later(() => s.social.model.answer(14), 300);
      });
    },
  },
  // the open panel's tabs, clicked Shard → System → Party → Beacons and back, every 0.8 s: each list fades out where it
  // stands before the next fades in, and the beacon list does the same
  'social-tabs': {
    hudClock: true,
    clipSeconds: 5.2,
    readout: socialCostReadout,
    async open(page) {
      await stageSocial(page, 'limb');
      await onStage(page, "s.partyScene(); s.chatScene(); s.beaconsScene(); s.open('shard')", 60);
    },
    async motion(page) {
      await uiCostProbe(page, 'social');
      await page.evaluate(() => {
        const hud = (window as unknown as SocialWindow).game.hud;
        const order = ['system', 'party', 'beacons', 'party', 'system', 'shard'];
        order.forEach((t, i) => hud.later(() => document.querySelector<HTMLButtonElement>(`.sc-tab.t-${t}`)?.click(), 300 + i * 800));
      });
    },
  },
  // beacons-many held still: scrolled to the middle of the list (both edge fades on) with the panel open and the beacons'
  // ages moving on, beside a party frame of the player leading, one member offline (OFFLINE, LEAD and KICK on show). The
  // list must not redraw, blink or move while it stands
  'beacons-rest': {
    hudClock: true,
    clipSeconds: 2,
    readout: socialRestReadout,
    showScrollbars: true,
    async open(page) {
      await stageSocial(page, 'limb');
      await onStage(
        page,
        "s.chatScene(); s.manyBeaconsScene(); s.setParty('Tess Arlo', [s.member('Kestrel Vane'), s.member('Tess Arlo'), s.member('Bo Tran', 2), s.member('Ilse Marr', 0, s.here, false)]); s.open('beacons'); s.social.model.answer(15)",
        60,
      );
      await onStage(page, "const l = document.querySelector('.sc-beacons'); l.scrollTop = Math.round((l.scrollHeight - l.clientHeight) / 2)", 60);
    },
    async motion(page) {
      await uiCostProbe(page, 'social');
      await socialRestWatch(page);
    },
  },
  // a list longer than the panel: eight calls for aid, one answer refused (too far) in view; the list fades at its foot
  // over its scrollbar. The clip scrolls it to its end and back, eased (the list's own scroll, as a wheel would)
  'beacons-many': {
    hudClock: true,
    clipSeconds: 3,
    readout: socialCostReadout,
    showScrollbars: true,
    async open(page) {
      await stageSocial(page, 'limb');
      await onStage(page, "s.chatScene(); s.manyBeaconsScene(); s.open('beacons'); s.social.model.answer(15)", 60);
    },
    async motion(page) {
      await uiCostProbe(page, 'social');
      await page.evaluate(() => {
        const w = window as unknown as SocialWindow;
        const list = document.querySelector('.sc-beacons') as HTMLElement;
        const end = Math.round(list.scrollHeight - list.clientHeight);
        // down over a second from 0.3 s, a pause, and back up over a second, eased in and out. A scroll offset is a whole
        // pixel, so the ends of the ease move a pixel every few frames (under a pixel a frame on average) rather than
        // one a frame; each step is due half a millisecond before its frame so none slips into the next
        const ys: number[] = [];
        for (let k = 0; k <= 60; k++) {
          const t = k / 60;
          ys.push(Math.round(end * (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)));
        }
        ys.forEach((y, k) => {
          w.game.hud.later(() => (list.scrollTop = y), 300 + k * (1000 / 60) - 0.5);
          w.game.hud.later(() => (list.scrollTop = end - y), 1700 + k * (1000 / 60) - 0.5);
        });
      });
    },
  },
  // The Edge following the Count (P2.E22.T02): the galaxy map and the sky in deep space with the Count at its lowest (the Edge
  // 10 ly in, the wall drawn 200,000 ly nearer), at the middle (the baseline) and at its highest (10 ly out). The still is the
  // lowest; `count-500` and `count-1000` are the others; the clip sweeps the Count from 0 up to 1000 and back, the wall
  // sliding with it. The sheet's title (and readout.txt) is the HUD's per-frame cost.
  'edge-map': {
    clipSeconds: 3,
    sheetFrames: [0, 30, 60, 90, 120, 150, 179],
    readout: hudCostReadout,
    async open(page) {
      await openEdgeMap(page, 0);
    },
    stills: {
      'count-500': (page) => setCount(page, 500),
      'count-1000': (page) => setCount(page, 1000),
    },
    async motion(page) {
      await uiCostProbe(page, 'hud');
      await sweepCount(page, 180, null, true);
    },
  },
  'edge-sky': {
    clipSeconds: 3,
    sheetFrames: [0, 30, 60, 90, 120, 150, 179],
    readout: hudCostReadout,
    async open(page) {
      await openEdgeSky(page, 0);
    },
    stills: {
      'count-500': (page) => setCount(page, 500),
      'count-1000': (page) => setCount(page, 1000),
    },
    async motion(page) {
      await uiCostProbe(page, 'hud');
      await sweepCount(page, 180);
    },
  },
  // The galaxy map at cluster zoom in a season opened Broken: the still is Count 0, every dark Waystation (the opening's three
  // and the ones the low Count pushed Edge-ward) marked on its star; `count-1000` is the Count at its highest, the marks gone;
  // `dark-selected` a dark system chosen (its "Waystation: Dark" row) and `edge-selected` the Edge (Distance, Expansion, Count).
  // The clip sweeps the Count 0 → 1000 → 0, the marks going out at 700 and coming back with it. The sheet's title (and
  // readout.txt) is the HUD's per-frame cost.
  'edge-dark': {
    clipSeconds: 3,
    sheetFrames: [0, 30, 60, 90, 120, 150, 179],
    readout: hudCostReadout,
    async open(page) {
      await openDarkMap(page, 0);
    },
    stills: {
      'count-1000': (page) => setCount(page, 1000, 'broken'),
      'dark-selected': async (page) => {
        await setCount(page, 0, 'broken');
        await selectOnMap(page, { system: seasonOpening('broken', 5).dark[0]! });
      },
      'edge-selected': async (page) => {
        await selectOnMap(page, { edge: true });
      },
    },
    async motion(page) {
      await uiCostProbe(page, 'hud');
      await sweepCount(page, 180, 'broken', true);
    },
  },
};
