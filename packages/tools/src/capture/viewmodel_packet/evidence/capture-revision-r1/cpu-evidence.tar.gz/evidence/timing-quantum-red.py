import sys,json
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'packages/tools/src/capture/viewmodel_packet'))
from test_inspect import packet
with packet('view-ixari') as fixture:
 value=fixture.value
 zero=next(f for f in value['frames'] if f['file']=='16x9-raise-0.png')
 raised=next(f for f in value['frames'] if f['file']=='16x9-raise-0.4.png')
 raised['elapsed']=zero['elapsed']+0.401
 fixture.write(value);result=fixture.run_cli()
 e=Path('/private/tmp/vmrev-hrgu6g4e')
 (e/'timing-quantum-red.stdout').write_text(result.stdout)
 (e/'timing-quantum-red.stderr').write_text(result.stderr)
 print(json.dumps({'cliExit':result.returncode,'duration':raised['elapsed']-zero['elapsed'],'steps':raised['frame']-zero['frame']}))
 assert result.returncode==0
