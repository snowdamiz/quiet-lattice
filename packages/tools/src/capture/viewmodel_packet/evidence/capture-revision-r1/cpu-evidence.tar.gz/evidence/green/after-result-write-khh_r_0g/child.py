
import json, sys, os, subprocess
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import caller
caller.HERE = Path(sys.argv[2])
def capture(ready, spec, paths, record):
    for name in spec['files']:
        (Path(paths['output']) / name).write_text('INERT BOUNDARY FIXTURE '+name)
    record['ports'] = ['capture', 'release']
    return {'released': True}
def decoder(ready, spec, paths, record, frozen):
    assert record['released']
    record['ports'].append('decode')
    record['inspection'] = {'valid': True, 'inert': True}
def cache(ready, evidence, record): record['initialCacheBytes'] = 0
def runner(*args): return caller.run_unit(*args, capture=capture, decoder=decoder, cache_copy=cache, final_verify=lambda _: {})
mode=os.environ.get('VM_MODE','success')
original_capture=capture
original_decoder=decoder
def capture(ready,spec,paths,record):
    if mode=='all-sinks':
        error=subprocess.CalledProcessError(7,['inert-capture'],output=b'raw\xff',stderr=b'err\xfe');error.unknown={'byte':b'\x00'};raise error
    value=original_capture(ready,spec,paths,record)
    if mode=='release-unproved':value['released']=False
    return value
def writer(path,value):
    if Path(path).name=='result.json' and mode=='after-result-write':
        boundary.exclusive_json(path,value,cap=20*boundary.MIB)
        raise OSError('RESULT_CLOSE_FAILURE')
    if Path(path).name in ('result.json', 'review-thalune.consumed.json.fallback.json') and mode=='all-sinks':raise OSError('ALL_DISK_SINKS_FAILED')
    return boundary.exclusive_json(path,value,cap=20*boundary.MIB)
def emit(data):raise OSError('STDERR_SINK_FAILED')
import boundary
code, result = caller.main(Path(sys.argv[3]), sys.argv[4], Path(sys.argv[5]), enabled=True, verifier=lambda _: {}, runner=runner, writer=writer, emit=emit)
Path(sys.argv[3]).parent.joinpath('returned.json').write_text(json.dumps(boundary.raw(result)))
if mode=='after-return':raise RuntimeError('FAILURE_AFTER_CALLER_RETURN')
print(json.dumps({'code': code, 'durable': result['durable']}))
raise SystemExit(code)
