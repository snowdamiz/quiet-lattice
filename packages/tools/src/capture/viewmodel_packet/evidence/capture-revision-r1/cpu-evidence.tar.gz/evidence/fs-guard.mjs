import fs from 'node:fs';
import {syncBuiltinESMExports} from 'node:module';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const permitted='/private/tmp/vmrev-hrgu6g4e/';
function check(p) {
 if (p===1 || p===2) return;
 if (typeof p==='number') throw Error('UNADMITTED_WRITE_DESCRIPTOR:'+p);
 if (p instanceof URL) p=fileURLToPath(p);
 const absolute=path.resolve(String(p));
 if (!absolute.startsWith(permitted)) throw Error('UNADMITTED_WRITE:'+absolute);
}
for(const name of ['writeFile','appendFile','mkdir','mkdtemp','rm','rmdir','unlink','truncate','chmod','chown','utimes','createWriteStream']) {
 for(const key of [name,name+'Sync']) if(typeof fs[key]==='function') {
  const original=fs[key]; fs[key]=function(p,...args){check(p);return original.call(this,p,...args)};
 }
 if(typeof fs.promises[name]==='function') { const original=fs.promises[name];fs.promises[name]=function(p,...args){check(p);return original.call(this,p,...args)}; }
}
for(const name of ['rename','copyFile','cp','link','symlink']) {
 const guard=(source,dest)=>{check(dest);if(name==='rename')check(source)};
 for(const key of [name,name+'Sync']) if(typeof fs[key]==='function') {const original=fs[key];fs[key]=function(a,b,...args){guard(a,b);return original.call(this,a,b,...args)}}
 if(typeof fs.promises[name]==='function'){const original=fs.promises[name];fs.promises[name]=function(a,b,...args){guard(a,b);return original.call(this,a,b,...args)}}
}
function opening(p,flags){if(typeof flags==='number' ? flags&(fs.constants.O_WRONLY|fs.constants.O_RDWR|fs.constants.O_CREAT|fs.constants.O_TRUNC|fs.constants.O_APPEND) : /[wa+]/.test(flags))check(p)}
for(const key of ['open','openSync']){const original=fs[key];fs[key]=function(p,f,...args){opening(p,f);return original.call(this,p,f,...args)}}
const open=fs.promises.open;fs.promises.open=function(p,f,...args){opening(p,f);return open.call(this,p,f,...args)};
syncBuiltinESMExports();
