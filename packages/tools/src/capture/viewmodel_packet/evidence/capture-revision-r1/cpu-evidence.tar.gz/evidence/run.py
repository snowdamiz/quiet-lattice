import json,subprocess,sys,time,os,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent
name=sys.argv[1];argv=sys.argv[2:];log=E/(name+'.txt');start=time.monotonic()
with log.open('xb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'},timeout=180)
row={'name':name,'argv':argv,'cwd':os.getcwd(),'exit':r.returncode,'elapsed':time.monotonic()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
with (E/'commands.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
print(json.dumps(row));print(log.read_text()[-2000:]);sys.exit(r.returncode)
