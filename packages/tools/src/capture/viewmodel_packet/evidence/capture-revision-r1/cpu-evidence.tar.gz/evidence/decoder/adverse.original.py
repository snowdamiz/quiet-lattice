import copy, hashlib, importlib.util, io, json, os, struct, subprocess, sys, zlib
from pathlib import Path
from PIL import Image
ROOT=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
HERE=ROOT/'packages/tools/src/capture/viewmodel_packet'
OUT=Path('/tmp/p1-e05-t03-cpu-review-CubSpO').resolve()
s=importlib.util.spec_from_file_location('fixtures',HERE/'test_inspect.py'); fx=importlib.util.module_from_spec(s); s.loader.exec_module(fx)
fixtures={}
for unit in ['return-thalune','view-ixari','review-thalune','review-ulgani']:
    base=OUT/unit; base.mkdir(exist_ok=True)
    fixtures[unit]=fx.Packet(base,unit)
results=[]
def frame(v, filename): return next(f for f in v['frames'] if f['file']==filename)
def run(label,unit,mutate=None,png=None):
    p=fixtures[unit]; v=copy.deepcopy(p.value)
    if mutate: mutate(v)
    p.write(v)
    restore=None
    if png:
        name,data=png; dest=p.output/name; restore=(dest,dest.read_bytes()); dest.write_bytes(data); p.manifest=p.manifest_now()
    case=OUT/'cases'/label; case.mkdir(parents=True,exist_ok=True)
    (case/p.readout).write_bytes((p.output/p.readout).read_bytes())
    manifest=case/'manifest.json'; manifest.write_text(json.dumps({'files':p.manifest},separators=(',',':')))
    if png: (case/png[0]).write_bytes(png[1])
    args=[sys.executable,'-B',str(HERE/'inspect_packet.py'),'--inventory',str(HERE/'inventory.json'),'--unit',unit,'--output',str(p.output),'--manifest',str(manifest)]
    completed=subprocess.run(args,env=os.environ.copy(),capture_output=True,timeout=20)
    (case/'stdout.json').write_bytes(completed.stdout); (case/'stderr.json').write_bytes(completed.stderr)
    (case/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    (case/'exit').write_text(str(completed.returncode)+'\n')
    payload=json.loads(completed.stdout or completed.stderr)
    result=dict(case=label,unit=unit,exit=completed.returncode,status=payload['status'],primaryFailure=payload.get('primaryFailure'),readoutBytes=(case/p.readout).stat().st_size)
    results.append(result); print(json.dumps(result),flush=True)
    if restore: restore[0].write_bytes(restore[1])
    p.write()
for unit in fixtures: run('baseline-'+unit,unit)
run('settled-raise-zero','return-thalune',lambda v:frame(v,'16x9-switch-settled.png').update(raise_=0) if False else frame(v,'16x9-switch-settled.png').update({'raise':0}))
run('neutral-unraised','view-ixari',lambda v:frame(v,'16x9-neutral.png').update({'raise':0}))
run('fire-unraised','view-ixari',lambda v:frame(v,'16x9-fire.png').update({'raise':0}))
run('neutral-maximum-heat','view-ixari',lambda v:frame(v,'16x9-neutral.png').update(heat=1))
run('left-sway-also-up','view-ixari',lambda v:frame(v,'16x9-sway-left.png').update(sway=[-.035,.03]))
def no_raise_time(v):
    a,b=frame(v,'16x9-raise-0.png'),frame(v,'16x9-raise-0.4.png')
    b.update(dt=0,elapsed=a['elapsed'],frame=a['frame']+1)
run('raise-point-four-zero-elapsed','view-ixari',no_raise_time)
run('malformed-known-input','view-ixari',lambda v:frame(v,'16x9-fire.png').update(input={'held':'never'}))
run('non-raise-seconds-object','view-ixari',lambda v:frame(v,'16x9-fire.png').update(raiseSeconds={}))
run('contradictory-overlay-count','review-thalune',lambda v:v['overlay'].update(counts={'Muzzle':0},offscreen=1))
run('far-occluded','review-thalune',lambda v:v['far'][0].update(clear=False))
run('missing-native-materials','review-thalune',lambda v:v['stats'].pop('materials'))
run('missing-tool-emission','review-thalune',lambda v:next(m for m in v['packet']['materials'] if m['name'].endswith('_Tool'))['slots'].pop('emissiveMap'))
run('unexpected-ulgani-bio','review-ulgani',lambda v:v['packet']['materials'].append(fx.texture_materials('thalune')[-1]))
run('projection-boolean','view-ixari',lambda v:frame(v,'16x9-fire.png')['projection']['world']. __setitem__(0,True))
run('unknown-nonfinite','return-thalune',lambda v:v.update(extra=float('nan')))
p=fixtures['return-thalune']; pngname='16x9-switch-gap.png'; raw=(p.output/pngname).read_bytes()
def chunk(t,b): return struct.pack('>I',len(b))+t+b+struct.pack('>I',zlib.crc32(t+b)&0xffffffff)
parts=[]; off=8
while off<len(raw):
    n=struct.unpack_from('>I',raw,off)[0]; parts.append((raw[off+4:off+8],raw[off+8:off+8+n])); off+=12+n
compressed=b''.join(b for t,b in parts if t==b'IDAT')
head=raw[:33]; tail=chunk(b'IEND',b'')
for label,data in [('zlib-missing-adler',compressed[:-4]),('zlib-truncated-deflate',compressed[:-5]),('zlib-extra-trailing',compressed+b'arbitrary-extra'),('zlib-adler-invalid',compressed[:-4]+b'\x00\x00\x00\x00')]:
    altered=head+chunk(b'IDAT',data)+tail
    probe=zlib.decompressobj()
    try:
        inflated=probe.decompress(data)
        external=dict(eof=probe.eof,unusedData=len(probe.unused_data),inflatedBytes=len(inflated))
    except zlib.error as e: external=dict(error=str(e))
    (OUT/(label+'-zlib.json')).write_text(json.dumps(external,indent=2)+'\n')
    run(label,'return-thalune',png=(pngname,altered))
run('duplicate-ihdr','return-thalune',png=(pngname,head+raw[8:]))
run('unknown-critical-chunk','return-thalune',png=(pngname,head+chunk(b'ABCD',b'unrecognized critical')+raw[33:]))
run('animated-control','return-thalune',png=(pngname,head+chunk(b'acTL',struct.pack('>II',1,0))+raw[33:]))
run('png-after-iend','return-thalune',png=(pngname,raw+b'junk'))
buf=io.BytesIO(); Image.new('RGB',(1920,1079)).save(buf,format='PNG')
run('wrong-still-height','return-thalune',png=(pngname,buf.getvalue()))
(OUT/'adverse-summary.json').write_text(json.dumps(results,indent=2)+'\n')
print('COMPLETED',len(results),'sequential CLI cases')
