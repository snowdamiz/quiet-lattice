import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import unittest

root = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
here = root / 'packages/tools/src/capture/viewmodel_packet'
out = Path(sys.argv[1])
out.mkdir()
module_spec = importlib.util.spec_from_file_location('decoder_tests', here / 'test_inspect.py')
module = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(module)
real_run = module.subprocess.run
cases = []

def recorded_run(args, **kwargs):
    case = out / ('case-%03d' % (len(cases) + 1))
    case.mkdir()
    cases.append(str(case))
    (case / 'command.json').write_text(json.dumps(args, indent=2) + '\n')
    replay = args[:]
    for flag in ('--output', '--manifest'):
        if flag in args:
            index = args.index(flag) + 1
            source = Path(args[index])
            dest = case / ('output' if flag == '--output' else 'manifest.json')
            if source.is_dir():
                shutil.copytree(source, dest)
            else:
                shutil.copyfile(source, dest)
            replay[index] = str(dest)
    (case / 'replay-command.json').write_text(json.dumps(replay, indent=2) + '\n')
    result = real_run(args, **kwargs)
    for label, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (case / label).write_bytes(data.encode() if isinstance(data, str) else data)
    (case / 'exit').write_text(str(result.returncode) + '\n')
    return result

module.subprocess.run = recorded_run
names = sys.argv[2:]
suite = (unittest.defaultTestLoader.loadTestsFromNames(names, module) if names else
         unittest.defaultTestLoader.loadTestsFromModule(module))
with (out / 'tests.log').open('x') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
summary = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
               cliCases=len(cases), successful=result.wasSuccessful(), argv=sys.argv,
               environment={key:os.environ.get(key) for key in
                            ['PYTHONPATH', 'TMPDIR', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS']},
               sourceSHA256={name:hashlib.sha256((here / name).read_bytes()).hexdigest()
                             for name in ['inspect_packet.py', 'test_inspect.py', 'inventory.json']})
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'exit').write_text(('0' if result.wasSuccessful() else '1') + '\n')
print(json.dumps(summary, indent=2))
sys.exit(0 if result.wasSuccessful() else 1)
