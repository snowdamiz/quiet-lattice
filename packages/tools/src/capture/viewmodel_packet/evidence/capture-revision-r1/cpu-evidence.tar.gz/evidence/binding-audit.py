import sys,json,hashlib
from pathlib import Path
root=Path.cwd(); packet=root/'packages/tools/src/capture/viewmodel_packet';sys.path.insert(0,str(packet))
import bindings
old=json.loads((packet/'readiness.json').read_text())['bindings']
actual=bindings.discover();changed=[]
for key in old:
 if key=='bindings':
  for a,b in zip(old[key],actual[key]):
   if a!=b:
    assert a['path']==b['path'] and Path(a['path']).is_relative_to(packet),(a,b)
    changed.append({'path':a['path'],'old':a['sha256'],'current':b['sha256']})
  assert len(old[key])==len(actual[key])
 else:assert old[key]==actual[key],(key,old[key],actual[key])
print(json.dumps({'status':'PASS','sourceDigest':actual['sourceDigest'],'trees':actual['trees'],'ignoredInventorySha256':actual['ignoredInventorySha256'],'allowedChangedPacketBindings':changed,'reviewerCacheFileExists':(root/'node_modules/.vitest-cache/2b6ca69062975caed4a6a8ff34a30b50fedc6b16').exists(),'foreignRestoration':False},indent=2))
