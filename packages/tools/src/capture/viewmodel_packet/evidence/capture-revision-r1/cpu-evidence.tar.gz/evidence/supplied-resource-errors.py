exec(compile(open('/tmp/p1-e05-t03-independent-Omf2XX/lifecycle.py').read().split("row=case('adapter-missing-resolver'")[0], '/tmp/p1-e05-t03-independent-Omf2XX/lifecycle.py','exec'))
for sinkfail in (False,True):
 original_primary=[]
 def setup(stack,root,record,trace):
  inert_init_ports(stack,root,record,trace)
  original_start=jb.StationJob.start
  def start(self):
   original_start(self)
   (self.scratch/'unsafe-link').symlink_to(root)
  stack.enter_context(patch.object(jb.StationJob,'start',start))
  original_require=native.require
  def observe_require(ok,msg):
   if not ok and str(msg).startswith('Unexpected owned symlink'):
    # Original native predicate and original exception; attach an unknown observation at its producer.
    try:original_require(ok,msg)
    except Exception as e:
     e.unknown={'resourceBytes':b'\x00\xff'};original_primary.append(e);raise
   return original_require(ok,msg)
  stack.enter_context(patch.object(native,'require',observe_require))
  if sinkfail:
   old=jb.write
   def write(path,value):
    if Path(path).name=='boundary.json' and value.get('errors'):raise OSError('POST_OBSERVER_RECEIPT_FAILURE')
    return old(path,value)
   stack.enter_context(patch.object(jb,'write',write))
 row=case('resource-original-'+str(sinkfail),setup)
 assert len(original_primary)==1
 facts=row['record']['native'];encoded=json.dumps(row['record'])
 assert 'resourceBytes' not in encoded
 assert facts['primaryFailure']['message']==('POST_OBSERVER_RECEIPT_FAILURE' if sinkfail else 'Capture did not complete: observer_failed')
 row['producerOriginal']=boundary.raw(original_primary[0]);row['primaryIsOriginal']=False
 (E/('resource-original-'+str(sinkfail)+'.json')).write_text(json.dumps(row,indent=2)+'\n')
(E/'resource-errors-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'cases':2,'originalResourceRawLost':True,'receiptMasksPrimary':True}))
