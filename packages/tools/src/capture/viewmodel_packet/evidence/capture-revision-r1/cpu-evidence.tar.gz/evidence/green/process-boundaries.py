import sys,os,json,tempfile,subprocess,hashlib
from pathlib import Path
from unittest.mock import patch
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P))
import test_boundary as stock,caller,boundary
HARNESS=stock.HARNESS.replace('import json, sys','import json, sys, os, subprocess').replace('code, result = caller.main', '''mode=os.environ.get('VM_MODE','success')
original_capture=capture
original_decoder=decoder
def capture(ready,spec,paths,record):
    if mode=='all-sinks':
        error=subprocess.CalledProcessError(7,['inert-capture'],output=b'raw\\xff',stderr=b'err\\xfe');error.unknown={'byte':b'\\x00'};raise error
    value=original_capture(ready,spec,paths,record)
    if mode=='release-unproved':value['released']=False
    return value
def writer(path,value):
    if Path(path).name=='result.json' and mode=='after-result-write':
        boundary.exclusive_json(path,value,cap=20*boundary.MIB)
        raise OSError('RESULT_CLOSE_FAILURE')
    if Path(path).name in ('result.json', 'review-thalune.consumed.json.fallback.json') and mode=='all-sinks':raise OSError('ALL_DISK_SINKS_FAILED')
    return boundary.exclusive_json(path,value,cap=20*boundary.MIB)
def emit(data):raise OSError('STDERR_SINK_FAILED')
import boundary
code, result = caller.main''').replace('verifier=lambda _: {}, runner=runner)', 'verifier=lambda _: {}, runner=runner, writer=writer, emit=emit)').replace("print(json.dumps({'code': code", "Path(sys.argv[3]).parent.joinpath('returned.json').write_text(json.dumps(boundary.raw(result)))\nif mode=='after-return':raise RuntimeError('FAILURE_AFTER_CALLER_RETURN')\nprint(json.dumps({'code': code")
rows=[]
root=Path(tempfile.mkdtemp(prefix='seven-',dir=E));repo=stock.Repo(root)
for i,spec in enumerate(repo.plan['units']):
 result=repo.run(i);assert result.returncode==0,result.stderr
 paths=repo.ready['paths'][spec['id']];r=json.loads((Path(paths['evidence'])/'result.json').read_text())
 assert r['accepted'] is False and r['ports']==['capture','release','decode']
 rows.append({'case':'seven-chain','unit':spec['id'],'head':repo.head,'callerExit':result.returncode,'files':len(r['outputManifest']),'reference':repo.previous[-1],'root':str(root)})
for mode in ['success','after-result-write','after-return','release-unproved','all-sinks']:
 root=Path(tempfile.mkdtemp(prefix=mode+'-',dir=E));repo=stock.Repo(root);repo.harness.write_text(HARNESS)
 spec,paths,_=repo.grant(0)
 p=subprocess.run([sys.executable,'-B',str(repo.harness),str(P),str(repo.packet),str(repo.ready_path),spec['id'],paths['grant']],env={**os.environ,'VM_MODE':mode},capture_output=True,timeout=15)
 (root/'stdout').write_bytes(p.stdout);(root/'stderr').write_bytes(p.stderr)
 expected=0 if mode=='success' else 1;assert p.returncode==expected,(mode,p.stderr)
 returned=json.loads((root/'returned.json').read_text());rr=returned['record']
 if mode=='all-sinks':
  assert not returned['durable'] and len(rr['persistenceErrors'])==3
  assert rr['primaryFailure']['attributes']['unknown']['byte']['base64']=='AA=='
 if mode=='release-unproved':assert rr['ports']==['capture','release'] and rr['released'] is False
 next_admitted=None
 result_file=Path(paths['evidence'])/'result.json'
 if result_file.exists():
  disk=json.loads(result_file.read_text());assert disk['accepted'] is False
  repo.previous=[{'unit':spec['id'],'callerExit':p.returncode,'resultSha256':stock.digest(result_file),'consumptionSha256':stock.digest(paths['consumption'])}]
  try:repo.admit(1);next_admitted=True
  except ValueError:next_admitted=False
  assert next_admitted==(mode=='success')
 rows.append({'case':mode,'root':str(root),'argv':p.args,'exit':p.returncode,'successorAdmitted':next_admitted,'durable':returned['durable'],'checksPassed':rr['checksPassed']})
(E/'process-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'sevenChainExits':[r['callerExit'] for r in rows[:7]],'count':sum(r['files'] for r in rows[:7]),'publicationCases':rows[7:]}))
