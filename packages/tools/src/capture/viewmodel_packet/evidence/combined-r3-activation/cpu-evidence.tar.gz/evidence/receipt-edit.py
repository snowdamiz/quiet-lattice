from pathlib import Path
p=Path('packages/tools/src/capture/viewmodel_packet/boundary.py');s=p.read_text();old="""def encoded(value):
    return (json.dumps(raw(value), allow_nan=False, separators=(',', ':')) + '\\n').encode()
"""
new="""CONSUMPTION_SCHEMA = 'viewmodel-consumption/1'
RESULT_SCHEMA = 'viewmodel-result/1'
CONSUMPTION_FIELDS = frozenset(('schema', 'authorizationId', 'unit', 'sourceHead', 'readySha256',
    'grantSha256', 'grantPath', 'entryToken', 'freeBytesAtAdmission', 'admission', 'previousOutputs'))
RESULT_FIELDS = CONSUMPTION_FIELDS | frozenset(('consumptionSha256', 'accepted', 'checksPassed', 'status',
    'released', 'output', 'outputManifest'))
FAILURE_FIELDS = frozenset(('primaryFailure', 'secondaryFailures', 'persistenceErrors'))


def protocol_document(record):
    \"\"\"Protocol fields stay JSON; only observations have graph semantics.

    Shared references in manifests/identities have ordinary JSON value semantics.
    Every other (including future unknown) field belongs to one observation graph,
    retaining aliases/cycles across those fields without changing the envelope.
    \"\"\"
    schema = record['schema']
    require(schema in (CONSUMPTION_SCHEMA, RESULT_SCHEMA), 'Unknown receipt schema')
    fields = RESULT_FIELDS if schema == RESULT_SCHEMA else CONSUMPTION_FIELDS
    document = {key: record[key] for key in record if key in fields}
    # Fail closed for invalid/cyclic protocol data instead of changing its type.
    json.dumps(document, allow_nan=False, separators=(',', ':'))
    if schema == RESULT_SCHEMA:
        require(type(record['accepted']) is bool and record['accepted'] is False, 'Result cannot accept itself')
        require(type(record['checksPassed']) is bool and type(record['released']) is bool, 'Result boolean contract')
        document['primaryFailure'] = raw(record['primaryFailure'])
        for key in ('secondaryFailures', 'persistenceErrors'):
            require(type(record.get(key, [])) is list, 'Failure list contract')
            document[key] = [raw(error) for error in record.get(key, [])]
    extras = {key: value for key, value in record.items() if key not in fields | FAILURE_FIELDS}
    document['observationEncoding'] = 'raw-graph-or-tree/1'
    document['observations'] = raw(extras)
    return document


def encoded(value):
    if type(value) is dict and value.get('schema') in (CONSUMPTION_SCHEMA, RESULT_SCHEMA):
        document = protocol_document(value)
    else:
        document = raw(value)
    return (json.dumps(document, allow_nan=False, separators=(',', ':')) + '\\n').encode()
"""
assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('packages/tools/src/capture/viewmodel_packet/caller.py');s=p.read_text().replace('from boundary import (MIB,','from boundary import (CONSUMPTION_SCHEMA, RESULT_SCHEMA, MIB,')
s=s.replace("# Hash, parse, success, identity and manifest use this single bounded snapshot.","# Hash, parse, schema, success, identity and manifest use this single bounded snapshot.\n        require(result.get('schema') == RESULT_SCHEMA and consumed.get('schema') == CONSUMPTION_SCHEMA, 'Predecessor receipt schema')")
s=s.replace("result.get('secondaryFailures') == [] and result.get('released') is True", "result.get('secondaryFailures') == [] and result.get('persistenceErrors') == [] and result.get('released') is True")
s=s.replace("return ready, spec, paths, {'authorizationId':", "return ready, spec, paths, {'schema': CONSUMPTION_SCHEMA, 'authorizationId':")
s=s.replace("record = {**consumed, 'consumptionSha256':", "record = {**consumed, 'schema': RESULT_SCHEMA, 'consumptionSha256':")
p.write_text(s)
p=Path('packages/tools/src/capture/viewmodel_packet/test_boundary.py');s=p.read_text().replace("receipt['ports']", "receipt['observations']['ports']");p.write_text(s)
