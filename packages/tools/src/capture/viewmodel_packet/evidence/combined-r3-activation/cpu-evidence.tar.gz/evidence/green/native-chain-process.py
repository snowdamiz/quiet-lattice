import sys,os,json,subprocess,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P))
from test_boundary import Repo,digest
rows=[]
for mode in ['actual-alias','copied-admission-control']:
 argv=[sys.executable,'-B',str(E/'native-chain-child.py'),mode]
 result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 (E/(mode+'-process.stdout')).write_bytes(result.stdout);(E/(mode+'-process.stderr')).write_bytes(result.stderr)
 assert result.returncode==0,result.stderr
 row=json.loads(result.stdout);root=Path(row['root']);repo=Repo.__new__(Repo);repo.root=root/'repo';repo.packet=repo.root/'packet';repo.head=row['head'];repo.ready_path=root/'ready.json';repo.ready=json.loads(repo.ready_path.read_text());repo.plan=json.loads((repo.packet/'inventory.json').read_text())
 repo.previous=[{'unit':'review-thalune','callerExit':result.returncode,'resultSha256':digest(row['resultPath']),'consumptionSha256':digest(row['consumptionPath'])}]
 try:repo.admit(1);admitted=True;error=None
 except Exception as caught:admitted=False;error=repr(caught)
 row.update(argv=argv,observedOsExit=result.returncode,successorAdmitted=admitted,successorError=error)
 assert admitted,row
 rows.append(row)
(E/'native-chain-process-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
