from pathlib import Path
p=Path('packages/tools/src/capture/viewmodel_packet/bindings.py');s=p.read_text();at=s.index('\ndef tree_binding(')
s=s[:at]+'''
VT_ENCODER = '/System/Library/Frameworks/VideoToolbox.framework/Versions/A/XPCServices/VTEncoderXPCService.xpc/Contents/MacOS/VTEncoderXPCService'
VT_ENCODER_SHA256 = 'a3af9d8f1d6423de4d6303c323f5132122181e01367155d325fc9bde3ed872b5'
VT_ENCODER_REQUIREMENT = 'identifier "com.apple.coremedia.videoencoder" and anchor apple'


def apple_encoder_binding():
    """Bind the exact Apple file; StageReceipts still proves current ownership."""
    path = canonical(VT_ENCODER)
    protected = []
    for item in (path, *path.parents):
        info = item.lstat()
        require(info.st_uid == 0 and not info.st_mode & 0o022, 'Apple encoder route must be root-owned and non-writable')
        require(stat.S_ISREG(info.st_mode) if item == path else stat.S_ISDIR(info.st_mode), 'Apple encoder route type')
        protected.append({'path': str(item), 'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid, 'mode': stat.S_IMODE(info.st_mode)})
    before = file_binding(path)
    require(before['sha256'] == VT_ENCODER_SHA256 and before['bytes'] == 167280, 'Unexpected Apple encoder bytes')
    codesign = file_binding('/usr/bin/codesign')
    observations = []
    for options in (['--verify', '--strict', '-R', '=' + VT_ENCODER_REQUIREMENT], ['-d', '--verbose=4', '-r-']):
        argv = ['/usr/bin/codesign', *options, str(path)]
        result = subprocess.run(argv, capture_output=True, timeout=5)
        require(len(result.stdout) + len(result.stderr) <= 65536, 'Encoder signature output ceiling')
        observations.append({'argv': argv, 'exit': result.returncode, 'stdout': result.stdout.decode('utf-8', 'strict'), 'stderr': result.stderr.decode('utf-8', 'strict')})
        require(result.returncode == 0, 'Apple encoder signature rejected')
    lines = (observations[-1]['stdout'] + observations[-1]['stderr']).splitlines()
    fields = dict(line.split('=', 1) for line in lines if '=' in line)
    require(fields.get('Identifier') == 'com.apple.coremedia.videoencoder' and fields.get('Platform identifier') == '26', 'Apple encoder platform identity')
    require('designated => ' + VT_ENCODER_REQUIREMENT in lines and len(fields.get('CDHash', '')) == 40, 'Apple encoder designated signature')
    require(file_binding(path) == before and file_binding('/usr/bin/codesign') == codesign, 'Encoder/signature tool changed during verification')
    for row in protected:
        info = Path(row['path']).lstat()
        require((info.st_dev, info.st_ino, info.st_uid, stat.S_IMODE(info.st_mode)) == (row['device'], row['inode'], row['uid'], row['mode']), 'Apple encoder route changed')
    return {'executable': before, 'codesign': codesign, 'protectedRoute': protected, 'requirement': VT_ENCODER_REQUIREMENT,
            'signature': fields, 'observations': observations,
            'scope': 'Exact owned-cohort executable only; current UID/birth/coalition/executable checks remain mandatory. External XPC ownership unqualified.'}

''' + s[at:]
s=s.replace("    python = file_binding(sys.executable)","    encoder = apple_encoder_binding()\n    python = file_binding(sys.executable)")
s=s.replace("Path('/usr/bin/caffeinate')]", "Path('/usr/bin/caffeinate'), Path(VT_ENCODER), Path('/usr/bin/codesign')]")
s=s.replace("    process[python['realpath']]", "    process[VT_ENCODER] = encoder['executable']['sha256']\n    process[python['realpath']]")
s=s.replace("'process_binary_sha256': process,", "'process_binary_sha256': process, 'appleEncoder': encoder,")
p.write_text(s)
