import sys,json
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path.cwd()/'packages/tools/src/capture/viewmodel_packet';sys.path.insert(0,str(P));import bindings
result=bindings.apple_encoder_binding();(E/'apple-encoder-binding.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
