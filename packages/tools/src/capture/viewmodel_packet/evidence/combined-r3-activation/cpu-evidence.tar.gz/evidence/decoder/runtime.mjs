import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import vm from 'node:vm';
import { pathToFileURL } from 'node:url';
import { registerHooks } from 'node:module';
import ts from '/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/node_modules/typescript/lib/typescript.js';
registerHooks({load(url,context,next){
  if(url.startsWith('file:')&&url.endsWith('.ts'))return {format:'module',shortCircuit:true,source:ts.transpileModule(fs.readFileSync(new URL(url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText};
  return next(url,context);
}});
const root='/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8';
const scratch='/private/tmp/vm-r3-fix-bpmhg9qg/decoder';
const runtimePath=`${root}/packages/client/src/entities/Multitool.js`;
const fixturePath=`${root}/packages/tools/src/capture/viewmodel_packet/fixture.mjs`;
const threePath=`${root}/packages/client/node_modules/three/build/three.module.js`;
const meterPath=`${root}/packages/shared/src/meters/rules.ts`;
const THREE=await import(pathToFileURL(threePath));
const meters=await import(pathToFileURL(meterPath));
const { installPageFixture }=await import(pathToFileURL(fixturePath));
const specs=JSON.parse(fs.readFileSync(`${root}/packages/tools/src/capture/viewmodel_packet/inventory.json`)).units.filter(s=>s.kind!=='review');
let load;
const context=vm.createContext({console});
const sources={three:THREE,'@astra/shared/meters':meters,
  '../core/Engine.js':{gltfLoader:()=>({load:(url,success)=>{assert.equal(load,undefined);load={url,success};}})},
  '../core/dispose.js':{disposeTree:()=>{}},
  './Ship.js':{characterMeterEnvironment:g=>({world:null,hazards:[],time:null,underwater:g.player.headUnderwater,sunlight:false,habitableBand:false,deepSpace:false,nearStar:false,nearBodies:false,footHazard:0})}};
const module=new vm.SourceTextModule(fs.readFileSync(runtimePath,'utf8'),{context,identifier:runtimePath});
await module.link(specifier=>{const exports=sources[specifier];assert.ok(exports,`Unexpected import ${specifier}`);return new vm.SyntheticModule(Object.keys(exports),function(){for(const [k,v] of Object.entries(exports))this.setExport(k,v);},{context});});
await module.evaluate();
const { Multitool }=module.namespace;
function scene(people){
  const root=new THREE.Group();
  for(const name of ['Skin',`VM_${people}_Tool`,...(people==='ulgani'?[]:['Bio'])]){
    const material=new THREE.MeshStandardMaterial({name});
    for(const slot of ['map','normalMap','roughnessMap','metalnessMap','aoMap',...(name==='Skin'?[]:['emissiveMap'])]){
      const t=new THREE.Texture({width:2048,height:2048});
      t.mipmaps=Array.from({length:12},(_,i)=>({width:2048>>i,height:2048>>i,data:new Uint8Array(1)}));
      material[slot]=t;
    }
    root.add(new THREE.Mesh(new THREE.BufferGeometry(),material));
  }
  for(const name of ['Muzzle','vm_hand_R','vm_hand_L']){const o=new THREE.Object3D();o.name=name;root.add(o);}
  root.getObjectByName('Muzzle').position.set(.1,-.2,-.4);
  return root;
}
function setup(people){
  const game={net:null,mode:'foot',director:{},build:{people},time:0,
    player:{headUnderwater:false,grounded:false,hSpeed:0,landShake:0},ship:{meterProfile:meters.meterProfile({ship:null})},
    cam:{frame:null,pos:new THREE.Vector3(),quat:new THREE.Quaternion()},camWorld:new THREE.Vector3(),camWorldQuat:new THREE.Quaternion(),
    engine:{camera:new THREE.PerspectiveCamera(70,16/9,.1,10000),viewCamera:new THREE.PerspectiveCamera(55,16/9,.01,10)},
    flora:{raycast:()=>null}};
  // Only constructor resource allocation is bypassed; every invoked method is
  // the full frozen module's real implementation. Synthetic model resources
  // satisfy its actual loader callback without loading assets or rendering.
  const tool=Object.create(Multitool.prototype);
  Object.assign(tool,{game,meterNet:null,viewModelPeople:people,viewModel:scene(people),viewModelRequest:0,
    view:new THREE.Group(),basePos:new THREE.Vector3(),swayX:0,swayY:0,stride:0,raise:1,
    beamMat:{uniforms:{uTime:{value:0},uColor:{value:new THREE.Color()}}},meter:{heat:0,charge:0,overheated:false},
    kick:0,muzzle:null,beam:new THREE.Group(),spark:new THREE.Group(),hitLight:new THREE.PointLight(),vmLight:new THREE.PointLight(),viewModelGlow:[]});
  tool.view.add(tool.viewModel);tool.muzzle=tool.viewModel.getObjectByName('Muzzle');
  game.multitool=tool;globalThis.window={game};installPageFixture();const api=window.__viewmodelPacket;
  assert.equal(tool.update,Multitool.prototype.update);assert.equal(api.state.frame,0);assert.equal(api.state.elapsed,0);
  return {game,tool,api};
}
function facts(c,file){return {file,frame:c.api.state.frame,elapsed:c.api.state.elapsed,dt:c.api.state.dt,raise:c.tool.raise,sway:[c.tool.swayX,c.tool.swayY],visible:c.tool.view.visible,modelAttached:!!c.tool.viewModel&&c.tool.viewModel.parent===c.tool.view,loaderPending:c.api.state.loaderPending,underwater:c.game.player.headUnderwater,heat:c.tool.heat,overheated:c.tool.overheated,firing:c.tool.firing,beamVisible:c.tool.beam.visible,input:c.api.state.input,raiseSeconds:c.api.state.raiseSeconds??null};}
function initial(c){c.api.step(0);for(let i=0;i<24;i++)c.api.step();assert.equal(c.api.state.frame,25);}
function switchGap(c,people){c.api.state.loaderPending=true;c.game.build.people=people;c.api.step(0);assert.ok(load);assert.equal(c.tool.raise,0);assert.equal(c.tool.viewModel,null);}
function attach(c,people){assert.ok(load.url.endsWith(`fp_${people}.glb`));const request=load;load=undefined;request.success({scene:scene(people)});c.api.state.loaderPending=false;assert.equal(c.tool.raise,0);}
const timelines=[];
for(const spec of specs)for(const variant of spec.kind==='view'?['full','zero-raise-reset','zero-settled','extra-updates']:['full','extra-updates']){
  const c=setup(spec.fromPeople??spec.people);initial(c);const incoming=facts(c,'incoming');const frames=[];
  if(spec.fromPeople){switchGap(c,spec.people);frames.push(facts(c,'16x9-switch-gap.png'));if(variant==='extra-updates'){for(let i=0;i<240;i++)c.api.step();c.api.step(0);c.api.step(0);}attach(c,spec.people);for(let i=0;i<24;i++)c.api.step();frames.push(facts(c,'16x9-switch-settled.png'));}
  for(const file of spec.files.filter(n=>n.endsWith('.png')&&n!=='sheet.png'&&!n.includes('switch-'))){
    const aspect=file.startsWith('21x9')?21/9:16/9;
    for(const camera of [c.game.engine.camera,c.game.engine.viewCamera]){camera.aspect=aspect;camera.updateProjectionMatrix();}
    const pose=file.replace(/^(16x9|21x9)-|\.png$/g,'');
    if(variant==='extra-updates'){for(let i=0;i<240;i++)c.api.step();c.api.step(0);c.api.step(0);}
    if(variant==='zero-raise-reset'&&pose==='raise-0'){
      c.game.player.headUnderwater=true;c.api.step(0);c.game.player.headUnderwater=false;c.api.state.raiseSeconds=0;c.api.step(0);
    }else if(variant==='zero-settled'&&pose==='fire'){
      c.api.state.raiseSeconds=null;c.api.step(0,{held:true});
    }else c.api.pose(pose);
    frames.push(facts(c,file));
  }
  timelines.push({unit:spec.id,variant,incoming,frames});
}
const transitions=[];
for(const people of ['thalune','ixari','ulgani']){
  for(const kind of ['underwater','switch','initial'])for(const count of [0,1,23,24,120]){
    const c=setup(kind==='switch'?{thalune:'ulgani',ixari:'thalune',ulgani:'ixari'}[people]:people);let before;
    if(kind==='underwater'){initial(c);c.api.pose('underwater');before=facts(c);c.game.player.headUnderwater=false;}
    else if(kind==='switch'){
      switchGap(c,people);before=facts(c);attach(c,people);
    }else{c.tool.raise=0;before=facts(c);}
    if(count===0)c.api.step(0);for(let i=0;i<count;i++)c.api.step();const after=facts(c);
    const expected=Math.min(1,Array.from({length:count}).reduce(s=>s+2.6/60,0));assert.equal(after.raise,expected);
    transitions.push({people,kind,count,before,after});
  }
  const c=setup(people);initial(c);c.api.pose('neutral');let before=facts(c);c.api.step(0);let after=facts(c);assert.equal(before.raise,after.raise);transitions.push({people,kind:'already-settled-zero',before,after});
  c.game.player.headUnderwater=true;before=facts(c);c.api.step(0);after=facts(c);assert.equal(after.raise,0);assert.deepEqual(before.sway,after.sway);transitions.push({people,kind:'immediate-downward-reset',before,after});
  c.api.pose('sway-left');before=facts(c);c.api.step(0,{dx:-100});after=facts(c);assert.deepEqual(after.sway,before.sway);transitions.push({people,kind:'zero-time-sway-reversal',before,after});
  c.api.pose('sway-right');after=facts(c);assert.ok(Math.abs(after.sway[0]-.035)<1e-6);transitions.push({people,kind:'producer-sway-reversal',before,after});
}
const files=[runtimePath,fixturePath,threePath,`${root}/packages/client/node_modules/three/build/three.core.js`,meterPath,process.execPath];
const sourceHashes=Object.fromEntries(files.map(path=>{const raw=fs.readFileSync(path);return [path,{bytes:raw.length,sha256:crypto.createHash('sha256').update(raw).digest('hex')}];}));
const report={version:process.version,sourceHashes,ports:'Full frozen Multitool.js and fixture install/step/pose, real Three and meter rules. Constructor bypass; inert loader/disposal/environment import ports with synthetic CPU model resources. No rendering/native/assets/visual qualification.',timelines,transitions};
fs.writeFileSync(`${scratch}/runtime-facts-v4.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({timelines:timelines.length,frames:timelines.reduce((n,t)=>n+t.frames.length,0),transitions:transitions.length,sourceHashes},null,2));
delete globalThis.window;
