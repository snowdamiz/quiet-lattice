import ast, copy, hashlib, importlib.util, json, os, shutil, subprocess, sys, time, unittest
from pathlib import Path
S = Path(__file__).resolve().parent
R = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
H = R/'packages/tools/src/capture/viewmodel_packet'
BASE = S.parent/'original'
OLD = Path('/private/tmp/p1-e05-t03-decoder-r3-69vr1kgc')
PY = '/Users/andreyyurlov/.local/share/uv/python/cpython-3.10.22-macos-aarch64-none/bin/python3.10'
NODE = '/Users/andreyyurlov/.local/share/fnm/node-versions/v26.12.1/installation/bin/node'
ENV = {'PATH':'/usr/bin:/bin','LANG':'C','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/Users/andreyyurlov/.cache/uv/archive-v0/a88MR2jSm399x3XK/lib/python3.10/site-packages','TMPDIR':str(S/'tmp'),'NODE_DISABLE_COMPILE_CACHE':'1','GIT_OPTIONAL_LOCKS':'0',**{key:'1' for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS')}}
def hashes(path):
    raw=Path(path).read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def write(path,value):
    with Path(path).open('xb') as f:
        f.write(value if isinstance(value,bytes) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
realrun=subprocess.run
records=[]
def run(label,argv):
    folder=S/label;folder.mkdir(parents=True)
    command=['/usr/bin/sandbox-exec','-f',str(S/'readonly.sb'),*argv]
    record={'argv':argv,'executionArgv':command,'cwd':str(R),'environment':ENV}
    write(folder/'invocation.json',record)
    begin=time.monotonic();p=realrun(command,cwd=R,env=ENV,capture_output=True,timeout=180)
    write(folder/'stdout',p.stdout);write(folder/'stderr',p.stderr)
    record.update(exit=p.returncode,seconds=time.monotonic()-begin,stdout=hashes(folder/'stdout'),stderr=hashes(folder/'stderr'))
    write(folder/'result.json',record);records.append(record)
    print(label,p.returncode,flush=True)
    return p
mode=sys.argv[1]
if mode=='setup':
    write(S/'readonly.sb',f'(version 1)\n(allow default)\n(deny network*)\n(deny file-write*)\n(allow file-write* (subpath "{S}") (literal "/dev/null"))\n'.encode())
    paths=[H/name for name in ('inspect_packet.py','fixture.mjs','inventory.json')]+[BASE/'inspect_packet.py',BASE/'test_inspect.py',R/'packages/client/src/entities/Multitool.js',Path(PY),Path(NODE),OLD/'runtime.mjs',Path('/private/tmp/p1-e05-t03-r3-nv25vo_2/REPORT-FINAL.txt'),Path('/private/tmp/p1-e05-t03-r3-nv25vo_2/DECODER-REPORT.txt')]
    write(S/'before.json',{str(p):hashes(p) for p in paths})
    for name in ('inspect_packet.py','test_inspect.py'):
        blob=realrun(['/usr/bin/git','show',f'80d348154d1fc9497d6989bf3f3544859e7b0477:packages/tools/src/capture/viewmodel_packet/{name}'],cwd=R,capture_output=True,check=True).stdout
        assert (BASE/name).read_bytes()==blob
elif mode in ('red-replay','green-replay'):
    source=BASE if mode=='red-replay' else H
    results=[]
    for invocation in sorted((OLD/'neighbors').glob('*/*/invocation.json')):
        unit=invocation.parent.parent.name;label=invocation.parent.name
        if not (label.startswith('underwater') or label.startswith('sway')):continue
        argv=[PY,'-B',str(source/'inspect_packet.py'),'--inventory',str(BASE/'inventory.json'),'--unit',unit,'--output',str(invocation.parent/'output'),'--manifest',str(invocation.parent/'manifest.json')]
        p=run(f'{mode}/{unit}/{label}',argv);result=json.loads(p.stdout or p.stderr)
        value=json.loads((invocation.parent/'output/observations.json').read_text())
        assert result.get('observations',result.get('evidence',{}).get('observations'))==value
        good='valid' in label
        assert p.returncode==(0 if mode=='red-replay' or good else 1)
        results.append({'unit':unit,'case':label,'exit':p.returncode,'primaryFailure':result.get('primaryFailure')})
    write(S/f'{mode}.json',results)
elif mode in ('red-tests','green-tests'):
    p=run(mode,[PY,'-B',str(S/'run.py'),mode+'-inner']);assert p.returncode==(1 if mode=='red-tests' else 0)
elif mode in ('red-tests-inner','green-tests-inner'):
    label=mode[:-6];folder=S/label
    tests=module(H/'test_inspect.py','decoder_tests')
    if label=='red-tests':
        tests.HERE=BASE;tests.inspector=module(BASE/'inspect_packet.py','base_inspector')
    # Retain test directories and every CLI input before subsequent mutations.
    tests.tempfile.TemporaryDirectory.cleanup=lambda self:self._finalizer.detach()
    def recorded(argv,**kwargs):
        target=folder/'cli'/f'{len(records):04d}';target.mkdir(parents=True)
        output=Path(argv[argv.index('--output')+1]);manifest=Path(argv[argv.index('--manifest')+1])
        shutil.copytree(output,target/'output');shutil.copyfile(manifest,target/'manifest.json')
        row={'argv':argv,'cwd':str(Path.cwd()),'environment':dict(os.environ),'inspector':hashes(argv[2])}
        write(target/'invocation.json',row)
        p=realrun(argv,**kwargs)
        write(target/'stdout',p.stdout.encode());write(target/'stderr',p.stderr.encode())
        row.update(exit=p.returncode,stdout=hashes(target/'stdout'),stderr=hashes(target/'stderr'))
        write(target/'result.json',row);records.append(row)
        return p
    tests.subprocess.run=recorded
    names=unittest.defaultTestLoader.getTestCaseNames(tests.InspectorTests)
    if label=='red-tests':
        names=[name for name in names if any(s in name for s in ('initial_clock','underwater_recovery','sway_reachability','every_endpoint','zero_time_resets'))]
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(tests.InspectorTests(name) for name in names))
    write(folder/'commands.json',records)
    write(folder/'summary.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'cli':len(records),'exitCounts':{str(c):sum(r['exit']==c for r in records) for c in (0,1)},'inspector':hashes(tests.HERE/'inspect_packet.py'),'testsSource':hashes(H/'test_inspect.py')})
    sys.exit(0 if result.wasSuccessful() else 1)
elif mode=='oracle-controls':
    p=run('oracle-controls-run',[PY,'-B',str(S/'run.py'),'oracle-controls-inner']);assert p.returncode==0
elif mode=='oracle-controls-inner':
    tests=module(H/'test_inspect.py','oracle_controls_tests')
    facts=json.loads((S/'runtime-facts-v4.json').read_text());cases=[]
    for timeline in facts['timelines']:
        unit=timeline['unit'];label=timeline['variant'];folder=S/'oracle-controls'/unit/label;folder.mkdir(parents=True)
        fixture=tests.Packet(folder,unit)
        for entry,observed in zip(fixture.value['frames'],timeline['frames']):
            assert entry['file']==observed['file'];entry.update(observed)
        fixture.value['unknownOracleFact']={'unit':unit,'variant':label}
        fixture.write();write(folder/'manifest.json',{'files':fixture.manifest})
        p=run(str(folder.relative_to(S))+'/cli',[PY,'-B',str(H/'inspect_packet.py'),'--inventory',str(BASE/'inventory.json'),'--unit',unit,'--output',str(fixture.output),'--manifest',str(folder/'manifest.json')])
        assert p.returncode==0,(unit,label,p.stderr)
        assert json.loads(p.stdout)['observations']==fixture.value
        cases.append({'unit':unit,'case':label,'exit':p.returncode})
    write(S/'oracle-controls.json',cases)
elif mode=='oracle-packets':
    p=run('oracle-runtime-run',[PY,'-B',str(S/'run.py'),'oracle-packets-inner']);assert p.returncode==0
elif mode=='oracle-packets-inner':
    tests=module(H/'test_inspect.py','oracle_packet_tests')
    facts=json.loads((S/'runtime-facts.json').read_text())
    cases=[]
    for timeline in facts['timelines']:
        unit=timeline['unit'];seed=S/'oracle-seeds'/unit;seed.mkdir(parents=True)
        fixture=tests.Packet(seed,unit)
        for entry,observed in zip(fixture.value['frames'],timeline['frames']):
            assert entry['file']==observed['file'];entry.update(observed)
        fixture.value['unknownOracleFact']={'unit':unit,'fields':['real raise','real sway','real fixture clock']}
        fixture.write()
        variants=[('full-runtime',copy.deepcopy(fixture.value),0)]
        for index,frame in enumerate(fixture.value['frames']):
            if index==0:
                value=copy.deepcopy(fixture.value);tests.retime(value,0,2,0,0)
                variants.append(('initial-zero',value,1))
            if frame['file'] in ('16x9-switch-settled.png','21x9-neutral.png'):
                for count in (0,1,23,24,120):
                    value=copy.deepcopy(fixture.value)
                    tests.retime(value,index,max(1,count),count/60,1/60 if count else 0)
                    variants.append((frame['file']+f'-{count}',value,0 if count>=24 else 1))
            if 'sway-' in frame['file']:
                value=copy.deepcopy(fixture.value);tests.retime(value,index,1,0,0)
                variants.append((frame['file']+'-zero-reversal',value,1))
        for label,value,expected in variants:
            case=S/'oracle-packets'/unit/label;case.mkdir(parents=True)
            shutil.copytree(fixture.output,case/'output')
            (case/'output/observations.json').write_text(json.dumps(value,separators=(',',':')))
            write(case/'manifest.json',{'files':[dict(path=p.name,**hashes(p)) for p in sorted((case/'output').iterdir())]})
            p=run(str(case.relative_to(S))+'/cli',[PY,'-B',str(H/'inspect_packet.py'),'--inventory',str(H/'inventory.json'),'--unit',unit,'--output',str(case/'output'),'--manifest',str(case/'manifest.json')])
            result=json.loads(p.stdout or p.stderr)
            assert result.get('observations',result.get('evidence',{}).get('observations'))==value
            assert p.returncode==expected,(unit,label,p.stderr)
            cases.append({'unit':unit,'case':label,'exit':p.returncode,'primaryFailure':result.get('primaryFailure')})
    write(S/'oracle-packets.json',cases)
elif mode.startswith('runtime'):
    p=run(mode,[NODE,'--experimental-vm-modules',str(S/'runtime.mjs')]);assert p.returncode==0
else:raise ValueError(mode)
