import ast,copy,hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent; R=Path.cwd(); P=R/'packages/tools/src/capture/viewmodel_packet'; BASE='80d348154d1fc9497d6989bf3f3544859e7b0477'; REVIEW=Path('/private/tmp/p1-e05-t03-r3-nv25vo_2')
def fsha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
before=json.loads((REVIEW/'before.json').read_text());old=json.loads((E/'original/readiness.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
changed={}
for name,row in before['tracked'].items():
 digest=fsha(R/name)
 if digest!=row['sha256']:changed[name]={'old':row['sha256'],'new':digest}
expected={'README.md','bindings.py','boundary.py','caller.py','entry.mjs','entry.test.mjs','inspect_packet.py','inventory.json','test_boundary.py','test_inspect.py'}
assert set(changed)=={str(P.relative_to(R)/n) for n in expected},changed
for n in (E/'original').iterdir():
 assert n.read_bytes()==subprocess.check_output(['git','show',f'{BASE}:{P.relative_to(R)/n.name}']),n
protected=json.loads((P/'evidence/capture-revision-r1/protected-audit.txt').read_text())
for group,files in protected['groups'].items():
 for name,row in files.items():assert fsha(R/name)==row['sha256'],name
for name,want in protected['helpers'].items():assert fsha(R/name)==want,name
for name,want in protected['reports'].items():assert fsha(name)==want,name
for name,row in before['priorEvidence'].items():assert fsha(name)==row['sha256'],name
reviewindex=json.loads((REVIEW/'FINAL-INDEX.json').read_text())
for name,row in reviewindex.items():assert fsha(REVIEW/name)==row['sha256'],name
syntax=[]
for n in P.glob('*.py'):ast.parse(n.read_text(),filename=str(n));syntax.append(n.name)
assert fsha(P/'inspect_packet.py')=='eccaf8fc817681e8442d4f25bfe9dbc6d80a01bac53cab6371bc0d8ae0ef1f0e'
assert fsha(P/'test_inspect.py')=='8a77ba1d427417e7b50d884da1fab7614765244c0d2deed93e679cd32236fad3'
sys.path.insert(0,str(P));import caller,boundary,bindings
os.environ['PATH']=old['bindings']['path']
ready=caller.prepare() # Exactly one final binding refresh after all executable source edits.
for key,value in old['bindings'].items():
 if key not in ('bindings','process_binary_sha256'):assert ready['bindings'][key]==value,key
assert ready['bindings']['process_binary_sha256']=={**old['bindings']['process_binary_sha256'],bindings.VT_ENCODER:bindings.VT_ENCODER_SHA256}
oldpins={x['path']:x for x in old['bindings']['bindings']};newpins={x['path']:x for x in ready['bindings']['bindings']}
assert set(newpins)-set(oldpins)=={bindings.VT_ENCODER,'/usr/bin/codesign'} and not set(oldpins)-set(newpins)
pinchanges={p for p in oldpins if oldpins[p]!=newpins[p]}
assert pinchanges=={str(P/n) for n in ['boundary.py','bindings.py','caller.py','entry.mjs','inspect_packet.py','inventory.json']},pinchanges
plan=boundary.validate_inventory(json.loads((P/'inventory.json').read_text()));oldplan=json.loads((E/'original/inventory.json').read_text())
assert {k:v for k,v in plan.items() if k not in ('runtimeEnabled','entryEnabled')}=={k:v for k,v in oldplan.items() if k not in ('runtimeEnabled','entryEnabled')}
assert ready['runtimeEnabled'] and ready['entryEnabled'] and plan['runtimeEnabled'] and plan['entryEnabled']
assert not ready['allUnitsQualified'] and not ready['nativeQualified']
assert 'RUNTIME_ENABLED = True' in (P/'caller.py').read_text() and 'ENTRY_ENABLED = true' in (P/'entry.mjs').read_text()
paths=lambda r:sorted(set(v for row in r['paths'].values() for v in row.values())|set(r['containers'].values()))
for group in (paths(old),paths(ready)):
 assert len(group)==31
 for p in group:boundary.canonical(p,absent=True)
ready['sourceProvenance']=copy.deepcopy(old['sourceProvenance'])
provenance=ready['sourceProvenance'];provenance['priorPacketRevision']=provenance['packetRevision']
provenance['packetRevision']={'base':BASE,'baseTree':before['tree'],'review':str(REVIEW/'REPORT-FINAL.txt'),'reviewSha256':fsha(REVIEW/'REPORT-FINAL.txt'),'scope':'R3 stable protocol envelope, unified timeline, exact Apple encoder prerequisite and guarded source activation; independent VMR4 required','sharedT15Unchanged':True,'finalHeadBinding':'post-commit handoff records exact candidate HEAD/tree; parent must bind it in a separate future external grant after R4 PASS'}
provenance['legacyReviewedSourceScope']='accepted runtime/art SOURCE R3 anchor only; enabled combined packet requires fresh VMR4'
provenance['encoderPrerequisite']={'referenceSource':'6b4073305af21efe5c6cf5ecc09f78406b637a42','diagnosis':'/private/tmp/p1-e07-t14-native-failure-3pevk0mk/APPENDIX-C2.md','diagnosisSha256':fsha('/private/tmp/p1-e07-t14-native-failure-3pevk0mk/APPENDIX-C2.md'),'scope':'VM-specific exact file/signature and inert unchanged StageReceipts ownership proof only; external/native XPC ownership remains unqualified'}
raw=(json.dumps(ready,indent=2)+'\n').encode();(E/'final-readiness.json').write_bytes(raw);(P/'readiness.json').write_bytes(raw)
W=Path('/private/tmp/vm-r2-fix-pern8y1v');oldfreeze=json.loads((W/'freeze.json').read_text());reused=[]
assert oldfreeze['sourceDigestUnchanged']==ready['bindings']['sourceDigest']
assert oldfreeze['dependenciesUnchanged']==ready['bindings']['trees']
for line in (W/'commands.jsonl').read_text().splitlines():
 row=json.loads(line)
 if row['name'] in ('shared-lifecycle','client-runtime','typecheck'):
  assert row['exit']==0 and fsha(W/(row['name']+'.log'))==row['logSha256'];reused.append(row)
assert len(reused)==3
proof={'status':'ENABLED_SOURCE_CPU_ONLY_AWAITING_R4_AND_PARENT_GRANT','base':BASE,'baseTree':before['tree'],'unchangedTrackedCount':len(before['tracked'])-len(changed),'changedPriorTracked':changed,'priorTracked':before['tracked'],'protected':protected,'protectedCounts':{k:len(v) for k,v in protected['groups'].items()},'protectedManifestSha256':fsha(P/'evidence/capture-revision-r1/protected-audit.txt'),'priorEvidenceVerified':before['priorEvidence'],'reviewIndexSha256':fsha(REVIEW/'FINAL-INDEX.json'),'reviewFilesVerified':len(reviewindex),'dependenciesUnchanged':ready['bindings']['trees'],'ignoredInventoryUnchanged':ready['bindings']['ignoredInventorySha256'],'sourceDigestUnchanged':ready['bindings']['sourceDigest'],'readinessSha256':hashlib.sha256(raw).hexdigest(),'bindingChanges':{p:newpins[p] for p in sorted(pinchanges|{bindings.VT_ENCODER,'/usr/bin/codesign'})},'allProspectivePathsAbsent':paths(ready),'historicalPathsAbsent':paths(old),'flagsTrue':True,'inventorySha256':fsha(P/'inventory.json'),'inventory':plan,'pythonSelfObservation':ready['pythonSelfObservation'],'syntax':syntax,'newSourceHashes':{str(p.relative_to(R)):fsha(p) for p in P.iterdir() if p.is_file()},'reusedExactCommands':reused,'reuseBoundary':'100 shared lifecycle and 110 client tests, four-package typecheck: unchanged complete non-packet source digest, all prior tracked bytes outside explicit packet edits, exact toolchain/dependency trees and original command/log hashes; historical execution, not freshly recounted'}
(E/'freeze.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['status','base','unchangedTrackedCount','protectedCounts','readinessSha256','sourceDigestUnchanged','flagsTrue','reviewFilesVerified']}))
