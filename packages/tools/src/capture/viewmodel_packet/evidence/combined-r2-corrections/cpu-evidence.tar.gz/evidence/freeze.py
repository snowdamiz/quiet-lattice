import ast,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent; R=Path.cwd(); P=R/'packages/tools/src/capture/viewmodel_packet'; BASE='182fc27d1a5459270e2a3c4673f8e70b86ef3a33'
sha=lambda b:hashlib.sha256(b).hexdigest()
def fsha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
before=json.loads(Path('/private/tmp/p1-e05-t03-r2-yrN5o2/before.json').read_text());old=json.loads((E/'original/readiness.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
changed={}
for name,row in before['tracked'].items():
 h=fsha(R/name)
 if h!=row['sha256']:changed[name]={'old':row['sha256'],'new':h}
expected={'boundary.py','caller.py','entry.mjs','entry.test.mjs','inspect_packet.py','native.py','test_inspect.py','test_revision.py'}
assert set(changed)=={str(P.relative_to(R)/n) for n in expected},changed
for n in (E/'original').iterdir():
 rel=P.relative_to(R)/n.name; original=subprocess.check_output(['git','show',f'{BASE}:{rel}'])
 assert n.read_bytes()==original,n
protected=json.loads((P/'evidence/capture-revision-r1/protected-audit.txt').read_text())
for group,files in protected['groups'].items():
 for name,row in files.items():assert fsha(R/name)==row['sha256'],name
for name,want in protected['helpers'].items():assert fsha(R/name)==want,name
for name,want in protected['reports'].items():assert fsha(name)==want,name
# All prior committed packet evidence and all other tracked working bytes still equal independent R2.
for n in P.glob('*.py'):ast.parse(n.read_text(),filename=str(n))
sys.path.insert(0,str(P));import caller,boundary
os.environ['PATH']=old['bindings']['path']
ready=caller.prepare() # The sole final disabled readiness refresh.
for key,value in old['bindings'].items():
 if key!='bindings':assert ready['bindings'][key]==value,key
oldpins={x['path']:x for x in old['bindings']['bindings']};newpins={x['path']:x for x in ready['bindings']['bindings']}
assert set(oldpins)==set(newpins)
pinchanges={p for p in oldpins if oldpins[p]!=newpins[p]}
assert pinchanges=={str(P/n) for n in ['boundary.py','caller.py','entry.mjs','inspect_packet.py','native.py']},pinchanges
assert all(ready[k]==old[k] for k in ['paths','containers','inventorySha256','runtimeEnabled','entryEnabled','allUnitsQualified'])
assert not ready['runtimeEnabled'] and not ready['entryEnabled']
assert 'RUNTIME_ENABLED = False' in (P/'caller.py').read_text() and 'ENTRY_ENABLED = false' in (P/'entry.mjs').read_text()
plan=boundary.validate_inventory(json.loads((P/'inventory.json').read_text()));assert not plan['runtimeEnabled'] and not plan['entryEnabled']
paths=sorted(set(v for row in ready['paths'].values() for v in row.values())|set(ready['containers'].values()));assert len(paths)==31 and all(not Path(p).exists() for p in paths)
ready['sourceProvenance']=old['sourceProvenance']
ready['sourceProvenance']['packetRevision']={'base':BASE,'baseTree':before['tree'],'review':'/private/tmp/p1-e05-t03-r2-yrN5o2/REPORT-FINAL.txt','reviewSha256':fsha('/private/tmp/p1-e05-t03-r2-yrN5o2/REPORT-FINAL.txt'),'scope':'three task-local combined VMR2 corrections; independent VMR3 required','sharedT15Unchanged':True,'finalHeadBinding':'post-commit handoff records the exact new HEAD/tree; any future external grant must bind that clean HEAD'}
ready['sourceProvenance']['legacyReviewedSourceScope']='accepted runtime/art SOURCE R3 anchor only; corrected combined packet requires fresh VMR3'
b=(json.dumps(ready,indent=2)+'\n').encode();(E/'final-readiness.json').write_bytes(b);(P/'readiness.json').write_bytes(b)
reports=['/private/tmp/p1-e05-t03-r2-yrN5o2/REPORT-FINAL.txt','/private/tmp/p1-e05-t03-decoder-r2-kf878yxf/REPORT.txt','/private/tmp/p1-e07-t14-r3-independent-mrcerv14/REPORT.md']
proof={'status':'SOURCE_CPU_ONLY','base':BASE,'baseTree':before['tree'],'unchangedTrackedCount':len(before['tracked'])-len(changed),'changedPriorTracked':changed,'priorTracked':before['tracked'],'protected':protected,'protectedCounts':{k:len(v) for k,v in protected['groups'].items()},'protectedManifestSha256':fsha(P/'evidence/capture-revision-r1/protected-audit.txt'),'reports':{n:fsha(n) for n in reports},'dependenciesUnchanged':ready['bindings']['trees'],'ignoredInventoryUnchanged':ready['bindings']['ignoredInventorySha256'],'sourceDigestUnchanged':ready['bindings']['sourceDigest'],'readinessSha256':sha(b),'bindingChanges':{p:newpins[p] for p in sorted(pinchanges)},'allProspectivePathsAbsent':paths,'flagsFalse':True,'inventorySha256':fsha(P/'inventory.json'),'inventory':plan,'pythonSelfObservation':ready['pythonSelfObservation'],'newSourceHashes':{str(p.relative_to(R)):fsha(p) for p in P.iterdir() if p.is_file()}}
(E/'freeze.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['status','base','unchangedTrackedCount','protectedCounts','readinessSha256','sourceDigestUnchanged','flagsFalse']}))
