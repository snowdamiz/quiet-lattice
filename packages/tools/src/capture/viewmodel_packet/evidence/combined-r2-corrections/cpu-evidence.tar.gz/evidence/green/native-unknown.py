from pathlib import Path
E=Path(__file__).resolve().parent
prefix=(E/'green/lifecycle.py').read_text().split("row=case('adapter-missing-resolver'")[0]
exec(compile(prefix,str(E/'green/lifecycle.py'),'exec'))
for cyclic in [False,True]:
 originals=[]
 def setup(stack,root,record,trace):
  inert_init_ports(stack,root,record,trace)
  stack.enter_context(patch.object(jb.StationJob,'members',lambda _:[{'pid':99999999,'birth':[1,2],'uid':os.getuid(),'pgid':99999999,'status':2}]))
  def current_commands(rows):
   trace.append('actual-observer-command-port')
   error=subprocess.TimeoutExpired(['inert-observer'],.01,output=b'RAW\xff',stderr=b'ERR\xfe')
   error.unknown={'retained':b'\x00','nested':{}}
   if cyclic:error.unknown['nested']['sourceError']=error
   originals.append(error);raise error
  stack.enter_context(patch.object(stages,'current_commands',current_commands))
 row=case('native-cyclic-'+str(cyclic),setup)
 assert len(originals)==1
 assert 'inert-drain' in row['trace']
 assert row['record']['native']['released'] is False
 if cyclic:
  from test_r2 import graph_decode
  recovered=graph_decode(row['record']['native']['callbackFailure'])
  assert recovered['attributes']['unknown']['nested']['sourceError'] is recovered
  assert recovered['attributes']['output']==b'RAW\xff'
  assert recovered['attributes']['stderr']==b'ERR\xfe'
 else:assert row['error']['type']=='TimeoutExpired'
(E/'native-unknown-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps([{'name':r['name'],'errorType':r['error'].get('type','rawGraph'),'trace':r['trace'],'released':r['record']['native']['released']}for r in results]))
