import sys,os,json,subprocess,tempfile,contextlib,time,signal,copy
from pathlib import Path
from unittest.mock import patch
E=Path(__file__).resolve().parent; R=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8'); P=R/'packages/tools/src/capture/viewmodel_packet'
sys.path.insert(0,str(P)); import native,boundary,bindings,caller
sys.path.insert(0,str(bindings.HELPERS)); import round4_job_boundary as jb,run_round4_browser_proof as proof,run_round4_remaining8 as stages
ready=json.loads((P/'readiness.json').read_text()); spec=caller.plan()['units'][0]
results=[]
original_mkdtemp=tempfile.mkdtemp

def case(name,configure):
 root=Path(original_mkdtemp(prefix='vmr-',dir=E)); e=root/'e';e.mkdir(); output=root/'output';output.mkdir()
 paths={'ready':str(root/'ready'),'consumption':str(root/'consumption'),'evidence':str(e),'output':str(output)}
 record={'entryToken':'inert','sourceHead':'0'*40,'consumptionSha256':'0'*64}; trace=[]
 def tmp(*args,**kw):
  kw['dir']=str(root); return original_mkdtemp(*args,**kw)
 def forbidden(*args,**kw):raise AssertionError('NO_NATIVE_PROCESS '+str(args))
 with contextlib.ExitStack() as stack:
  stack.enter_context(patch.object(tempfile,'mkdtemp',tmp))
  stack.enter_context(patch.object(subprocess,'run',forbidden))
  stack.enter_context(patch.object(subprocess,'check_output',forbidden))
  configure(stack,root,record,trace)
  try:native.capture(ready,spec,paths,record); exception=None
  except BaseException as error:exception=boundary.raw(error)
 row={'name':name,'root':str(root),'record':boundary.raw(record),'error':exception,'trace':trace,'timerAfter':signal.getitimer(signal.ITIMER_REAL)}
 (E/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');results.append(row);return row

def inert_init_ports(stack,root,record,trace):
 def start(self):
  trace.append('inert-start');self.root={'pid':99999999,'birth':[1,2]};self.coalition_id=111111
 def status(self):
  self._r2_ticks=getattr(self,'_r2_ticks',0)+1
  if self._r2_ticks>1:self.state['exits']['capture']=0
  return self.state
 def drain(self,*a):trace.append('inert-drain');self.state['drained']=False;return self.state
 stack.enter_context(patch.object(jb.StationJob,'start',start));stack.enter_context(patch.object(jb.StationJob,'status',status));stack.enter_context(patch.object(jb.StationJob,'drain',drain));stack.enter_context(patch.object(jb.StationJob,'members',lambda _:[]));stack.enter_context(patch.object(jb,'kernel_tasks',lambda _: {'live':0,'future':{'raw':b'\x00\xff'}}))

row=case('adapter-missing-resolver',inert_init_ports)
assert row['record']['native']['wait']=='completed'
assert 'resolver' not in json.dumps(row['record']['native'].get('primaryFailure'))
assert row['record']['native']['released'] is False
# Actual helper observation succeeds at the same point with the shape it expects.
root=Path(original_mkdtemp(prefix='vmr-',dir=E));scratch=root/'scratch';scratch.mkdir();out=root/'out';out.mkdir()
from types import SimpleNamespace
job=SimpleNamespace(scratch=scratch,out=out,members=lambda:[])
fixed=copy.deepcopy(ready['bindings']);fixed['resolver']={'selectedExecutable':{'path':fixed['browserBinary']}}
obs=stages.StageReceipts(job,fixed,root/'private');obs.observe();assert (out/'observed_execution.json').exists()
results.append({'name':'adapter-shape-control','observed':True,'root':str(root)})

def constructor_failure(stack,root,record,trace):
 old=jb.write
 def write(path,value):
  if Path(path).name=='request.json':raise OSError('ENOSPC request write with no filename')
  return old(path,value)
 stack.enter_context(patch.object(jb,'write',write));stack.enter_context(patch.object(jb.StationJob,'start',lambda _:(_ for _ in ()).throw(AssertionError('start forbidden'))))
row=case('constructor-partial-ownership',constructor_failure)
state=row['record']['native']['jobState'];assert Path(state['scratch']).is_dir() and state['target'] and state['root'] is None and state['registered'] is False
assert not (Path(state['out'])/'boundary.json').exists()

def bootstrap_failure(stack,root,record,trace,exitcode):
 old=jb.write
 def run(argv,**kw):
  assert argv[:2]==['/bin/launchctl','bootstrap'];trace.append('inert-bootstrap')
  p=subprocess.CompletedProcess(argv,exitcode,stdout=b'BOOTSTRAP_STDOUT_UNKNOWN\0\xff',stderr=b'BOOTSTRAP_STDERR_UNKNOWN\xfe');p.unknown={'extra':b'\x00'};return p
 def write(path,value):
  if Path(path).name=='bootstrap.json':raise OSError('ENOSPC bootstrap receipt')
  return old(path,value)
 stack.enter_context(patch.object(subprocess,'run',run));stack.enter_context(patch.object(jb,'write',write))
for code in (0,17):
 row=case('bootstrap-receipt-'+str(code),lambda *a:bootstrap_failure(*a,code))
 calls=[e for e in row['record']['native']['helperCalls'] if e['operation']=='run'];assert len(calls)==1 and calls[0]['value']['returncode']==code and calls[0]['value']['unknown']['extra']['base64']=='AA=='
 assert row['record']['native']['released'] is False

# The actual retained wait catches ordinary observer errors; check whether producer facts escape.
def observer_failure(stack,root,record,trace):
 inert_init_ports(stack,root,record,trace)
 def observe(self):
  trace.append('observe-primary')
  e=subprocess.TimeoutExpired(['inert-observer'],.01,output=b'RAW\xff',stderr=b'ERR\xfe');e.unknown={'secretlessFuture':b'\x00'};raise e
 stack.enter_context(patch.object(stages.StageReceipts,'observe',observe))
row=case('observer-original-error',observer_failure)
serialized=json.dumps(row['record']); lost='secretlessFuture' not in serialized
assert not lost
assert row['record']['native']['primaryFailure']['type']=='TimeoutExpired'

# Deadline in actual helper archive must stop before all later dispatch.
def archive_alarm(stack,root,record,trace):
 inert_init_ports(stack,root,record,trace)
 def wait(self,*a,**kw):self.state['exits']['capture']=0;return 'completed'
 def drain(self,*a):self.state.update(drained=True,clean=True);return self.state
 def run(argv,**kw):
  trace.append(argv[:2])
  with boundary.deadline(.01):time.sleep(.05)
 stack.enter_context(patch.object(jb.StationJob,'wait',wait));stack.enter_context(patch.object(jb.StationJob,'drain',drain));stack.enter_context(patch.object(stages.StageReceipts,'require_browser',lambda _:None));stack.enter_context(patch.object(subprocess,'run',run))
row=case('archive-deadline',archive_alarm)
assert row['trace']==['inert-start',['/bin/launchctl','bootout']] and row['error']['type']=='DeadlineExpired' and row['timerAfter'][0]==0
(E/'lifecycle-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'cases':len(results),'adapterMismatchReproduced':False,'observerOriginalRawLost':lost,'otherControls':'PASS'}))
