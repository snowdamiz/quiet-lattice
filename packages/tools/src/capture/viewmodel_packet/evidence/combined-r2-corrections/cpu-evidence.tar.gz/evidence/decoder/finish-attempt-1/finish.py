import hashlib
import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
R = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
files = ['packages/tools/src/capture/viewmodel_packet/inspect_packet.py',
         'packages/tools/src/capture/viewmodel_packet/test_inspect.py']
git = []
for label, args in [('diff-check', ['git', 'diff', '--check', '--', *files]),
                    ('diff', ['git', 'diff', '--binary', '--full-index', '--', *files]),
                    ('status', ['git', 'status', '--short'])]:
    result = subprocess.run(args, cwd=R, capture_output=True)
    (S / (label + '.stdout')).write_bytes(result.stdout)
    (S / (label + '.stderr')).write_bytes(result.stderr)
    git.append({'argv': args, 'cwd': str(R), 'exit': result.returncode})
    assert result.returncode == 0
(S / 'git-commands.json').write_text(json.dumps(git, indent=2) + '\n')

facts = []
for mode in ('replay-red', 'tests-red', 'replay-green', 'tests-full'):
    for case in sorted((S / mode).glob('cli-*')):
        command = json.loads((case / 'command.json').read_text())
        value = json.loads((case / 'output/observations.json').read_text()) if (case / 'output/observations.json').exists() else None
        if value is None:
            continue
        if not ('unknownRaw' in value and ('switchTiming' in value['unknownRaw'] or value['unknownRaw'].get('check') == 'transition elapsed facts')):
            continue
        payload = json.loads((case / ('stdout' if command['exit'] == 0 else 'stderr')).read_text())
        returned = payload if command['exit'] == 0 else payload['evidence']
        assert returned['observations'] == value
        gap, settled = value['frames'][:2]
        facts.append({'mode': mode, 'case': str(case), 'unit': value['unit'], 'exit': command['exit'],
                      'primaryFailure': payload.get('primaryFailure'), 'rawFactsPreserved': True,
                      'unknownRaw': value['unknownRaw'],
                      'gap': {k: gap[k] for k in ('file', 'frame', 'elapsed', 'dt', 'raise')},
                      'settled': {k: settled[k] for k in ('file', 'frame', 'elapsed', 'dt', 'raise')}})
(S / 'transition-facts.json').write_text(json.dumps(facts, indent=2) + '\n')

after = json.loads((S / 'after/source.json').read_text())
report = '''R2-3 IMPLEMENTATION SOURCE PROOF: PASS
This is the implementation sub-agent's CPU/source proof, not independent review,
native acceptance, screenshot/pose meaning, or whole T03 acceptance.

WORKSPACE AND OWNERSHIP
/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8
Branch task/P1-E05-T03; unchanged HEAD 182fc27d1a5459270e2a3c4673f8e70b86ef3a33
Tree 546f57bc68c5a19f8144ae2ccd205a368bd9982f
Only owned repository edits: inspect_packet.py and test_inspect.py under
packages/tools/src/capture/viewmodel_packet. Scratch writes only in this decoder
directory. No commit. Shared status also contains parent-owned boundary.py,
caller.py and native.py changes; these were not edited or tested by this lane.
Parent refreshes bindings once the complete shared implementation is final.

ORACLE AND CHANGE
Read the complete REPORT-FINAL.txt and decoder REPORT.txt plus retained
transition-followup inputs and followup.py before editing. fixture.mjs step()
advances one frame and elapsed dt, with default 1/60. The switch-gap uses step(0),
then after loader attachment the fixture performs 24 ordinary updates before
switch-settled. Multitool.update raises by dt*2.6 and resets to zero when hidden;
the model attachment callback does not raise the tool. The source fixture's
single render/sample per named pose is unchanged. No T04 pose or clip changes.

The existing raise-0.4 progress rule now also applies to switch-settled, paired
with the immediately preceding same-aspect switch-gap. The interval requires
at least 0.4 elapsed, at least 24 frame updates, whole 1/60 elapsed increments,
elapsed no greater than frame updates/60, and final dt=1/60 (existing numerical
tolerances retained). This preserves extra fixed updates and zero-dt steps.
Full raise, zero/reset endpoints, raiseSeconds, and unknown observations keep
their prior rules. No fixture/runtime change was necessary.

RED
Original inspector and inventory at ../original are byte-identical to the
pinned Git blobs; their hashes were verified before and after. Original inspector
SHA256 f51410422b5c36a36f240bead001b7869cddc747dffb008302c945480ff05ee9.
Actual CLI replays on immutable retained full packets: all 12 exit 0/PASS,
including nine invalid zero-time/one-step/23-step transitions across
return-thalune, view-ixari and view-ulgani, plus three valid 24-step controls.
replay-red wrapper exits 0 because the defect-reproduction assertions succeeded.
New regression tests against that same original CLI: wrapper exit 1,
2 tests, 30 adverse subtest failures, zero errors; all 42 CLI calls exit 0.
The 12 valid positive cases passed. This is observed false acceptance, not
an import, dependency or harness failure.

GREEN
Same retained 12 input packets through candidate CLI: nine adverse exits 1/FAIL
with the intended 24-updates-at-1/60 error, three valid exits 0/PASS.
All complete observations, including unknown facts, are identical in returned
success/failure evidence. replay-green wrapper exits 0.
Full candidate suite: exit 0, 26 tests in 13.088s, zero failures/errors.
All original 24 test method ASTs are unchanged. Includes existing PNG/zlib/CRC,
critical-chunk, RGB/RGBA 8/16-bit Adam7/split-IDAT controls, seven-unit packets,
extra raise-0.4 cooling, caps, manifest/file boundary and raw-observation checks.
The two new methods add 30 adverse and 12 valid real-CLI transition cases.
Adverse cases per unit: zero-time, one-step, 23-steps, short duration, fractional
update time, too few updates, too much time, zero final dt, duration-as-dt,
and wrong fixed dt. Valid cases per unit: 24 fixed updates, 240 extra fixed
updates, two extra zero-dt updates, and both kinds of extra updates together.
Full suite actual CLI calls: 121 (31 exit 0 / 90 expected exit 1).
Across all fresh runs: 187 real CLI calls, sequential, at most one test worker.
All packets contain full inventories, actual synthetic PNG bytes and recomputed
size/SHA256 manifests. No decoder function is replaced for transition tests.
Adverse candidate observations reject before PNG decoding; matching valid packets
and original accepted counterexamples exercise actual PNG/zlib/Pillow decoding.

PRESERVATION AND LIMITS
before/provenance.json equals after/provenance.json: 470 protected files including
fixture, runtime, six source/export assets, four helpers, exact shared T15 files,
old reports, retained R2 case inputs/results and all existing PIL files. Original
inspector/test/inventory still match Git. No native/browser/GPU/Metal, Blender,
services/DB, grants, screenshots, installs, dependency writes, readiness/evidence/
README changes, nested agents, broad cleanup, commit, PR or queue action ran.
Temporary test directories are retained; ordinary fixture-local test mutations
still run as authored. This proof does not validate native execution or image
meaning. No readiness/binding result is claimed while parent work continues.

EVIDENCE
Each mode has invocation.json (exact argv, shell command, cwd, environment),
stdout, stderr and exit. Each cli-NNN directory retains input output/, inventory,
manifest, raw stdout/stderr, and command.json with actual argv, replayArgv for
the immutable saved input snapshot, exit, interpreter target source hash and log
hashes. commands.json indexes those records. transition-facts.json extracts all
108 fresh transition results without replacing raw evidence. tests-full/stderr
contains all 26 test names. git-commands.json and diff*.stdout retain scope checks.
verify_decoder.py is the reproducible serial harness; tests-red selects the
original CLI via test-module HERE, leaving inspector behavior unchanged.

FINAL SOURCE SHA256
'''
for name, value in after.items():
    report += f'{name}: {value["sha256"]} ({value["bytes"]} bytes)\n'
report += '\nEXACT EXECUTED COMMANDS\n'
for mode in ('before', 'replay-red', 'tests-red', 'replay-green', 'tests-full', 'after'):
    invocation = json.loads((S / mode / 'invocation.json').read_text())
    report += f'\n{mode}: exit={(S / mode / "exit").read_text().strip()}\ncwd={invocation["cwd"]}\n{invocation["shell"]}\n'
assert len(facts) == 108
(S / 'REPORT.txt').write_text(report)

index = {}
for path in sorted(S.rglob('*')):
    if path.is_file() and not path.is_symlink():
        raw = path.read_bytes()
        index[str(path.relative_to(S))] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(S / 'evidence-sha256.json').write_text(json.dumps(index, indent=2) + '\n')
print('Report:', S / 'REPORT.txt', 'evidence files:', len(index), 'transition facts:', len(facts))
