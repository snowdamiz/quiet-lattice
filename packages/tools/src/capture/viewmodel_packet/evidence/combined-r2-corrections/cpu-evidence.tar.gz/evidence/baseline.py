import sys,json
from pathlib import Path
P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet')
sys.path.insert(0,str(P))
import bindings,caller
r=json.loads((P/'readiness.json').read_text()); bindings.check(r['bindings']); print('BASELINE_BINDINGS_PASS')
