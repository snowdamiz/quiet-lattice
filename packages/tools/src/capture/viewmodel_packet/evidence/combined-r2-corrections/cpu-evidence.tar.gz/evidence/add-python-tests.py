from pathlib import Path
p=Path('packages/tools/src/capture/viewmodel_packet/test_revision.py');s=p.read_text().replace("def adapter(self, mode='healthy', save_fails=False):","def adapter(self, mode='healthy', save_fails=False, encoder_fails=False):")
s=s.replace("if mode == 'observer':", "if mode in ('observer', 'cyclic'):")
s=s.replace("error.unknown = {'retained': b'\\x00'}; originals.append(error); raise error", "error.unknown = {'retained': b'\\x00'}\n                if mode == 'cyclic':\n                    error.unknown.update(nested={'sourceError': error}, shared=error.unknown)\n                originals.append(error); raise error")
s=s.replace("            try:\n                native.capture(ready", "            if encoder_fails:\n                real_raw = native.raw\n                def encoder(value):\n                    if isinstance(value, subprocess.TimeoutExpired): raise ValueError('INJECTED_ENCODER_FAILURE')\n                    return real_raw(value)\n                stack.enter_context(patch.object(native, 'raw', encoder))\n            try:\n                native.capture(ready")
p.write_text(s)
