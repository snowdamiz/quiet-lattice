/* global process, Buffer */
// Execute the frozen captureReview body; only native/import ports are inert.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { registerHooks, stripTypeScriptTypes, syncBuiltinESMExports } from 'node:module';
import { pathToFileURL, URL } from 'node:url';
import cp from 'node:child_process';

const packet = '/private/tmp/vm-r2-fix-pern8y1v/red/repo/packages/tools/src/capture/viewmodel_packet';
const ready = JSON.parse(fs.readFileSync(path.join(packet, 'readiness.json')));
const plan = JSON.parse(fs.readFileSync(path.join(packet, 'inventory.json')));
const trace = [];
let failingOperation, cleanupFails, viteFails, primary, secondary, tertiary;

const chromium = {
  launch: async () => {
    trace.push('inert-launch-port');
    let initCalls = 0;
    const page = Object.fromEntries(
      ['on', 'addInitScript', 'goto', 'waitForFunction', 'evaluate'].map((operation) => [
        operation,
        (...args) => {
          trace.push(operation);
          // The first init belongs to the adapter; the second is the real openReview call.
          if (operation === 'addInitScript') initCalls++;
          if (operation === failingOperation && (operation !== 'addInitScript' || initCalls === 2)) throw primary;
          if (operation === 'evaluate') throw new Error('Unexpected later dispatch');
          return operation === 'on' ? page : Promise.resolve(args);
        },
      ]),
    );
    return {
      newPage: async () => {
        trace.push('newPage');
        if (failingOperation === 'newPage') throw primary;
        return page;
      },
      close: async () => {
        trace.push('browser.close');
        if (cleanupFails) throw secondary;
      },
    };
  },
};
const vite = {
  listen: async () => {},
  close: async () => {
    trace.push('vite.close'); if (viteFails) throw tertiary;
  },
};
const net = () => ({
  listen(_port, _host, callback) {
    callback();
  },
  address() {
    return { port: 12345 };
  },
  close(callback) {
    callback();
  },
});

// Private references avoid importing a real launcher, bundler, server or codec.
globalThis.__viewmodelInertPorts = { chromium, vite, net };
const hooks = registerHooks({
  resolve(spec, context, next) {
    if (spec === '@playwright/test') return { url: 'inert:pw', shortCircuit: true };
    if (spec === 'vite') return { url: 'inert:vite', shortCircuit: true };
    if (spec === 'node:net' && context.parentURL?.endsWith('/capture.ts')) return { url: 'inert:net', shortCircuit: true };
    return next(spec, context);
  },
  load(url, context, next) {
    if (url === 'inert:pw' || url === pathToFileURL(ready.bindings.playwright).href)
      return { format: 'module', source: 'export const chromium=globalThis.__viewmodelInertPorts.chromium;', shortCircuit: true };
    if (url === 'inert:vite')
      return { format: 'module', source: 'export const createServer=async()=>globalThis.__viewmodelInertPorts.vite;', shortCircuit: true };
    if (url === 'inert:net') return { format: 'module', source: 'export const createServer=globalThis.__viewmodelInertPorts.net;', shortCircuit: true };
    if (url === pathToFileURL(ready.bindings.tsxApi).href) return { format: 'commonjs', source: 'exports.register=()=>()=>{};', shortCircuit: true };
    if (url.endsWith('/capture/classes.ts'))
      return {
        format: 'module',
        source: 'export const farRanges=()=>[];export const loadClassRules=()=>({});export const reviewClass=()=>"viewmodel";',
        shortCircuit: true,
      };
    if (url.endsWith('/capture/screens.ts')) return { format: 'module', source: 'export const SCREENS={};', shortCircuit: true };
    if (url.endsWith('/capture/capture.ts'))
      return { format: 'module', source: stripTypeScriptTypes(fs.readFileSync(process.env.VM_SHARED_UNDER_TEST ?? new URL(url), 'utf8')), shortCircuit: true };
    return next(url, context);
  },
});
const { execute, productionCapture, errorFacts } = await import(pathToFileURL(path.join(packet, 'entry.mjs')));

const makeFailure = (name, id) => Object.freeze(Object.assign(new Error(name), {partial:Buffer.from([0,255,id]), unknown:Object.freeze({owner:name,available:false,id})}));

test('independent falsy integration receipts', async () => {
 const saved=new Map(); for(const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']){saved.set(name,cp[name]);cp[name]=()=>{throw Error('NO_NATIVE:'+name)}};syncBuiltinESMExports();
 const rows=[];
 try {
 for(const [label,raw] of [['error',makeFailure('PRIMARY',1)],['false',false],['zero',0],['empty',''],['null',null],['undefined',undefined]]) {
  for(const both of [false,true]) for(const sink of ['durable','fallback','all-sinks']) {
   failingOperation='goto';cleanupFails=both;viteFails=both;trace.length=0;primary=raw;secondary=makeFailure('SECONDARY_BROWSER_CLOSE',2);tertiary=makeFailure('TERTIARY_VITE_STOP',3);
   const dir=path.join('/private/tmp/vm-r2-fix-pern8y1v/red',`falsy-v2-${label}-${both}-${sink}`);fs.mkdirSync(dir);
   let caught,attempt=0;const receipts=[];
   const result=await execute({ready,spec:plan.units[0],paths:{output:dir+'/output',evidence:dir}}, {
    capture:async(...args)=>{try{return await productionCapture(...args)}catch(e){caught=e;throw e}},
    receipt:(name,record)=>{attempt++;if(sink==='all-sinks'||sink==='fallback'&&attempt===1)throw Error('RECEIPT');const p=path.join(dir,name);fs.writeFileSync(p,JSON.stringify(record),{flag:'wx'});receipts.push(JSON.parse(fs.readFileSync(p)))},
    emit:()=>{throw Error('STDERR')}
   });
   assert.equal(result.code,1);assert.equal(trace.filter(x=>x==='goto').length,1);assert.equal(trace.filter(x=>x==='vite.close').length,1);
   if(both){assert.equal(caught.errors[0],raw);assert.equal(caught.errors[1],secondary);assert.equal(caught.errors[2],tertiary);assert.equal(caught.cause,raw)}else assert.equal(caught,raw);
   const encoded=JSON.stringify(result.record);const observed={label,both,sink,trace:[...trace],result,receipts,rawSharedIdentityPreserved:true,viteFaultRetained:!both||encoded.includes('TERTIARY_VITE_STOP'),durablePrimaryKey:receipts.length?Object.hasOwn(receipts[0],'primaryFailure'):null};rows.push(observed);
  }
 }
 fs.writeFileSync('/private/tmp/vm-r2-fix-pern8y1v/red/falsy-results.json',JSON.stringify(rows,null,2),{flag:'wx'});
 const lost=rows.filter(x=>!x.viteFaultRetained);assert.equal(lost.length,9);assert.ok(lost.every(x=>['false','zero','empty'].includes(x.label)));console.log(JSON.stringify({cases:rows.length,missingViteFacts:lost.length,undefinedDurablePrimaryOmitted:rows.filter(x=>x.label==='undefined'&&!x.both&&x.durablePrimaryKey===false).length}));
 }finally{for(const [name,value]of saved)cp[name]=value;syncBuiltinESMExports();hooks.deregister();delete globalThis.__viewmodelInertPorts}
});
