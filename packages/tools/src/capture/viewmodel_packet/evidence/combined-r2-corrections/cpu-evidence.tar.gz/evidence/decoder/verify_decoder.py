import ast
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
HERE = ROOT / 'packages/tools/src/capture/viewmodel_packet'
BASE = Path('/private/tmp/vm-r2-fix-pern8y1v/original')
OUT = Path(__file__).resolve().parent
OLD = Path('/private/tmp/p1-e05-t03-decoder-r2-kf878yxf')
HEAD = '182fc27d1a5459270e2a3c4673f8e70b86ef3a33'
ENV = {k: os.environ[k] for k in ('PYTHONDONTWRITEBYTECODE', 'PYTHONPATH', 'TMPDIR',
       'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')}
real_run = subprocess.run


def digest(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def provenance():
    hashes = {}
    for name in ('inspect_packet.py', 'test_inspect.py', 'inventory.json'):
        raw = subprocess.check_output(['git', 'show', f'{HEAD}:packages/tools/src/capture/viewmodel_packet/{name}'], cwd=ROOT)
        assert raw == (BASE / name).read_bytes(), name
        hashes[name] = digest(BASE / name)
    paths = [HERE / name for name in ('fixture.mjs', 'inventory.json', 'README.md', 'REPORT.md',
             'CAPTURE-REVISION-R1.md', 'T15-ADOPTION.md')]
    paths += [ROOT / 'packages/client/src/entities/Multitool.js',
              ROOT / 'packages/tools/src/capture/capture.ts',
              ROOT / 'packages/tools/src/capture/capture.lifecycle.test.ts']
    for name in ('round4_capture_children.py', 'round4_job_boundary.py',
                 'run_round4_browser_proof.py', 'run_round4_remaining8.py'):
        paths.append(ROOT / 'assets/blend/stations/_authoring' / name)
    for people in ('thalune', 'ixari', 'ulgani'):
        paths += [ROOT / f'assets/blend/characters/viewmodels/fp_{people}.blend',
                  ROOT / f'packages/client/public/models/characters/viewmodels/fp_{people}.glb']
    paths += [Path('/private/tmp/p1-e05-t03-r2-yrN5o2/REPORT-FINAL.txt'), OLD / 'REPORT.txt',
              OLD / 'followup.py', OLD / 'transition-summary.json', Path(sys.executable)]
    paths += [p for p in (OLD / 'transition-followup').rglob('*') if p.is_file()]
    paths += [p for p in (Path(ENV['PYTHONPATH']) / 'PIL').rglob('*') if p.is_file()]
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
            'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT).decode().strip(),
            'baseMatchesGit': hashes, 'protected': {str(p): digest(p) for p in sorted(set(paths))}}


def load_tests():
    spec = importlib.util.spec_from_file_location('decoder_tests', HERE / 'test_inspect.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RetainedDirectory(tempfile.TemporaryDirectory):
    def cleanup(self):
        self._finalizer.detach()


def main(mode, lane):
    if mode in ('before', 'after'):
        facts = provenance()
        save(lane / 'provenance.json', facts)
        if mode == 'before':
            assert (HERE / 'inspect_packet.py').read_bytes() == (BASE / 'inspect_packet.py').read_bytes()
        else:
            before = json.loads((OUT / 'before/provenance.json').read_text())
            assert facts == before, 'protected bytes or base provenance changed'
            methods = lambda p: {n.name: ast.dump(n) for c in ast.parse(p.read_text()).body
                       if isinstance(c, ast.ClassDef) and c.name == 'InspectorTests'
                       for n in c.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
            old, new = methods(BASE / 'test_inspect.py'), methods(HERE / 'test_inspect.py')
            assert len(old) == 24 and all(new.get(k) == v for k, v in old.items())
            save(lane / 'source.json', {name: digest(HERE / name) for name in ('inspect_packet.py', 'test_inspect.py')})
            print('Original 24 test methods unchanged; candidate has', len(new), 'tests')
        print('Provenance verified:', facts['head'], facts['tree'], len(facts['protected']), 'protected files')
        return 0

    records = []

    def run_logged(args, **kwargs):
        case = lane / f'cli-{len(records):03d}'
        case.mkdir()
        args = [str(a) for a in args]
        output = Path(args[args.index('--output') + 1])
        manifest = Path(args[args.index('--manifest') + 1])
        inventory = Path(args[args.index('--inventory') + 1])
        shutil.copytree(output, case / 'output')
        shutil.copyfile(manifest, case / 'manifest.json')
        shutil.copyfile(inventory, case / 'inventory.json')
        replay = args[:]
        for flag, path in (('--output', case / 'output'), ('--manifest', case / 'manifest.json'), ('--inventory', case / 'inventory.json')):
            replay[replay.index(flag) + 1] = str(path)
        start = time.monotonic()
        result = real_run(args, **kwargs)
        for name, value in (('stdout', result.stdout), ('stderr', result.stderr)):
            (case / name).write_bytes(value.encode() if isinstance(value, str) else value)
        record = {'argv': args, 'replayArgv': replay, 'cwd': str(ROOT), 'environment': ENV,
                  'exit': result.returncode, 'seconds': time.monotonic() - start,
                  'inspector': digest(Path(args[2])), 'stdout': digest(case / 'stdout'), 'stderr': digest(case / 'stderr')}
        save(case / 'command.json', record)
        records.append(record)
        return result

    if mode in ('replay-red', 'replay-green'):
        source = BASE if mode == 'replay-red' else HERE
        for unit in ('return-thalune', 'view-ixari', 'view-ulgani'):
            for label in ('zero-time', 'one-step', '23-steps', '24-steps-valid'):
                case = OLD / 'transition-followup' / unit / label
                args = [sys.executable, '-B', str(source / 'inspect_packet.py'), '--inventory', str(BASE / 'inventory.json'),
                        '--unit', unit, '--output', str(case / 'output'), '--manifest', str(case / 'manifest.json')]
                result = run_logged(args, cwd=ROOT, capture_output=True, timeout=20)
                expected = 0 if mode == 'replay-red' or label == '24-steps-valid' else 1
                assert result.returncode == expected, (unit, label, result.returncode)
                value = json.loads((case / 'output/observations.json').read_text())
                payload = json.loads(result.stdout or result.stderr)
                assert (payload if expected == 0 else payload['evidence'])['observations'] == value
                if expected == 0:
                    assert payload['valid'] is True and payload['status'] == 'PASS'
                else:
                    assert '24 updates at 1/60' in payload['primaryFailure'] and not result.stdout
                print(unit, label, 'exit', result.returncode, 'raw observations preserved')
        exit_code = 0
    else:
        module = load_tests()
        tempfile.TemporaryDirectory = RetainedDirectory
        subprocess.run = run_logged
        if mode == 'tests-red':
            module.HERE = BASE
        names = ['test_cli_switch_settled_reconciles_gap_elapsed_frames_and_last_dt',
                 'test_cli_switch_settled_accepts_fixed_steps_and_zero_dt_resets']
        suite = (unittest.defaultTestLoader.loadTestsFromTestCase(module.InspectorTests) if mode == 'tests-full'
                 else unittest.TestSuite(module.InspectorTests(name) for name in names))
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        exit_code = int(not result.wasSuccessful())
        save(lane / 'tests.json', {'testsRun': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors)})
    save(lane / 'commands.json', records)
    print('Actual CLI subprocesses:', len(records), 'exit histogram:', {str(code): sum(r['exit'] == code for r in records) for code in (0, 1)})
    return exit_code


mode = sys.argv[1]
lane = OUT / mode
lane.mkdir()
save(lane / 'invocation.json', {'argv': [sys.executable, '-B', str(Path(__file__).resolve()), mode],
      'shell': 'env ' + ' '.join(shlex.quote(k + '=' + v) for k, v in ENV.items()) + ' ' + shlex.join([sys.executable, '-B', str(Path(__file__).resolve()), mode]),
      'cwd': str(ROOT), 'environment': ENV})
with (lane / 'stdout').open('x') as stdout, (lane / 'stderr').open('x') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        code = main(mode, lane)
(lane / 'exit').write_text(str(code) + '\n')
print(mode, 'exit', code, 'logs:', lane)
sys.exit(code)
