import unittest,sys
suite=unittest.TestSuite()
for pattern in ['test_boundary.py','test_native.py','test_revision.py']:
    suite.addTests(unittest.defaultTestLoader.discover('packages/tools/src/capture/viewmodel_packet',pattern=pattern))
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
