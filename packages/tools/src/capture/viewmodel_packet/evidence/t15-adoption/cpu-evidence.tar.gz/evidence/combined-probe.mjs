/* global process, Buffer */
// Execute the frozen captureReview body; only native/import ports are inert.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { registerHooks, stripTypeScriptTypes, syncBuiltinESMExports } from 'node:module';
import { pathToFileURL, URL } from 'node:url';
import cp from 'node:child_process';

const packet = '/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet';
const ready = JSON.parse(fs.readFileSync(path.join(packet, 'readiness.json')));
const plan = JSON.parse(fs.readFileSync(path.join(packet, 'inventory.json')));
const trace = [];
let failingOperation, cleanupFails, viteFails, primary, secondary, tertiary;

const chromium = {
  launch: async () => {
    trace.push('inert-launch-port');
    let initCalls = 0;
    const page = Object.fromEntries(
      ['on', 'addInitScript', 'goto', 'waitForFunction', 'evaluate'].map((operation) => [
        operation,
        (...args) => {
          trace.push(operation);
          // The first init belongs to the adapter; the second is the real openReview call.
          if (operation === 'addInitScript') initCalls++;
          if (operation === failingOperation && (operation !== 'addInitScript' || initCalls === 2)) throw primary;
          if (operation === 'evaluate') throw new Error('Unexpected later dispatch');
          return operation === 'on' ? page : Promise.resolve(args);
        },
      ]),
    );
    return {
      newPage: async () => {
        trace.push('newPage');
        if (failingOperation === 'newPage') throw primary;
        return page;
      },
      close: async () => {
        trace.push('browser.close');
        if (cleanupFails) throw secondary;
      },
    };
  },
};
const vite = {
  listen: async () => {},
  close: async () => {
    trace.push('vite.close'); if (viteFails) throw tertiary;
  },
};
const net = () => ({
  listen(_port, _host, callback) {
    callback();
  },
  address() {
    return { port: 12345 };
  },
  close(callback) {
    callback();
  },
});

// Private references avoid importing a real launcher, bundler, server or codec.
globalThis.__viewmodelInertPorts = { chromium, vite, net };
const hooks = registerHooks({
  resolve(spec, context, next) {
    if (spec === '@playwright/test') return { url: 'inert:pw', shortCircuit: true };
    if (spec === 'vite') return { url: 'inert:vite', shortCircuit: true };
    if (spec === 'node:net' && context.parentURL?.endsWith('/capture.ts')) return { url: 'inert:net', shortCircuit: true };
    return next(spec, context);
  },
  load(url, context, next) {
    if (url === 'inert:pw' || url === pathToFileURL(ready.bindings.playwright).href)
      return { format: 'module', source: 'export const chromium=globalThis.__viewmodelInertPorts.chromium;', shortCircuit: true };
    if (url === 'inert:vite')
      return { format: 'module', source: 'export const createServer=async()=>globalThis.__viewmodelInertPorts.vite;', shortCircuit: true };
    if (url === 'inert:net') return { format: 'module', source: 'export const createServer=globalThis.__viewmodelInertPorts.net;', shortCircuit: true };
    if (url === pathToFileURL(ready.bindings.tsxApi).href) return { format: 'commonjs', source: 'exports.register=()=>()=>{};', shortCircuit: true };
    if (url.endsWith('/capture/classes.ts'))
      return {
        format: 'module',
        source: 'export const farRanges=()=>[];export const loadClassRules=()=>({});export const reviewClass=()=>"viewmodel";',
        shortCircuit: true,
      };
    if (url.endsWith('/capture/screens.ts')) return { format: 'module', source: 'export const SCREENS={};', shortCircuit: true };
    if (url.endsWith('/capture/capture.ts'))
      return { format: 'module', source: stripTypeScriptTypes(fs.readFileSync(process.env.VM_SHARED_UNDER_TEST ?? new URL(url), 'utf8')), shortCircuit: true };
    return next(url, context);
  },
});
const { execute, productionCapture, errorFacts } = await import(pathToFileURL(path.join(packet, 'entry.mjs')));

const makeFailure = (name, id) => Object.freeze(Object.assign(new Error(name), {partial:Buffer.from([0,255,id]), unknown:Object.freeze({owner:name,available:false,id})}));
test('combined productionCapture, captureReview and receipt boundaries retain all ordered failures', async () => {
 const saved=new Map();
 for(const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) {saved.set(name,cp[name]);cp[name]=()=>{throw Error(`NO_CHILD_PROCESS:${name}`)}}
 syncBuiltinESMExports();
 const rows=[],issues=[];
 try {
  for(const operation of ['newPage','on','addInitScript','goto','waitForFunction','evaluate']) {
   for(const browserFailure of [false,true]) for(const viteFailure of [false,true]) for(const sink of ['durable','fallback','all-sinks']) {
    failingOperation=operation;cleanupFails=browserFailure;viteFails=viteFailure;trace.length=0;
    primary=makeFailure(`PRIMARY_${operation}`,1);secondary=makeFailure('SECONDARY_BROWSER_CLOSE',2);tertiary=makeFailure('TERTIARY_VITE_STOP',3);
    const receiptError=makeFailure('RECEIPT_FAILURE',4),emitError=makeFailure('STDERR_FAILURE',5);
    const records=[];let caught,attempts=0;
    const result=await execute({ready,spec:plan.units[0],paths:{output:'/INERT-no-output',evidence:'/INERT-no-evidence'}},{
     capture:async(...args)=>{try{return await productionCapture(...args)}catch(error){caught=error;throw error}},
     receipt:(_name,record)=>{attempts++;if(sink==='all-sinks'||sink==='fallback'&&attempts===1)throw receiptError;records.push(JSON.parse(JSON.stringify(record)))},
     emit:()=>{throw emitError},
    });
    const row={operation,browserFailure,viteFailure,sink,trace:[...trace],caught:errorFacts(caught),result,records};rows.push(row);
    try {
     assert.equal(result.code,1);assert.equal(result.record.checksPassed,false);assert.equal(result.durable,sink!=='all-sinks');
     assert.deepEqual(result.record.primaryFailure,errorFacts(primary));
     assert.equal(trace.filter(s=>s==='vite.close').length,1);
     assert.equal(trace.filter(s=>s==='browser.close').length,2); // common owner, then existing packet fallback
     assert.deepEqual(trace.filter(s=>s==='browser.close'||s==='vite.close'),['browser.close','vite.close','browser.close']);
     const expected=[primary,...(browserFailure?[secondary]:[]),...(viteFailure?[tertiary]:[])];
     if(expected.length===1) assert.equal(caught,primary);
     else {
      assert.ok(caught instanceof AggregateError);assert.equal(caught.cause,primary);
      assert.equal(caught.errors.length,expected.length);expected.forEach((error,i)=>assert.equal(caught.errors[i],error));
      const aggregate=result.record.secondaryFailures.find(f=>f.phase==='capture-finally').error;
      assert.equal(aggregate.message,'Capture encountered multiple failures');assert.deepEqual(aggregate.cause,errorFacts(primary));
      assert.equal(aggregate.errors.length,expected.length);assert.equal(aggregate.errors[0],'[cycle]');
      expected.slice(1).forEach((error,i)=>assert.deepEqual(aggregate.errors[i+1],errorFacts(error)));
     }
     if(browserFailure) assert.ok(result.record.secondaryFailures.some(f=>f.phase==='cleanup'&&f.error.message===secondary.message&&f.error.partial.base64===secondary.partial.toString('base64')));
     if(sink==='all-sinks') {
      assert.equal(records.length,0);assert.equal(result.record.secondaryFailures.filter(f=>f.error.message===receiptError.message).length,2);
      assert.deepEqual(result.record.secondaryFailures.at(-1).error,errorFacts(emitError));
     } else {
      assert.equal(records.length,1);assert.deepEqual(records[0].primaryFailure,errorFacts(primary));
      if(expected.length>1) assert.deepEqual(records[0].secondaryFailures.find(f=>f.phase==='capture-finally').error,result.record.secondaryFailures.find(f=>f.phase==='capture-finally').error);
     }
    } catch(error) {row.assertion=errorFacts(error);issues.push(error)}
   }
  }
  fs.writeFileSync(process.env.VM_ENTRY_EVIDENCE,JSON.stringify({cases:rows.length,failures:issues.length,rows},null,2),{flag:'wx'});
  assert.equal(issues.length,0,issues.map(e=>e.message).join('\n'));
 } finally {for(const [name,value] of saved)cp[name]=value;syncBuiltinESMExports();hooks.deregister();delete globalThis.__viewmodelInertPorts}
});
