import ast,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent;ROOT=Path.cwd();PACKET=ROOT/'packages/tools/src/capture/viewmodel_packet';PREFIX=os.fsencode(str(PACKET.relative_to(ROOT)))+b'/'
sha=lambda data:hashlib.sha256(data).hexdigest()
def file_sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
before=json.loads((E/'before.json').read_text());adoption=json.loads((E/'adoption.json').read_text());old=json.loads((E/'prior-readiness.json').read_text());ready=json.loads((E/'prepare.log').read_text())
assert set(ready['bindings'])==set(old['bindings'])
for key,value in old['bindings'].items():
 if key!='sourceDigest':assert ready['bindings'][key]==value,key
for name,row in before['packetBefore'].items():assert file_sha(ROOT/name)==row['sha256'],name
source_paths=sorted(x for x in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if x and not x.startswith(PREFIX))
current=hashlib.sha256();previous=hashlib.sha256();rows=[]
test=b'packages/tools/src/capture/capture.lifecycle.test.ts';capture=b'packages/tools/src/capture/capture.ts'
for raw in source_paths:
 name=os.fsdecode(raw);digest=file_sha(ROOT/name);rows.append({'path':name,'sha256':digest})
 current.update(raw+b'\0'+digest.encode()+b'\n')
 if raw!=test:
  prior='3f95b7bf75c3c25819a9b7d7f94276afb9340f3a6fa9e41d4310817a585f7fdc' if raw==capture else digest
  previous.update(raw+b'\0'+prior.encode()+b'\n')
assert current.hexdigest()==ready['bindings']['sourceDigest'];assert previous.hexdigest()==old['bindings']['sourceDigest'];assert test in source_paths and capture in source_paths
protected=json.loads((PACKET/'evidence/capture-revision-r1/protected-audit.txt').read_text())
for group,files in protected['groups'].items():
 for name,row in files.items():assert file_sha(ROOT/name)==row['sha256'],name
for name,want in protected['helpers'].items():assert file_sha(ROOT/name)==want,name
for name,want in protected['reports'].items():assert file_sha(Path(name))==want,name
assert file_sha(Path('/tmp/p1-e14-t15-independent-gzn1kbbe/REPORT.txt'))==before['reviewSha256']
shared={str(Path('packages/tools/src/capture')/name):digest for name,digest in adoption['files'].items()}
for name,digest in shared.items():assert file_sha(ROOT/name)==digest
assert subprocess.check_output(['git','diff','--full-index','--binary',before['base'],adoption['adoptionCommit']])==(E/'T15.patch').read_bytes()
paths=sorted({v for row in ready['paths'].values() for v in row.values()}|set(ready['containers'].values()))
assert all(not Path(p).exists() for p in paths)
sys.path.insert(0,str(PACKET));from boundary import validate_inventory
plan=validate_inventory(json.loads((PACKET/'inventory.json').read_text()));assert sum(len(u['files']) for u in plan['units'])==101;assert sum(u['pngCount'] for u in plan['units'])==94
assert not plan['runtimeEnabled'] and not plan['entryEnabled'] and not ready['runtimeEnabled'] and not ready['entryEnabled']
assert 'RUNTIME_ENABLED = False' in (PACKET/'caller.py').read_text();assert 'ENTRY_ENABLED = false' in (PACKET/'entry.mjs').read_text()
for path in PACKET.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
ready['sourceProvenance']={'priorPacketCheckpoint':before['base'],'sharedCaptureReviewedCommit':before['t15'],'sharedCaptureAdoptionCommit':adoption['adoptionCommit'],'sharedCaptureAdoptionTree':adoption['adoptionTree'],'sharedCaptureReviewSha256':before['reviewSha256'],'sharedCapturePatchSha256':adoption['patchSha256'],'sharedCaptureFiles':shared,'sourceDigestIncludesSharedLifecycleTest':True,'legacyReviewedSourceScope':'accepted runtime/art SOURCE R3 anchor; combined packet R2 remains pending','finalHeadBinding':'final combined metadata commit is recorded by the post-commit handoff and must be bound by a future external grant'}
ready_bytes=(json.dumps(ready,indent=2)+'\n').encode();(E/'combined-readiness.json').write_bytes(ready_bytes);(PACKET/'readiness.json').write_bytes(ready_bytes)
closure=(json.dumps(rows,separators=(',',':'))+'\n').encode();(E/'source-closure.json.gz').write_bytes(gzip.compress(closure,mtime=0))
proof={'status':'PASS','base':before['base'],'adoption':adoption,'readySha256':sha(ready_bytes),'sourceDigest':current.hexdigest(),'reconstructedPriorSourceDigest':previous.hexdigest(),'sourceClosureRows':len(rows),'sourceClosureSha256':sha(closure),'explicitSharedBindings':shared,'sourceClosureIncludesNewLifecycleTest':True,'dependencyTreesUnchanged':ready['bindings']['trees'],'ignoredInventoryUnchanged':ready['bindings']['ignoredInventorySha256'],'allOtherBindingsUnchanged':True,'protectedCounts':{k:len(v) for k,v in protected['groups'].items()},'protectedManifestSha256':file_sha(PACKET/'evidence/capture-revision-r1/protected-audit.txt'),'allPriorPacketFilesUnchangedExceptFreshReadiness':True,'allPriorPacketFiles':before['packetBefore'],'protected':protected,'flagsFalse':True,'absentProspectivePaths':paths,'inventorySha256':file_sha(PACKET/'inventory.json'),'payload':{'files':101,'PNGs':94,'readouts':7,'units':plan['units'],'copyCount':plan['copyCount'],'reserves':plan['reserves'],'deadlines':plan['seconds']}}
(E/'combined-freeze.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['status','readySha256','sourceDigest','sourceClosureRows','sourceClosureIncludesNewLifecycleTest','protectedCounts','flagsFalse']}))
