import hashlib, io, json, os, signal, stat, sys, tarfile
from pathlib import Path
signal.alarm(120)
root=Path(__file__).resolve().parent
destination=Path.cwd()/'packages/tools/src/capture/viewmodel_packet/evidence/t15-adoption'
archive=destination/'cpu-evidence.tar.gz'
paths=sorted(root.rglob('*'));rows=[];total=0
with tarfile.open(archive,'x:gz',compresslevel=3) as output:
 for path in paths:
  info=path.lstat();name=str(path.relative_to(root))
  if stat.S_ISREG(info.st_mode):
   total+=info.st_size;assert total<=1024**3 and info.st_size<=128*1024**2
   fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
   with os.fdopen(fd,'rb') as stream:
    opened=os.fstat(stream.fileno());assert (opened.st_dev,opened.st_ino,opened.st_size)==(info.st_dev,info.st_ino,info.st_size)
    digest=hashlib.sha256()
    class Reader:
     def read(self,n):
      data=stream.read(n);digest.update(data);return data
    tarinfo=tarfile.TarInfo('evidence/'+name);tarinfo.size=info.st_size;tarinfo.mode=0o600;tarinfo.mtime=info.st_mtime
    output.addfile(tarinfo,Reader())
    after=os.fstat(stream.fileno());assert (after.st_size,after.st_mtime_ns)==(opened.st_size,opened.st_mtime_ns)
   rows.append({'path':name,'kind':'file','bytes':info.st_size,'sha256':digest.hexdigest()})
  elif stat.S_ISDIR(info.st_mode):rows.append({'path':name,'kind':'directory'})
  elif stat.S_ISLNK(info.st_mode):rows.append({'path':name,'kind':'symlink','target':os.readlink(path)})
  elif stat.S_ISFIFO(info.st_mode):rows.append({'path':name,'kind':'fifo'})
  else:raise AssertionError((path,info.st_mode))
manifest={'sourceRoot':str(root),'note':'All regular evidence bytes retained; FIFO/symlink identities recorded without opening or following. Source scratch remains untouched. Synthetic CPU fixtures only.','rows':rows}
raw=(json.dumps(manifest,indent=2)+'\n').encode();(destination/'archive-manifest.json').write_bytes(raw)
expected={row['path']:row for row in rows if row['kind']=='file'}
with tarfile.open(archive,'r:gz') as check:
 for member in check:
  assert member.isfile();row=expected.pop(member.name.removeprefix('evidence/'));assert member.size==row['bytes'];digest=hashlib.sha256()
  with check.extractfile(member) as stream:
   for data in iter(lambda:stream.read(1024**2),b''):digest.update(data)
  assert digest.hexdigest()==row['sha256']
assert not expected
index={'status':'PASS','argv':[sys.executable,'-B',str(Path(__file__))],'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'manifestSha256':hashlib.sha256(raw).hexdigest(),'logicalFileBytes':total,'regularFiles':sum(row['kind']=='file' for row in rows),'nonregular':sum(row['kind'] not in ('file','directory') for row in rows),'preservedScratch':str(root),'archiveReadbackVerified':True}
(destination/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(index,indent=2))
