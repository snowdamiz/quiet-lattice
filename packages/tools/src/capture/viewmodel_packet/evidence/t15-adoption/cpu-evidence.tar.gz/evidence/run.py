import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent;name=sys.argv[1];argv=sys.argv[2:]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}
log=root/(name+'.log');start=time.monotonic()
with log.open('xb') as output:
 try:
  done=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,env=env,timeout=150);code=done.returncode
 except subprocess.TimeoutExpired:
  code=124
row={'name':name,'argv':argv,'cwd':os.getcwd(),'exit':code,'elapsedSeconds':time.monotonic()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'environment':{k:env.get(k) for k in ['PATH','PYTHONPATH','PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','TMPDIR','NODE_OPTIONS','NODE_DISABLE_COMPILE_CACHE','VM_ENTRY_EVIDENCE','VM_REVISION_TMP']}}
with (root/'commands.jsonl').open('a') as output:output.write(json.dumps(row)+'\n')
print(json.dumps({k:row[k] for k in ["name","exit","elapsedSeconds","log","sha256"]}));print(log.read_text(errors='replace')[-1800:]);sys.exit(code)
