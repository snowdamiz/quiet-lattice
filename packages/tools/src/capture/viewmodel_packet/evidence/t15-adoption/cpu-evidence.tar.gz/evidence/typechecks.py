import subprocess,sys
from pathlib import Path
root=Path.cwd()
node='/Users/andreyyurlov/.local/share/fnm/node-versions/v26.12.1/installation/bin/node'
tsc=str(root/'node_modules/.pnpm/typescript@6.0.3/node_modules/typescript/bin/tsc')
for name in ['shared','client','server','tools']:
    cmd=[node,tsc,'-p',str(root/'packages'/name)]
    print(repr(cmd),flush=True)
    result=subprocess.run(cmd,timeout=90)
    if result.returncode:sys.exit(result.returncode)
