import ast,hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path.cwd();P=R/'packages/tools/src/capture/viewmodel_packet';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();compiled={}
for p in P.glob('*.py'):compile(p.read_bytes(),str(p),'exec');compiled[p.name]=sha(p)
protected=json.loads((P/'evidence/capture-revision-r1/protected-audit.txt').read_text())
for n,h in protected['reports'].items():assert sha(n)==h,n
for n,h in protected['helpers'].items():assert sha(R/n)==h,n
unchanged={}
for n in ('entry.mjs','fixture.mjs','inspect_packet.py','inventory.json','resolve.mjs','protocol_child.py','test_protocol.py','test_live_usage.py','test_revision.py','test_native.py','test_r2.py'):
 assert (E/'base'/n).read_bytes()==(P/n).read_bytes(),n;unchanged[n]=sha(P/n)
old=(E/'base/native.py').read_text();new=(P/'native.py').read_text();start='        # Cleanup gets one finite phase';end='            raise primary\n'
a=old[old.index(start):old.index(end,old.index(start))+len(end)];b=new[new.index(start):new.index(end,new.index(start))+len(end)];assert a==b
old_size=next(n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name=='size');new_size=next(n for n in ast.parse(new).body if isinstance(n,ast.FunctionDef) and n.name=='size');assert ast.dump(old_size)==ast.dump(new_size)
ready=json.loads((P/'readiness.json').read_text());prior=json.loads((E/'base/readiness.json').read_text())
for k in ('sourceDigest','ignoredInventorySha256','trees','node','python','pythonKernel','tsxApi','playwright','esbuild','browserBinary','decoderPython','decoderSite','process_binary_sha256'):assert ready['bindings'][k]==prior['bindings'][k],k
original=subprocess.check_output(['git','diff','--full-index','--binary','38b6c4b58db43146df20cd760808d1461d7a667b^','38b6c4b58db43146df20cd760808d1461d7a667b']);adopt=subprocess.check_output(['git','diff','--full-index','--binary','dea07963^','dea07963']);assert original==adopt
r={'compiled':compiled,'unchanged':unchanged,'strictCleanupSegmentSha256':hashlib.sha256(a.encode()).hexdigest(),'t15PatchSha256':hashlib.sha256(original).hexdigest(),'helpers':protected['helpers'],'protectedReports':protected['reports'],'shared':{n:sha(R/n) for n in ('packages/tools/src/capture/capture.ts','packages/tools/src/capture/capture.lifecycle.test.ts','packages/client/src/entities/Multitool.js')},'historicalReuse':'Shared lifecycle100/client110/TS/PNG/timeline results are unchanged historical evidence; no broad suite repeated','base':'a78c7e5f58e399fcecab0197b65ffe42500cb16a'};(E/'static-reuse.json').write_text(json.dumps(r,indent=2)+'\n');subprocess.run(['git','diff','--check'],check=True);print(json.dumps({'compiled':len(compiled),'unchanged':unchanged,'strictCleanup':r['strictCleanupSegmentSha256']}))
