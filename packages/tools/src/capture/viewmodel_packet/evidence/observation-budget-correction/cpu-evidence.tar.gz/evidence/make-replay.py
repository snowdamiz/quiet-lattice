from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');s=(P/'protocol_child.py').read_text()
s=s.replace("index=int(sys.argv[3])", "index=int(sys.argv[3]); ticks=0")
s=s.replace("rows=[{'pid':990001+i,'birth':[1,i],'uid':os.getuid(),'pgid':990001,'status':2} for i in range(4)]", "rows=list(json.loads(Path('/private/tmp/p1-e05-t03-viewmodel-packet-live-qsu7czb1/review-thalune/job/boundary.json').read_text())['identities'].values())")
s=s.replace("job.root=rows[0];job.coalition_id=111111", "job.root=rows[0];job.coalition_id=43446")
a=s.index(' def status(job):');b=s.index(' def drain(job,*_):',a)
s=s[:a]+''' def status(job):
  global ticks
  ticks+=1
  if ticks>int(os.environ.get('VM_REPLAY_TICKS','150')):job.state['exits']['capture']=0
  job.save()
  return job.state
'''+s[b:]
s=s.replace("drained=True;job.state.update", "drained=True;job.state.update")
s=s.replace(" def capture(ready,spec,paths,record):\n  result=native.capture(ready,spec,paths,record)"," def capture(ready,spec,paths,record):\n  memory.append(record)\n  result=native.capture(ready,spec,paths,record)")
s=s.replace(" frozen=json.loads", " frozen=json.loads")
s=s.replace(" spec=repo.plan", " memory=[]\n spec=repo.plan")
s=s.replace("(jb.StationJob,'members',lambda _:[] if drained else rows),", "(jb,'user_pids',lambda:[] if drained else [r['pid'] for r in rows]+list(range(900000,900000+int(os.environ.get('VM_REPLAY_NONMEMBERS','1024'))))),")
s=s.replace("('coalition',lambda _: [111111,0])", "('coalition',lambda pid: [43446,43447] if any(r['pid']==pid for r in rows) else [777,778])")
s=s.replace("lambda pid: None if drained else next(r for r in rows if r['pid']==pid)","lambda pid: None if drained else next((r for r in rows if r['pid']==pid),None)")
s=s.replace("' --type='+['gpu-process','renderer','utility'][i-1]", "' --type='+['gpu-process','renderer','utility'][(i-1)%3]")
s=s.replace(" disk=json.loads", " from collections import Counter\n native_facts=memory[0]['native']; counts=dict(Counter(e['operation'] for e in native_facts['helperCalls']))\n measured={'ticks':ticks,'counts':counts,'events':len(native_facts['helperCalls']),'observedBytes':native_facts.get('helperObservationBytes'),'primary':str(memory[0]['primaryFailure']),'helperErrors':native_facts.get('jobState',{}).get('state',{}).get('errors'),'publication':[str(e['error']) for e in memory[0].get('persistenceErrors',[])],'cleanupTrace':trace,'nativeSnapshotReconstructed':False,'syntheticNonmembers':int(os.environ.get('VM_REPLAY_NONMEMBERS','1024'))}\n (root/'growth.json').write_text(json.dumps(measured,indent=2)+'\\n')\n disk=json.loads")
(E/'growth-child.py').write_text(s)
