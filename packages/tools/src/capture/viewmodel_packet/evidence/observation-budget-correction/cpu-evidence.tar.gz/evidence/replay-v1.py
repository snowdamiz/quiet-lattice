import os,sys,json,subprocess,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P));from test_protocol import repository
assert (E/'base/native.py').read_bytes()==(P/'native.py').read_bytes()
root,repo=repository();repo.grant(0);argv=[sys.executable,'-B',str(E/'growth-child.py'),'--inert-cpu-fixture',str(root),'0','success'];env={**os.environ,'VM_PACKET_UNDER_TEST':str(P)}
p=subprocess.run(argv,env=env,capture_output=True,timeout=90);(E/'red.stdout').write_bytes(p.stdout);(E/'red.stderr').write_bytes(p.stderr)
facts=json.loads((root/'growth.json').read_text());facts.update(argv=argv,exit=p.returncode,root=str(root));(E/'red-measurement.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps(facts));assert p.returncode==1 and 'Raw helper observation ceiling exceeded' in str(facts) and 'Raw observation node ceiling' in str(facts)
