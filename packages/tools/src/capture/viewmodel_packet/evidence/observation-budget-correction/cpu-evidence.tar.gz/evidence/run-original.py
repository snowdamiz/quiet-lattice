import os,sys,json,time,subprocess,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8');name=sys.argv[1];args=sys.argv[2:]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(E/'tmp'),TMP=str(E/'tmp'),TEMP=str(E/'tmp'),NODE_DISABLE_COMPILE_CACHE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',VM_REVISION_TMP=str(E/'tmp'))
(E/'tmp').mkdir(exist_ok=True);start=time.monotonic()
with (E/(name+'.log')).open('xb') as out:p=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=240)
raw=(E/(name+'.log')).read_bytes();row={'name':name,'argv':args,'cwd':str(R),'exit':p.returncode,'seconds':time.monotonic()-start,'logSha256':hashlib.sha256(raw).hexdigest(),'env':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','TMPDIR','NODE_DISABLE_COMPILE_CACHE','VM_REVISION_TMP','NODE_OPTIONS','VM_ENTRY_EVIDENCE','VM_CAPTURE_SOURCE'] if k in env}}
with (E/'commands.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
print(json.dumps(row));print(raw.decode(errors='replace')[-2200:]);sys.exit(p.returncode)
