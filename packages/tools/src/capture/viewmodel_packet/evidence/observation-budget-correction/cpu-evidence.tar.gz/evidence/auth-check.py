import sys,os,json,subprocess,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path.cwd();P=R/'packages/tools/src/capture/viewmodel_packet';sys.path.insert(0,str(P));import caller
ready=json.loads((P/'readiness.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('VIEWMODEL_')};env['PATH']=ready['bindings']['path'];env['NODE_DISABLE_COMPILE_CACHE']='1';rows=[]
for name,argv in [('caller',[sys.executable,'-B',str(P/'caller.py'),'--ready',str(P/'readiness.json'),'--unit','review-thalune']),('entry',[ready['bindings']['node'],str(P/'entry.mjs')]),('check',[sys.executable,'-B',str(P/'caller.py'),'--check',str(P/'readiness.json')])]:
 p=subprocess.run(argv,cwd=R,env=env,capture_output=True,timeout=45);(E/(name+'-auth.stdout')).write_bytes(p.stdout);(E/(name+'-auth.stderr')).write_bytes(p.stderr)
 assert p.returncode==(0 if name=='check' else 1),(name,p.stdout,p.stderr)
 if name=='caller':assert b'Missing parent grant' in p.stderr
 if name=='entry':assert b'Missing consumed parent grant' in p.stderr
 rows.append({'name':name,'argv':argv,'exit':p.returncode,'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':hashlib.sha256(p.stderr).hexdigest()})
paths=sorted({str(v) for row in ready['paths'].values() for v in [*row.values(),*caller.terminal_paths(row)]}|set(ready['containers'].values()));assert all(not Path(p).exists() and not Path(p).is_symlink() for p in paths)
(E/'auth-check.json').write_text(json.dumps({'commands':rows,'path':env['PATH'],'absent':paths,'runtimeEnabled':ready['runtimeEnabled'],'entryEnabled':ready['entryEnabled']},indent=2)+'\n');print(json.dumps({'commands':rows,'absent':len(paths)}))
