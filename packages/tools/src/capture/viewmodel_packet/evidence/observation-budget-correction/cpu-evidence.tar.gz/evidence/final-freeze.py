import os,sys,json,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P));import caller,bindings,boundary
old=json.loads((P/'readiness.json').read_text());os.environ['PATH']=old['bindings']['path']
ready=caller.prepare();data=(json.dumps(ready,indent=2)+'\n').encode()
assert ready['bindings']['node']=='/Users/andreyyurlov/.local/share/fnm/node-versions/v26.12.1/installation/bin/node'
assert ready['bindings']['sourceDigest']==old['bindings']['sourceDigest']
assert ready['bindings']['trees']==old['bindings']['trees']
assert ready['bindings']['ignoredInventorySha256']==old['bindings']['ignoredInventorySha256']
assert ready['runtimeEnabled'] and ready['entryEnabled'] and not ready['nativeQualified']
paths=sorted({str(v) for row in ready['paths'].values() for v in [*row.values(),*caller.terminal_paths(row)]}|set(ready['containers'].values()));assert all(not Path(p).exists() for p in paths)
(P/'readiness.json').write_bytes(data)
(E/'final-readiness.json').write_bytes(data)
(E/'final-freeze.json').write_text(json.dumps({'sha256':hashlib.sha256(data).hexdigest(),'absent':paths,'oldHistoricalReadySha256':hashlib.sha256((E/'base/readiness.json').read_bytes()).hexdigest(),'status':ready['executionStatus'],'nativeQualified':False,'sourceDigest':ready['bindings']['sourceDigest'],'processes':ready['bindings']['process_binary_sha256'],'self':ready['pythonSelfObservation']},indent=2)+'\n')
print(json.dumps({'sha256':hashlib.sha256(data).hexdigest(),'absentPaths':len(paths),'status':ready['executionStatus'],'nativeQualified':False}))
