import sys,os,json,hashlib,tempfile
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P));import bindings;sys.path.insert(0,str(bindings.HELPERS));import round4_job_boundary as helper
root=Path(tempfile.mkdtemp(prefix='write-',dir='/private/tmp/vmo-7o2wl_r3'));value={'observation':'x'*131072};body=(json.dumps(value,indent=2)+'\n').encode();path=root/'receipt.json'
for _ in range(150):helper.write(path,value)
files=[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in root.iterdir()]
facts={'scope':'Actual frozen helper.write, CPU owned files only; no job launch','attempts':150,'attemptedBytes':150*len(body),'retainedBytes':sum(f['bytes'] for f in files),'bothTargetAndAtomicTemporaryReserve':2*len(body),'files':files,'root':str(root)};assert facts['attemptedBytes']>16*1024**2 and facts['bothTargetAndAtomicTemporaryReserve']<16*1024**2;(E/'overwrite-premise.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps(facts))
