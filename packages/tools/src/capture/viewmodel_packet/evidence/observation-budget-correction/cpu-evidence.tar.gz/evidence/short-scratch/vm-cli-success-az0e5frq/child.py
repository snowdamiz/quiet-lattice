
import json, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import caller
caller.HERE = Path(sys.argv[2])
def capture(ready, spec, paths, record):
    for name in spec['files']:
        (Path(paths['output']) / name).write_text('INERT BOUNDARY FIXTURE '+name)
    record['ports'] = ['capture', 'release']
    return {'released': True}
def decoder(ready, spec, paths, record, frozen):
    assert record['released']
    record['ports'].append('decode')
    record['inspection'] = {'valid': True, 'inert': True}
def cache(ready, evidence, record): record['initialCacheBytes'] = 0
def runner(*args): return caller.run_unit(*args, capture=capture, decoder=decoder, cache_copy=cache, final_verify=lambda _: {})
code, result = caller.main(Path(sys.argv[3]), sys.argv[4], Path(sys.argv[5]), enabled=True, verifier=lambda _: {}, runner=runner)
print(json.dumps({'code': code, 'durable': result['durable']}))
raise SystemExit(code)
