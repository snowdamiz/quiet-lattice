import json,sys,subprocess,tempfile
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P));import native,observations
root=Path(tempfile.mkdtemp(prefix='order-',dir='/private/tmp/vmo-7o2wl_r3'));e={'helperCalls':[]};j=observations.Journal(root/'journal',e);mods=[SimpleNamespace(write=lambda *_:None) for _ in range(3)];mods[0]._archive_profile_paths=lambda *_:None
with patch.object(subprocess,'run',lambda *a,**k:subprocess.CompletedProcess(a[0],0,stdout=b'cpu',stderr=b'')),patch.object(subprocess,'Popen',side_effect=AssertionError('NO_PROCESS')),native.observed_helpers(mods,e,journal=j):assert subprocess.check_output(['/inert'])==b'cpu'
received=[];observations.validate(j.directory,j.manifest,consume=received.append)
print(json.dumps([{'operation':r['operation'],'callSequence':r.get('callSequence')} for r in received]))
assert [r['operation'] for r in sorted(received,key=lambda r:r['callSequence'])]==['check_output','run']
