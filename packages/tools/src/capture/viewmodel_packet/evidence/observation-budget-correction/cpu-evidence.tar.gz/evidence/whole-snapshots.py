import sys,json,hashlib,tempfile
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P));import observations,boundary
from test_r2 import graph_decode
source=Path('/private/tmp/space-vm-parent-unit1-r2-q6kzldbb');inputs={n:(source/n).read_bytes() for n in ('processes-before.txt','processes-after.txt')};unknown={'raw':b'\x00\xff'};unknown['cycle']=unknown;value={**inputs,'a':unknown,'b':unknown};event={'operation':'CPU_REPLAY_PARENT_SNAPSHOTS_NOT_VM_CALLBACK_HISTORY','value':boundary.raw(value)}
root=Path(tempfile.mkdtemp(prefix='whole-',dir='/private/tmp/vmo-7o2wl_r3'));e={};journal=observations.Journal(root/'journal',e)
for _ in range(20):journal.append(event)
e['phase']='cleanup';journal.finish();count=0
expected={n:hashlib.sha256(data).hexdigest() for n,data in inputs.items()}
def consume(event):
 global count
 value=graph_decode(event['value']);assert value['a'] is value['b'] and value['a']['cycle'] is value['a'];assert value['a']['raw']==b'\x00\xff'
 for n,h in expected.items():assert hashlib.sha256(value[n]).hexdigest()==h
 count+=1
facts=observations.validate(journal.directory,journal.manifest,consume=consume);assert count==20
facts.update(scope='20 explicit synthetic repetitions of retained out-of-band parent snapshots; no reconstructed original VM history',inputSha256=expected,inputBytes={n:len(b) for n,b in inputs.items()},root=str(root));(E/'whole-snapshots.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps(facts))
