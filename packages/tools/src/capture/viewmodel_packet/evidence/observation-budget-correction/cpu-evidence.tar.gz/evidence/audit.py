import sys,os,json,hashlib,stat,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8');P=R/'packages/tools/src/capture/viewmodel_packet'
def file(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode),str(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'bytes':s.st_size,'sha256':h.hexdigest()}
protected=json.loads((P/'evidence/capture-revision-r1/protected-audit.txt').read_text());data={'protected':{k:{n:file(R/n) for n in v} for k,v in protected['groups'].items()},'helpers':{n:file(R/n) for n in protected['helpers']}}
for k,v in protected['groups'].items():
 for n,r in v.items():assert data['protected'][k][n]['sha256']==r['sha256'],n
for n,h in protected['helpers'].items():assert data['helpers'][n]['sha256']==h,n
data['trackedOutsidePacket']={os.fsdecode(n):file(R/os.fsdecode(n)) for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0') if n and not n.startswith(b'packages/tools/src/capture/viewmodel_packet/')}
roots=['/private/tmp/vm-live-sampling-qsu7czb1','/private/tmp/space-vm-parent-unit1-r2-q6kzldbb','/private/tmp/p1-e05-t03-viewmodel-packet-live-qsu7czb1','/private/tmp/lrv-1rcMrgis','/private/tmp/space-vm-parent-unit1-r5-kghan_6a','/private/tmp/p1-e05-t03-viewmodel-packet-r5-rdtnxbus','/private/tmp/p1-e05-t03-r5-IeiUns','/private/tmp/p1-e05-t03-r4-RzbhYi','/private/tmp/vm-r4-fix-rdtnxbus','/private/tmp/vm-native-fix-ydkbvouf','/private/tmp/egp-164a9dca1cd5400c8f734587e449adeb','/private/tmp/space-effects-parent-pilot-r2-1of62im8']
data['history']={};data['special']={}
for root in roots:
 for p in Path(root).rglob('*'):
  if p.is_symlink(): data['special'][str(p)]={'symlink':os.readlink(p)}
  elif p.is_file():data['history'][str(p)]=file(p)
for p in Path('/private/tmp').glob('p1-e05-t03-viewmodel-packet-*-*.json'):
 if p.is_file():data['history'][str(p)]=file(p)
ready=json.loads((P/'readiness.json').read_text());sys.path.insert(0,str(P));import bindings
os.environ['PATH']=ready['bindings']['path'];data['trees']=[bindings.tree_binding(t['path']) for t in ready['bindings']['trees']];data['ignoredSha256']=hashlib.sha256(bindings.ignored_inventory(R)).hexdigest()
label=sys.argv[1];(E/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
if label!='before':assert data==json.loads((E/'before.json').read_text()),'PRESERVATION MISMATCH'
print(json.dumps({'protected':sum(map(len,data['protected'].values())),'tracked':len(data['trackedOutsidePacket']),'history':len(data['history']),'trees':data['trees'],'ignored':data['ignoredSha256']}))
