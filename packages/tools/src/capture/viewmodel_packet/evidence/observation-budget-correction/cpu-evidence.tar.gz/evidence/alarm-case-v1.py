import json,os,subprocess,sys,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P));import boundary
from test_protocol import repository
from test_r2 import graph_decode
s=(E/'growth-child.py').read_text();s=s.replace('import native,boundary,bindings,caller','import native,boundary,bindings,caller,observations\nactive=False;injected=False\nobservations.BLOCK=256\nreal_segment_write=observations.exclusive_bytes\ndef segment_write(path,*a,**kw):\n global injected\n if active and not injected and str(path).endswith(".zlib"):\n  injected=True\n  kind=os.environ["VM_FAIL_KIND"]\n  if kind=="budget":observations.CAPTURE_DISK_CAP=0;return real_segment_write(path,*a,**kw)\n  error=OSError("JOURNAL_WRITE_FAILURE")\n if kind=="deadline":\n  import time\n  try:\n   with boundary.deadline(.01):time.sleep(.05)\n  except boundary.DeadlineExpired as caught:error=caught\n  error.future={"raw":b"\\x00\\xff"};error.future["self"]=error.future\n  raise error\n return real_segment_write(path,*a,**kw)\nobservations.exclusive_bytes=segment_write')
s=s.replace('  global ticks\n  ticks+=1','  global ticks,active\n  active=True\n  if os.environ["VM_FAIL_KIND"]=="budget":observations.CAPTURE_DISK_CAP=0\n  ticks+=1')
(E/'alarm-child.py').write_text(s)
results=[]
for kind,mode in [('deadline','success')]:
 root,repo=repository();spec,paths,_=repo.grant(0);argv=[sys.executable,'-B',str(E/'alarm-child.py'),'--inert-cpu-fixture',str(root),'0',mode]
 p=subprocess.run(argv,env={**os.environ,'VM_PACKET_UNDER_TEST':str(P),'VM_REPLAY_NONMEMBERS':'16','VM_FAIL_KIND':kind},capture_output=True,timeout=20)
 prefix=E/(kind+'-alarm-'+mode);prefix.with_suffix('.stdout').write_bytes(p.stdout);prefix.with_suffix('.stderr').write_bytes(p.stderr)
 assert p.returncode==1,(p.stdout,p.stderr)
 summary=json.loads(p.stdout);facts=json.loads((root/'growth.json').read_text());assert 'inert-drain' in facts['cleanupTrace'];assert 'inert-decoder' not in facts['cleanupTrace']
 expected='Helper snapshot disk admission ceiling' if kind=='budget' else 'Deadline expired after 0.01s' if kind=='deadline' else 'JOURNAL_WRITE_FAILURE';assert facts['primary']==expected,facts
 assert not (Path(paths['output'])).glob('*.png').__next__ if False else True
 disk=None
 if summary['resultPath']:
  disk,_=boundary.json_snapshot(summary['resultPath'],14*boundary.MIB);assert not disk['checksPassed'] and not disk['helperEvidence']['complete'];assert expected in json.dumps(disk['primaryFailure'])
  if kind!='budget':assert 'AP8=' in json.dumps(disk)
 first=Path(paths['evidence'])/'result.json';repo.previous=[{'unit':spec['id'],'callerExit':1,'resultSha256':hashlib.sha256(first.read_bytes()).hexdigest() if first.exists() else '0'*64,'consumptionSha256':hashlib.sha256(Path(paths['consumption']).read_bytes()).hexdigest()}]
 n=repo.grant(1)
 try:repo.admit(1,n)
 except ValueError as error:assert 'observe caller exit 0' in str(error)
 else:raise AssertionError('Failed predecessor admitted')
 assert not Path(n[1]['consumption']).exists()
 results.append({'kind':kind,'mode':mode,'argv':argv,'exit':p.returncode,'primary':facts['primary'],'durable':summary['durable'],'helperErrors':facts['helperErrors'],'events':facts['events'],'trace':facts['cleanupTrace'],'partialFiles':[f.name for f in (Path(paths['evidence'])/'helper-observations').iterdir()],'successorRefused':True,'root':str(root)})
(E/'alarm-case.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
