import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
for(const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) {
 const original=cp[name];
 cp[name]=(...args)=>{if(name==='execFileSync' && args[0]==='git') return original(...args);throw Error('PROCESS_EXECUTION_FORBIDDEN:'+name+':'+args[0]);};
}
syncBuiltinESMExports();
