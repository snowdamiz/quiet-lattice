import ast, copy, hashlib, importlib.util, json, os, shutil, subprocess, sys, time, unittest
from pathlib import Path

S = Path(__file__).resolve().parent
R = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
H = R/'packages/tools/src/capture/viewmodel_packet'
A = Path('/private/tmp/vm-r3-fix-bpmhg9qg/decoder')
V = Path('/private/tmp/p1-e05-t03-timeline-r4-YQHDQkRt')
PY = '/Users/andreyyurlov/.local/share/uv/python/cpython-3.10.22-macos-aarch64-none/bin/python3.10'
NODE = '/Users/andreyyurlov/.local/share/fnm/node-versions/v26.12.1/installation/bin/node'
ENV = {'PATH':'/usr/bin:/bin','LANG':'C','PYTHONDONTWRITEBYTECODE':'1','NODE_DISABLE_COMPILE_CACHE':'1','GIT_OPTIONAL_LOCKS':'0',
       'PYTHONPATH':'/Users/andreyyurlov/.cache/uv/archive-v0/a88MR2jSm399x3XK/lib/python3.10/site-packages',
       **{k:str(S/'tmp') for k in ('TMP','TEMP','TMPDIR','VM_REVISION_TMP')}, 'XDG_CACHE_HOME':str(S/'cache'),
       **{k:'1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')}}
realrun = subprocess.run

def hashes(p):
    raw = Path(p).read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def write(p, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True)+'\n').encode()
    with Path(p).open('xb') as f: f.write(raw)

def git(*args):
    return realrun(['/usr/bin/git',*args],cwd=R,env=ENV,capture_output=True,check=True).stdout

def module(p, name):
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m

def run(label, argv):
    d = S/label; d.mkdir(parents=True)
    command = ['/usr/bin/sandbox-exec','-f',str(S/'readonly.sb'),*argv]
    row = dict(argv=argv, executionArgv=command, cwd=str(R), environment=ENV)
    write(d/'invocation.json',row)
    start = time.monotonic()
    p = realrun(command,cwd=R,env=ENV,capture_output=True,timeout=180)
    write(d/'stdout',p.stdout); write(d/'stderr',p.stderr)
    row.update(exit=p.returncode,seconds=time.monotonic()-start,stdout=hashes(d/'stdout'),stderr=hashes(d/'stderr'))
    write(d/'result.json',row)
    print(label, 'exit', p.returncode, flush=True)
    return p

def cli(label, source, unit, folder):
    p = run(label,[PY,'-B',str(source/'inspect_packet.py'),'--inventory',str(S/'base/inventory.json'),
                   '--unit',unit,'--output',str(folder/'output'),'--manifest',str(folder/'manifest.json')])
    result = json.loads(p.stdout or p.stderr)
    value = json.loads((folder/'output/observations.json').read_text())
    assert result.get('observations',result.get('evidence',{}).get('observations')) == value
    return dict(unit=unit,case=label,exit=p.returncode,primaryFailure=result.get('primaryFailure'),packet=str(folder))

NEW = ['test_cli_visible_raise_reset_requires_hidden_and_visible_updates',
       'test_cli_initial_budget_adds_required_zero_updates_to_elapsed_steps',
       'test_cli_reset_budget_accepts_reachable_hidden_and_visible_steps']
FOCUSED = NEW + ['test_cli_zero_time_resets_settled_observations_and_extra_updates_remain_valid',
    'test_cli_initial_clock_requires_setup_and_first_pose_settle',
    'test_cli_underwater_recovery_uses_runtime_raise_bound_for_every_people',
    'test_cli_sway_reachability_covers_both_axes_and_every_people',
    'test_cli_every_endpoint_reconciles_fixed_step_clock',
    'test_cli_timed_raise_reconciles_elapsed_frames_and_last_dt',
    'test_cli_switch_settled_reconciles_gap_elapsed_frames_and_last_dt',
    'test_cli_switch_settled_accepts_fixed_steps_and_zero_dt_resets']

mode = sys.argv[1]
if mode == 'prepare':
    (S/'base').mkdir(); (S/'tmp').mkdir(); (S/'cache').mkdir()
    assert git('rev-parse','HEAD','HEAD^{tree}').decode().splitlines() == ['af301db512343f2d578e68b8cfdbe7f72bfe794d','70fa16f7484cf5af0e9d150b49e7c3269fe675e2']
    assert git('branch','--show-current').decode().strip() == 'task/P1-E05-T03'
    for name in ('inspect_packet.py','test_inspect.py','inventory.json'):
        raw = git('show',f'HEAD:packages/tools/src/capture/viewmodel_packet/{name}')
        assert raw == (H/name).read_bytes()
        write(S/'base'/name, raw)
    paths = [H/n for n in ('fixture.mjs','inventory.json')]
    paths += [Path(p) for p in json.loads((V/'runtime-facts-v4.json').read_text())['sourceHashes']]
    paths += [R/'node_modules/typescript/lib/typescript.js',Path(PY)]
    for directory in (A, V, Path('/private/tmp/p1-e05-t03-r4-RzbhYi')):
        paths += [p for p in directory.rglob('*') if p.is_file()]
    write(S/'before.json',dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),
                              files={str(p):hashes(p) for p in sorted(set(paths))},base={n:hashes(S/'base'/n) for n in ('inspect_packet.py','test_inspect.py','inventory.json')}))
    write(S/'environment.json', ENV)
    write(S/'readonly.sb',f'(version 1)\n(allow default)\n(deny network*)\n(deny file-write*)\n(allow file-write* (subpath "{S}") (literal "/dev/null"))\n'.encode())
    for name in ('runtime.mjs','runtime-frame-budget.mjs'):
        raw = (V/name).read_text(); needle = f"const scratch='{V}';"
        assert raw.count(needle) == 1
        write(S/name,raw.replace(needle,f"const scratch='{S}';").encode())
    print('Prepared exact-base copied bytes and preservation hashes',len(set(paths)))
elif mode == 'runtime':
    for name in ('runtime','runtime-frame-budget'):
        p = run(name,[NODE,'--experimental-vm-modules',str(S/f'{name}.mjs')]); assert p.returncode == 0,p.stderr
    for name in ('runtime-facts-v4.json','frame-budget-runtime-facts.json'):
        assert json.loads((S/name).read_text()) == json.loads((V/name).read_text())
    facts = json.loads((S/'runtime-facts-v4.json').read_text())
    write(S/'runtime-parity.json',dict(equalToR4=True,timelines=len(facts['timelines']),endpoints=sum(len(t['frames']) for t in facts['timelines']),transitions=len(facts['transitions']),sourceHashes=facts['sourceHashes']))
elif mode in ('red-replay','green-replay'):
    source = S/'base' if mode == 'red-replay' else H
    rows = []
    for folder in sorted((V/'frame-budget/packets').glob('*/*')):
        unit,label = folder.parent.name,folder.name
        row = cli(f'{mode}/{unit}/{label}',source,unit,folder)
        expected = 0 if mode == 'red-replay' or 'control' in label else 1
        assert row['exit'] == expected,row
        rows.append(row)
    assert len(rows) == 7
    write(S/f'{mode}.json',rows)
elif mode in ('red-tests','red-tests-v2','green-tests'):
    p = run(mode,[PY,'-B',str(S/'run.py'),mode+'-inner'])
    assert p.returncode == (1 if mode.startswith('red-tests') else 0),p.stderr[-5000:]
elif mode in ('red-tests-inner','red-tests-v2-inner','green-tests-inner'):
    label = mode[:-6]; folder = S/label
    tests = module(H/'test_inspect.py','decoder_tests')
    if label.startswith('red-tests'):
        tests.HERE = S/'base'; tests.inspector = module(S/'base/inspect_packet.py','base_inspector')
    tests.tempfile.TemporaryDirectory.cleanup = lambda self:self._finalizer.detach()
    records = []
    def recorded(argv, **kwargs):
        d = folder/'cli'/f'{len(records):04d}'; d.mkdir(parents=True)
        output = Path(argv[argv.index('--output')+1]); manifest = Path(argv[argv.index('--manifest')+1])
        shutil.copytree(output,d/'output'); shutil.copyfile(manifest,d/'manifest.json')
        row = dict(argv=argv,cwd=str(Path.cwd()),environment=dict(os.environ),inspector=hashes(argv[2]))
        write(d/'invocation.json',row)
        p = realrun(argv,**kwargs)
        write(d/'stdout',p.stdout.encode()); write(d/'stderr',p.stderr.encode())
        row.update(exit=p.returncode,stdout=hashes(d/'stdout'),stderr=hashes(d/'stderr'))
        write(d/'result.json',row); records.append(row)
        return p
    tests.subprocess.run = recorded
    names = NEW if label.startswith('red-tests') else FOCUSED
    result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(tests.InspectorTests(n) for n in names))
    write(folder/'summary.json',dict(tests=result.testsRun,methods=names,failures=len(result.failures),errors=len(result.errors),cli=len(records),
        exitCounts={str(c):sum(r['exit']==c for r in records) for c in (0,1)},inspector=hashes(tests.HERE/'inspect_packet.py'),testsSource=hashes(H/'test_inspect.py')))
    sys.exit(0 if result.wasSuccessful() else 1)
elif mode == 'oracle':
    facts = json.loads((S/'runtime-facts-v4.json').read_text()); rows=[]
    for folder in sorted((A/'oracle-controls').glob('*/*')):
        if not (folder/'manifest.json').is_file(): continue
        unit,label = folder.parent.name,folder.name
        value = json.loads((folder/'output/observations.json').read_text())
        timeline = next(t for t in facts['timelines'] if (t['unit'],t['variant']) == (unit,label))
        assert len(timeline['frames']) == len(value['frames'])
        for actual, observed in zip(value['frames'], timeline['frames']):
            assert all(actual[k] == v for k,v in observed.items())
        row = cli(f'oracle/{unit}/{label}',H,unit,folder); assert row['exit'] == 0,row
        rows.append(row)
    assert len(rows) == 14
    write(S/'oracle-results.json',rows)
elif mode == 'runtime-extra':
    prefix = (S/'runtime.mjs').read_text().split('const timelines=[];')[0]
    write(S/'runtime-extra.mjs',(prefix+(S/'runtime-extra-suffix.mjs').read_text()).encode())
    p = run('runtime-extra',[NODE,'--experimental-vm-modules',str(S/'runtime-extra.mjs')]); assert p.returncode == 0,p.stderr
elif mode == 'oracle-extra':
    tests = module(H/'test_inspect.py','extra_packet_tests')
    facts = json.loads((S/'runtime-extra-facts.json').read_text()); rows = []
    assert facts['sourceHashes'] == json.loads((S/'runtime-facts-v4.json').read_text())['sourceHashes']
    for timeline in facts['timelines']:
        unit,label = timeline['unit'],timeline['variant']
        folder = S/'oracle-extra-packets'/unit/label; folder.mkdir(parents=True)
        fixture = tests.Packet(folder,unit)
        assert len(fixture.value['frames']) == len(timeline['frames'])
        for entry,observed in zip(fixture.value['frames'],timeline['frames']):
            assert entry['file'] == observed['file']; entry.update(observed)
        fixture.value['unknownOracleFact'] = dict(unit=unit,variant=label)
        fixture.write(); write(folder/'manifest.json',dict(files=fixture.manifest))
        row = cli(f'oracle-extra/{unit}/{label}',H,unit,folder); assert row['exit'] == 0,row
        rows.append(row)
    assert len(rows) == 10
    write(S/'oracle-extra-results.json',rows)
else:
    raise ValueError(mode)
