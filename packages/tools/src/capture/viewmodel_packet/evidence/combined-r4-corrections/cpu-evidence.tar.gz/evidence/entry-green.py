import hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path.cwd()/'packages/tools/src/capture/viewmodel_packet';sys.path.insert(0,str(P))
from test_protocol import repository,process
from test_boundary import digest
root,repo=repository()
for pin in repo.ready['bindings']['bindings']:
 data=Path(pin['realpath']).read_bytes();pin['bytes']=len(data);pin['sha256']=hashlib.sha256(data).hexdigest()
repo.ready_path.write_text(json.dumps(repo.ready));spec,paths,_=repo.grant(0);child=process(repo,0);assert child.returncode==0,(child.stdout,child.stderr)
source=(P/'production.test.mjs').read_text().split('const { execute, productionCapture } =')[0]
source=source.replace("const packet = process.env.VM_PACKET_UNDER_TEST ?? import.meta.dirname;",'const packet = '+json.dumps(str(P))+';')
source+='''
for (const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) {
 const original=cp[name];
 cp[name]=(...args)=>{if(name==='execFileSync' && args[0]==='git')return original(...args);throw Error('NO_NATIVE:'+name)};
}
netPorts.Socket.prototype.connect=netPorts.Server.prototype.listen=()=>assert.fail('NO_NETWORK');
syncBuiltinESMExports();
const imported=await import(pathToFileURL(ready.bindings.playwright).href);
const required=createRequire(import.meta.url)(ready.bindings.playwright);
const esm=await import(pathToFileURL(ready.bindings.playwright.replace(/index\\.js$/,'index.mjs')).href);
assert.equal(imported.default,required);assert.equal(required.chromium,esm.chromium);
chromium=required.chromium;originalLaunch=chromium.launch;chromium.launch=inertChromium.launch;
failingOperation='goto';cleanupFails=true;primary=Object.assign(new Error('ACTUAL_ENTRY_GOTO'),{partial:Buffer.from([0,255]),unknown:{unchanged:true}});
vite.close=async()=>{trace.push('vite.close');throw Object.assign(new Error('ACTUAL_ENTRY_VITE_STOP'),{partial:Buffer.from([0,254])})};
process.on('exit',()=>fs.writeFileSync(process.env.VM_ENTRY_EVIDENCE,JSON.stringify({trace,sameChromium:true,node:process.version,launchRestored:chromium.launch===inertChromium.launch}),{flag:'wx'}));
'''
preload=root/'real-module-preload.mjs';preload.write_text(source)
raw=Path(paths['consumption']).read_bytes();consumed=json.loads(raw)
env={**os.environ,'VIEWMODEL_READY':str(repo.ready_path),'VIEWMODEL_CONSUMPTION':paths['consumption'],'VIEWMODEL_CONSUMPTION_SHA256':digest(paths['consumption']),'VIEWMODEL_ENTRY_TOKEN':consumed['entryToken'],'VIEWMODEL_SOURCE_HEAD':consumed['sourceHead'],'VIEWMODEL_UNIT':consumed['unit'],'VM_ENTRY_EVIDENCE':str(root/'entry-port-trace.json')}
argv=[repo.ready['bindings']['node'],'--import',str(E/'fs-guard.mjs'),'--import',str(preload),str(P/'entry.mjs')]
child=subprocess.run(argv,env=env,capture_output=True,timeout=10);(root/'actual-entry.stdout').write_bytes(child.stdout);(root/'actual-entry.stderr').write_bytes(child.stderr)
receipt=json.loads((Path(paths['evidence'])/'entry-result.json').read_text());trace=json.loads((root/'entry-port-trace.json').read_text())
assert child.returncode==1,(child.returncode,child.stdout,child.stderr)
assert receipt['captureFailed'] and not receipt['checksPassed'] and not receipt['accepted']
assert receipt['primaryFailure']['message']=='ACTUAL_ENTRY_GOTO' and receipt['primaryFailure']['partial']['base64']=='AP8='
assert receipt['primaryFailure']['unknown']=={'unchanged':True}
assert 'ACTUAL_ENTRY_VITE_STOP' in json.dumps(receipt['secondaryFailures']) and 'SECONDARY_BROWSER_CLOSE' in json.dumps(receipt['secondaryFailures'])
assert receipt['writes']==[] and len([x for x in receipt['resources'] if x['operation']=='chromium.launch'])==1
assert trace['trace'].count('inert-launch-port')==1 and trace['trace'].count('vite.close')==1 and trace['trace'].count('browser.close')==2 and trace['launchRestored']
report={'status':'PASS_ACTUAL_AUTHENTICATED_ENTRY_EXPECTED_FAILURE_FACTS','argv':argv,'cwd':str(Path.cwd()),'env':{k:v for k,v in env.items() if k.startswith(('VIEWMODEL_','VM_ENTRY_'))},'exit':child.returncode,'root':str(root),'preloadSha256':digest(preload),'trace':trace,'receipt':receipt,'nativeLaunches':0,'scope':'actual pinned CJS/public ESM singleton and actual entry/admission/productionCapture/shared captureReview; only browser launch/Vite/network/tsx compilation ports inert; synthetic authority bound to private Git'}
(E/'green-authenticated-entry.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'exit':child.returncode,'primary':receipt['primaryFailure']['message'],'secondaryCount':len(receipt['secondaryFailures']),'trace':trace}))
