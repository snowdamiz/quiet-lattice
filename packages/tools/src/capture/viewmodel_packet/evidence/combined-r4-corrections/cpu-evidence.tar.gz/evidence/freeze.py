import ast,copy,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path.cwd();P=R/'packages/tools/src/capture/viewmodel_packet';V=Path('/private/tmp/p1-e05-t03-r4-RzbhYi');BASE='af301db512343f2d578e68b8cfdbe7f72bfe794d'
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
before=json.loads((V/'before.json').read_text());old=json.loads((E/'original/readiness.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
changed={}
for name,row in before['tracked'].items():
 h=sha(R/name)
 if h!=row['sha256']:changed[name]={'old':row['sha256'],'new':h}
expected={'README.md','caller.py','entry.mjs','production.test.mjs','publication.test.mjs','inspect_packet.py','test_inspect.py'}
assert set(changed)=={str(P.relative_to(R)/n) for n in expected},changed
for p in (E/'original').iterdir():assert p.read_bytes()==subprocess.check_output(['git','show',f'{BASE}:{P.relative_to(R)/p.name}']),p
assert (P/'entry.mjs').read_text().replace('(await import(pathToFileURL(ready.bindings.playwright).href)).default','await import(pathToFileURL(ready.bindings.playwright).href)')==(E/'original/entry.mjs').read_text()
assert (P/'caller.py').read_text().replace('viewmodel-packet-r5-rdtnxbus','viewmodel-packet-r4-bpmhg9qg')==(E/'original/caller.py').read_text()
protected=json.loads((P/'evidence/capture-revision-r1/protected-audit.txt').read_text())
for rows in protected['groups'].values():
 for name,row in rows.items():assert sha(R/name)==row['sha256'],name
for name,digest in protected['helpers'].items():assert sha(R/name)==digest,name
for name,digest in protected['reports'].items():assert sha(name)==digest,name
for section in ('priorEvidence','authorReports'):
 for name,row in before[section].items():assert sha(name)==row['sha256'],name
index=json.loads((V/'FINAL-INDEX.json').read_text())
for name,row in index.items():assert sha(V/name)==row['sha256'],name
assert sha(P/'inspect_packet.py')=='862a50a99f822a95bdf6dfd67da272ad3a544dbbf78884e752cddc38ff278461'
assert sha(P/'test_inspect.py')=='ad1d56f77dee018cca260210c0bac2c0b0ed9be37a3be316401a0859edc92342'
syntax=[]
for path in P.glob('*.py'):ast.parse(path.read_text(),filename=str(path));syntax.append(path.name)
sys.path.insert(0,str(P));import caller,boundary
os.environ['PATH']=old['bindings']['path']
ready=caller.prepare() # The sole final refresh after executable edits and focused proofs.
for key,value in old['bindings'].items():
 if key!='bindings':assert ready['bindings'][key]==value,key
oldpins={x['path']:x for x in old['bindings']['bindings']};newpins={x['path']:x for x in ready['bindings']['bindings']};assert set(oldpins)==set(newpins)
pinchanges={p for p in oldpins if oldpins[p]!=newpins[p]};assert pinchanges=={str(P/n) for n in ('caller.py','entry.mjs','inspect_packet.py')},pinchanges
assert ready['inventorySha256']==old['inventorySha256'] and (P/'inventory.json').read_bytes()==(E/'original/inventory.json').read_bytes()
assert ready['runtimeEnabled'] and ready['entryEnabled'] and not ready['allUnitsQualified'] and not ready['nativeQualified']
allpaths=lambda value:sorted(set(v for row in value['paths'].values() for v in row.values())|set(value['containers'].values()))
historical=sorted(set(allpaths(old))|set(json.loads(Path('/private/tmp/vm-r3-fix-bpmhg9qg/original/readiness.json').read_text())['containers'].values()))
# Include every original v1 path, not only its containers.
historical=sorted(set(historical)|set(allpaths(json.loads(Path('/private/tmp/vm-r3-fix-bpmhg9qg/original/readiness.json').read_text()))))
for path in historical+allpaths(ready):boundary.canonical(path,absent=True)
assert len(allpaths(ready))==31 and len(historical)==62
ready['sourceProvenance']=copy.deepcopy(old['sourceProvenance']);pr=ready['sourceProvenance'];pr['previousPacketRevision']=copy.deepcopy(pr['packetRevision']);pr['packetRevision']={'base':BASE,'baseTree':before['tree'],'review':str(V/'REPORT-FINAL.txt'),'reviewSha256':sha(V/'REPORT-FINAL.txt'),'scope':'R4 real pinned CommonJS Playwright boundary and mandatory runtime update-budget correction; independent R5 required','sharedT15Unchanged':True,'finalHeadBinding':'post-commit handoff records exact clean HEAD/tree; a separate future parent grant must bind it after independent PASS'}
pr['legacyReviewedSourceScope']='accepted runtime/art SOURCE R3 anchor only; enabled corrected packet requires fresh VMR5'
pr['playwrightCorrection']={'referenceSource':'c396817029dd3756834cf5cbc660250a5331392d','referenceReport':'/private/tmp/p1-e08-t09-native-import-fix-ncq1tdni/APPENDIX-C2.md','referenceReportSha256':sha('/private/tmp/p1-e08-t09-native-import-fix-ncq1tdni/APPENDIX-C2.md'),'scope':'VM-specific real installed CJS/public ESM singleton and authenticated entry reproduction, no foreign source edits or runtime launch'}
pr['setstoreAssessment']={'evidence':str(E/'setstore-route-assessment.json'),'evidenceSha256':sha(E/'setstore-route-assessment.json'),'bindingExpanded':False,'scope':'conditional unchanged-observer refusal; T13 used different full-Chrome BrowserServer route; VM service creation/authorization unestablished'}
raw=(json.dumps(ready,indent=2)+'\n').encode();(E/'final-readiness.json').write_bytes(raw);(P/'readiness.json').write_bytes(raw)
W=Path('/private/tmp/vm-r3-fix-bpmhg9qg');oldfreeze=json.loads((W/'freeze.json').read_text());reuse=[]
assert oldfreeze['sourceDigestUnchanged']==ready['bindings']['sourceDigest'] and oldfreeze['dependenciesUnchanged']==ready['bindings']['trees']
for line in (W/'commands.jsonl').read_text().splitlines():
 row=json.loads(line)
 if row['name'] in ('activation-python','r2-regression','encoder-controls','protocol-frozen'):
  assert row['exit']==0 and sha(W/(row['name']+'.log'))==row['logSha256'];reuse.append(row)
for row in oldfreeze['reusedExactCommands']:
 oldroot=Path('/private/tmp/vm-r2-fix-pern8y1v');assert sha(oldroot/(row['name']+'.log'))==row['logSha256'];reuse.append(row)
assert len(reuse)==7
proof={'base':BASE,'baseTree':before['tree'],'status':'ENABLED_SOURCE_CPU_ONLY_AWAITING_R5','readinessSha256':hashlib.sha256(raw).hexdigest(),'inventorySha256':sha(P/'inventory.json'),'changedPriorTracked':changed,'priorTracked':before['tracked'],'unchangedPriorTracked':len(before['tracked'])-len(changed),'protected':protected,'protectedManifestSha256':sha(P/'evidence/capture-revision-r1/protected-audit.txt'),'protectedCounts':{k:len(v) for k,v in protected['groups'].items()},'priorEvidenceVerified':{**before['priorEvidence'],**before['authorReports']},'reviewIndexSha256':sha(V/'FINAL-INDEX.json'),'reviewFilesVerified':len(index),'sourceDigestUnchanged':ready['bindings']['sourceDigest'],'ignoredInventoryUnchanged':ready['bindings']['ignoredInventorySha256'],'dependenciesUnchanged':ready['bindings']['trees'],'processBindingsUnchanged':ready['bindings']['process_binary_sha256'],'bindingChanges':{p:newpins[p] for p in pinchanges},'allProspectivePathsAbsent':allpaths(ready),'historicalPathsAbsent':historical,'syntax':syntax,'reusedExactCommands':reuse,'reuseScope':'Historical commands only. Non-packet source and dependencies exact; native/boundary/protocol/error helper bodies unchanged; caller changes only prospective identity literals. Full suites not rerun. Entry import and inspector affected predicates have fresh focused proofs.','newSourceHashes':{str(p.relative_to(R)):sha(p) for p in P.iterdir() if p.is_file()}}
(E/'freeze.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k] for k in ('base','status','readinessSha256','unchangedPriorTracked','protectedCounts','reviewFilesVerified')}))
