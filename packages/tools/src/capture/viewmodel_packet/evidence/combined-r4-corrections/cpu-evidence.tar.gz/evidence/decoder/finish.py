import ast, hashlib, json, os, subprocess
from collections import Counter
from pathlib import Path

S = Path(__file__).resolve().parent
R = Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8')
H = R/'packages/tools/src/capture/viewmodel_packet'
ENV = json.loads((S/'environment.json').read_text())
def hashes(p):
    raw = Path(p).read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(p,value):
    raw = value if isinstance(value,bytes) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    with Path(p).open('xb') as f:f.write(raw)
def git(*args):
    p = subprocess.run(['/usr/bin/git',*args],cwd=R,env=ENV,capture_output=True)
    assert p.returncode == 0,p.stderr
    return p.stdout

before = json.loads((S/'before.json').read_text())
after = {p:hashes(p) for p in before['files']}
assert after == before['files']
assert git('rev-parse','HEAD').decode().strip() == before['head']
assert git('rev-parse','HEAD^{tree}').decode().strip() == before['tree']
write(S/'preservation.json',dict(files=after,count=len(after),allUnchanged=True,head=before['head'],tree=before['tree']))
owned = ['packages/tools/src/capture/viewmodel_packet/'+n for n in ('inspect_packet.py','test_inspect.py')]
patch = git('diff','--binary','--full-index',before['head'],'--',*owned)
write(S/'owned.diff',patch)
git('diff','--check','--',*owned)
for name in ('inspect_packet.py','test_inspect.py'):
    write(S/f'final-{name}',(H/name).read_bytes())
methods = lambda p:{n.name:ast.dump(n) for n in ast.walk(ast.parse(Path(p).read_text())) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
old,new = methods(S/'base/test_inspect.py'),methods(H/'test_inspect.py')
changed = [k for k in old if old[k] != new[k]]
assert changed == ['test_cli_zero_time_resets_settled_observations_and_extra_updates_remain_valid']
assert len(old) == 31 and len(new) == 34
commands = {str(p.relative_to(S)):json.loads(p.read_text()) for p in sorted(S.rglob('result.json')) if 'tmp' not in p.relative_to(S).parts and p.parent.joinpath('invocation.json').is_file()}
cli = {k:v for k,v in commands.items() if any(str(a).endswith('/inspect_packet.py') for a in v['argv'])}
counts = Counter(v['exit'] for v in cli.values())
assert counts == {0:223,1:247} and len(cli) == 470
for key,row in commands.items():
    for stream in ('stdout','stderr'):
        assert hashes((S/key).parent/stream) == row[stream]
write(S/'commands.json',commands)
failures = []
for label in ('red-tests','red-tests-v2'):
    raw = (S/label/'stderr').read_text()
    failures.append(dict(label=label,head=raw[:1600],tail=raw[-1000:],summary=json.loads((S/label/'summary.json').read_text())))
write(S/'failure-tails.json',dict(testFailures=failures,greenCounterexampleFailures=json.loads((S/'green-replay.json').read_text())))
runtime = json.loads((S/'runtime-parity.json').read_text())
extra = json.loads((S/'runtime-extra-facts.json').read_text())
summary = dict(head=before['head'],tree=before['tree'],ownedPatch=hashes(S/'owned.diff'),
    source={n:hashes(H/n) for n in ('inspect_packet.py','test_inspect.py')},
    baseline=before['base'],oldTestMethodsUnchanged=30,changedOldMethods=changed,newMethods=sorted(set(new)-set(old)),
    focused=json.loads((S/'green-tests/summary.json').read_text()),
    finalRed=json.loads((S/'red-tests-v2/summary.json').read_text()),
    totalCli=len(cli),totalExitCounts=dict(counts),finalGreenCli=301,finalGreenExitCounts={0:101,1:200},
    runtime=runtime,extraRuntime=dict(controls=len(extra['controls']),timelines=len(extra['timelines']),endpoints=sum(len(t['frames']) for t in extra['timelines'])),
    preservationFiles=len(after),gitStatus=git('status','--short').decode(),boundary='Source CPU implementation proof, not independent or native acceptance')
write(S/'SUMMARY.json',summary)
write(S/'git-status.txt',summary['gitStatus'].encode())
print(json.dumps({k:summary[k] for k in ('head','tree','source','ownedPatch','totalCli','totalExitCounts','finalGreenCli','finalGreenExitCounts','extraRuntime','preservationFiles')},indent=2))
