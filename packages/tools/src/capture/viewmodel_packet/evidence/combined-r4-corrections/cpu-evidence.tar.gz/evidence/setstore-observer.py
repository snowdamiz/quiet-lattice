import contextlib,hashlib,importlib,json,os,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
E=Path(__file__).resolve().parent; P=Path('/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet');sys.path.insert(0,str(P));import bindings
sys.path.insert(0,str(bindings.HELPERS)); stages=importlib.import_module('run_round4_remaining8')
files=[Path('/private/tmp/t13-observer-native-7b836b7a/result.json'),Path('/private/tmp/t13-observer-native-7b836b7a/capture/browser-launch.json'),Path('/private/tmp/space-t13-parent-native-lim2ud6m/os-exit.json'),Path('/private/tmp/space-t13-parent-native-lim2ud6m/parent-release-observation.json')]
source={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
binary='/System/Library/PrivateFrameworks/CascadeSets.framework/Versions/A/XPCServices/SetStoreUpdateService.xpc/Contents/MacOS/SetStoreUpdateService'
def objects(x):
 if isinstance(x,dict):
  yield x
  for v in x.values():yield from objects(v)
 elif isinstance(x,list):
  for v in x:yield from objects(v)
prior=json.loads(files[0].read_text()); recorded=next(r for r in objects(prior) if r.get('binary')==binary and 'kernel' in r)
ready=json.loads((P/'readiness.json').read_text());pins=ready['bindings']['process_binary_sha256'];assert binary not in pins
row=recorded['kernel']; assert row['uid']==os.getuid();coalition=recorded['coalition']; digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest();results=[]
for mode in ['actual-map','inert-exact-binding-control','wrong-uid','wrong-birth','wrong-coalition','not-member']:
 root=E/('setstore-'+mode);root.mkdir(); current={**row}
 if mode=='wrong-uid':current['uid']+=1
 if mode=='wrong-birth':current['birth']=[0,0]
 job=SimpleNamespace(out=root,scratch=root,state={},members=lambda:[] if mode=='not-member' else [row],coalition_id=coalition[0])
 config={'resolver':{'selectedExecutable':{'path':ready['bindings']['browserBinary']}},'process_binary_sha256':pins if mode=='actual-map' else {**pins,binary:digest}}
 def forbidden(*a,**kw):raise AssertionError('NO_NATIVE_COMMAND')
 error=None
 with contextlib.ExitStack() as stack:
  for owner,name,value in [(subprocess,'run',forbidden),(subprocess,'check_output',forbidden),(subprocess,'Popen',forbidden),(stages,'current_commands',lambda _:{row['pid']:binary}),(stages,'identity',lambda _:current),(stages,'coalition',lambda _:[-1,0] if mode=='wrong-coalition' else coalition),(stages,'executable_path',lambda _:binary)]:stack.enter_context(patch.object(owner,name,value))
  observer=stages.StageReceipts(job,config,str(root))
  try:observer.observe()
  except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
  receipt=observer.receipt()
 admitted=[r for r in receipt['processes'] if r['admitted']]
 if mode=='actual-map':assert error['message']=='Unbound owned executable: '+binary
 elif mode in ['wrong-uid','wrong-birth','wrong-coalition']:assert error and not admitted
 elif mode=='not-member':assert not error and not admitted
 else:assert not error and len(admitted)==1
 results.append({'mode':mode,'error':error,'receipt':receipt})
assert source=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
report={'sourceHashes':source,'historicalMember':recorded,'bindingPresent':False,'currentExecutableSha256':digest,'results':results,'scope':'Inert historical member replay only, no native process, no task binding edits or ownership authorization'}
(E/'setstore-observer.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
