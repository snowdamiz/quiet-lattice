import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import vm from 'node:vm';
import { pathToFileURL } from 'node:url';
import { registerHooks } from 'node:module';
import ts from '/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/node_modules/typescript/lib/typescript.js';
registerHooks({load(url,context,next){
  if(url.startsWith('file:')&&url.endsWith('.ts'))return {format:'module',shortCircuit:true,source:ts.transpileModule(fs.readFileSync(new URL(url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText};
  return next(url,context);
}});
const root='/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8';
const scratch='/private/tmp/vm-r4-fix-rdtnxbus/decoder';
const runtimePath=`${root}/packages/client/src/entities/Multitool.js`;
const fixturePath=`${root}/packages/tools/src/capture/viewmodel_packet/fixture.mjs`;
const threePath=`${root}/packages/client/node_modules/three/build/three.module.js`;
const meterPath=`${root}/packages/shared/src/meters/rules.ts`;
const THREE=await import(pathToFileURL(threePath));
const meters=await import(pathToFileURL(meterPath));
const { installPageFixture }=await import(pathToFileURL(fixturePath));
const specs=JSON.parse(fs.readFileSync(`${root}/packages/tools/src/capture/viewmodel_packet/inventory.json`)).units.filter(s=>s.kind!=='review');
let load;
const context=vm.createContext({console});
const sources={three:THREE,'@astra/shared/meters':meters,
  '../core/Engine.js':{gltfLoader:()=>({load:(url,success)=>{assert.equal(load,undefined);load={url,success};}})},
  '../core/dispose.js':{disposeTree:()=>{}},
  './Ship.js':{characterMeterEnvironment:g=>({world:null,hazards:[],time:null,underwater:g.player.headUnderwater,sunlight:false,habitableBand:false,deepSpace:false,nearStar:false,nearBodies:false,footHazard:0})}};
const module=new vm.SourceTextModule(fs.readFileSync(runtimePath,'utf8'),{context,identifier:runtimePath});
await module.link(specifier=>{const exports=sources[specifier];assert.ok(exports,`Unexpected import ${specifier}`);return new vm.SyntheticModule(Object.keys(exports),function(){for(const [k,v] of Object.entries(exports))this.setExport(k,v);},{context});});
await module.evaluate();
const { Multitool }=module.namespace;
function scene(people){
  const root=new THREE.Group();
  for(const name of ['Skin',`VM_${people}_Tool`,...(people==='ulgani'?[]:['Bio'])]){
    const material=new THREE.MeshStandardMaterial({name});
    for(const slot of ['map','normalMap','roughnessMap','metalnessMap','aoMap',...(name==='Skin'?[]:['emissiveMap'])]){
      const t=new THREE.Texture({width:2048,height:2048});
      t.mipmaps=Array.from({length:12},(_,i)=>({width:2048>>i,height:2048>>i,data:new Uint8Array(1)}));
      material[slot]=t;
    }
    root.add(new THREE.Mesh(new THREE.BufferGeometry(),material));
  }
  for(const name of ['Muzzle','vm_hand_R','vm_hand_L']){const o=new THREE.Object3D();o.name=name;root.add(o);}
  root.getObjectByName('Muzzle').position.set(.1,-.2,-.4);
  return root;
}
function setup(people){
  const game={net:null,mode:'foot',director:{},build:{people},time:0,
    player:{headUnderwater:false,grounded:false,hSpeed:0,landShake:0},ship:{meterProfile:meters.meterProfile({ship:null})},
    cam:{frame:null,pos:new THREE.Vector3(),quat:new THREE.Quaternion()},camWorld:new THREE.Vector3(),camWorldQuat:new THREE.Quaternion(),
    engine:{camera:new THREE.PerspectiveCamera(70,16/9,.1,10000),viewCamera:new THREE.PerspectiveCamera(55,16/9,.01,10)},
    flora:{raycast:()=>null}};
  // Only constructor resource allocation is bypassed; every invoked method is
  // the full frozen module's real implementation. Synthetic model resources
  // satisfy its actual loader callback without loading assets or rendering.
  const tool=Object.create(Multitool.prototype);
  Object.assign(tool,{game,meterNet:null,viewModelPeople:people,viewModel:scene(people),viewModelRequest:0,
    view:new THREE.Group(),basePos:new THREE.Vector3(),swayX:0,swayY:0,stride:0,raise:1,
    beamMat:{uniforms:{uTime:{value:0},uColor:{value:new THREE.Color()}}},meter:{heat:0,charge:0,overheated:false},
    kick:0,muzzle:null,beam:new THREE.Group(),spark:new THREE.Group(),hitLight:new THREE.PointLight(),vmLight:new THREE.PointLight(),viewModelGlow:[]});
  tool.view.add(tool.viewModel);tool.muzzle=tool.viewModel.getObjectByName('Muzzle');
  game.multitool=tool;globalThis.window={game};installPageFixture();const api=window.__viewmodelPacket;
  assert.equal(tool.update,Multitool.prototype.update);assert.equal(api.state.frame,0);assert.equal(api.state.elapsed,0);
  return {game,tool,api};
}
function facts(c,file){return {file,frame:c.api.state.frame,elapsed:c.api.state.elapsed,dt:c.api.state.dt,raise:c.tool.raise,sway:[c.tool.swayX,c.tool.swayY],visible:c.tool.view.visible,modelAttached:!!c.tool.viewModel&&c.tool.viewModel.parent===c.tool.view,loaderPending:c.api.state.loaderPending,underwater:c.game.player.headUnderwater,heat:c.tool.heat,overheated:c.tool.overheated,firing:c.tool.firing,beamVisible:c.tool.beam.visible,input:c.api.state.input,raiseSeconds:c.api.state.raiseSeconds??null};}
function initial(c){c.api.step(0);for(let i=0;i<24;i++)c.api.step();assert.equal(c.api.state.frame,25);}
function switchGap(c,people){c.api.state.loaderPending=true;c.game.build.people=people;c.api.step(0);assert.ok(load);assert.equal(c.tool.raise,0);assert.equal(c.tool.viewModel,null);}
function attach(c,people){assert.ok(load.url.endsWith(`fp_${people}.glb`));const request=load;load=undefined;request.success({scene:scene(people)});c.api.state.loaderPending=false;assert.equal(c.tool.raise,0);}

const controls=[];
for(const people of ['thalune','ixari','ulgani']){
  const one=setup(people);initial(one);one.api.pose('sway-down');const before=facts(one);one.api.step(0);const afterOne=facts(one);
  assert.equal(afterOne.raise,1);assert.equal(afterOne.visible,true);assert.equal(afterOne.frame-before.frame,1);assert.equal(afterOne.elapsed,before.elapsed);
  const two=setup(people);initial(two);two.api.pose('sway-down');const beforeTwo=facts(two);
  two.game.player.headUnderwater=true;two.api.step(0);const hidden=facts(two);
  two.game.player.headUnderwater=false;two.api.state.raiseSeconds=0;two.api.step(0);const afterTwo=facts(two);
  assert.equal(hidden.raise,0);assert.equal(hidden.visible,false);assert.equal(afterTwo.raise,0);assert.equal(afterTwo.visible,true);
  assert.equal(afterTwo.frame-beforeTwo.frame,2);assert.equal(afterTwo.elapsed,beforeTwo.elapsed);assert.deepEqual(afterTwo.sway,beforeTwo.sway);
  controls.push({people,before,afterOne,beforeTwo,hidden,afterTwo});
}
const first=setup('thalune');initial(first);for(let i=0;i<240;i++)first.api.step();first.api.step(0);first.api.step(0);first.api.pose('neutral');
const firstFacts=facts(first,'16x9-neutral.png');assert.equal(firstFacts.frame,387);assert.ok(Math.abs(firstFacts.elapsed-384/60)<1e-12);
const report={controls,firstFacts,sourceHashes:Object.fromEntries([runtimePath,fixturePath,process.execPath].map(p=>{const raw=fs.readFileSync(p);return [p,{bytes:raw.length,sha256:crypto.createHash('sha256').update(raw).digest('hex')}];}))};
fs.writeFileSync(`${scratch}/frame-budget-runtime-facts.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));delete globalThis.window;
