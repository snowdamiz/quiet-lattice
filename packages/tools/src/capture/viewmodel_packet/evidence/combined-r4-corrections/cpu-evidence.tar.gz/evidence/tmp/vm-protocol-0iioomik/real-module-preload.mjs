/* global process, Buffer */
// Execute the frozen captureReview body; only native/import ports are inert.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createRequire, registerHooks, stripTypeScriptTypes, syncBuiltinESMExports } from 'node:module';
import { pathToFileURL, URL } from 'node:url';
import cp from 'node:child_process';
import netPorts from 'node:net';

const packet = "/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/packages/tools/src/capture/viewmodel_packet";
const ready = JSON.parse(fs.readFileSync(path.join(packet, 'readiness.json')));
const plan = JSON.parse(fs.readFileSync(path.join(packet, 'inventory.json')));
const trace = [];
let failingOperation, cleanupFails, primary;
const secondary = new Error('SECONDARY_BROWSER_CLOSE');
let chromium, originalLaunch;
const inertChromium = {
  launch: async () => {
    trace.push('inert-launch-port');
    let initCalls = 0;
    const page = Object.fromEntries(
      ['on', 'addInitScript', 'goto', 'waitForFunction', 'evaluate'].map((operation) => [
        operation,
        (...args) => {
          trace.push(operation);
          // The first init belongs to the adapter; the second is the real openReview call.
          if (operation === 'addInitScript') initCalls++;
          if (operation === failingOperation && (operation !== 'addInitScript' || initCalls === 2)) throw primary;
          if (operation === 'evaluate') throw new Error('Unexpected later dispatch');
          return operation === 'on' ? page : Promise.resolve(args);
        },
      ]),
    );
    return {
      newPage: async () => {
        trace.push('newPage');
        if (failingOperation === 'newPage') throw primary;
        return page;
      },
      close: async () => {
        trace.push('browser.close');
        if (cleanupFails) throw secondary;
      },
    };
  },
};
const vite = {
  listen: async () => {},
  close: async () => {
    trace.push('vite.close');
  },
};
const net = () => ({
  listen(_port, _host, callback) {
    callback();
  },
  address() {
    return { port: 12345 };
  },
  close(callback) {
    callback();
  },
});

// Actual installed Playwright is imported; only launch, Vite and network ports are inert.
globalThis.__viewmodelInertPorts = { vite, net };
const hooks = registerHooks({
  resolve(spec, context, next) {
    if (spec === '@playwright/test') return { url: pathToFileURL(ready.bindings.playwright.replace(/index\.js$/, 'index.mjs')).href, shortCircuit: true };
    if (spec === 'vite') return { url: 'inert:vite', shortCircuit: true };
    if (spec === 'node:net' && context.parentURL?.endsWith('/capture.ts')) return { url: 'inert:net', shortCircuit: true };
    return next(spec, context);
  },
  load(url, context, next) {
    if (url === 'inert:vite')
      return { format: 'module', source: 'export const createServer=async()=>globalThis.__viewmodelInertPorts.vite;', shortCircuit: true };
    if (url === 'inert:net') return { format: 'module', source: 'export const createServer=globalThis.__viewmodelInertPorts.net;', shortCircuit: true };
    if (url === pathToFileURL(ready.bindings.tsxApi).href) return { format: 'commonjs', source: 'exports.register=()=>()=>{};', shortCircuit: true };
    if (url.endsWith('/capture/classes.ts'))
      return {
        format: 'module',
        source: 'export const farRanges=()=>[];export const loadClassRules=()=>({});export const reviewClass=()=>"viewmodel";',
        shortCircuit: true,
      };
    if (url.endsWith('/capture/screens.ts')) return { format: 'module', source: 'export const SCREENS={};', shortCircuit: true };
    if (url.endsWith('/capture/capture.ts'))
      return { format: 'module', source: stripTypeScriptTypes(fs.readFileSync(new URL(url), 'utf8')), shortCircuit: true };
    return next(url, context);
  },
});

for (const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) {
 const original=cp[name];
 cp[name]=(...args)=>{if(name==='execFileSync' && args[0]==='git')return original(...args);throw Error('NO_NATIVE:'+name)};
}
netPorts.Socket.prototype.connect=netPorts.Server.prototype.listen=()=>assert.fail('NO_NETWORK');
syncBuiltinESMExports();
const imported=await import(pathToFileURL(ready.bindings.playwright).href);
const required=createRequire(import.meta.url)(ready.bindings.playwright);
const esm=await import(pathToFileURL(ready.bindings.playwright.replace(/index\.js$/,'index.mjs')).href);
assert.equal(imported.default,required);assert.equal(required.chromium,esm.chromium);
chromium=required.chromium;originalLaunch=chromium.launch;chromium.launch=inertChromium.launch;
failingOperation='goto';cleanupFails=true;primary=Object.assign(new Error('ACTUAL_ENTRY_GOTO'),{partial:Buffer.from([0,255]),unknown:{unchanged:true}});
vite.close=async()=>{trace.push('vite.close');throw Object.assign(new Error('ACTUAL_ENTRY_VITE_STOP'),{partial:Buffer.from([0,254])})};
process.on('exit',()=>fs.writeFileSync(process.env.VM_ENTRY_EVIDENCE,JSON.stringify({trace,sameChromium:true,node:process.version,launchRestored:chromium.launch===inertChromium.launch}),{flag:'wx'}));
