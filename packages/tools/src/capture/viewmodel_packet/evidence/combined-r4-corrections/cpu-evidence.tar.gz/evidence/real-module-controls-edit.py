from pathlib import Path
P=Path('packages/tools/src/capture/viewmodel_packet')
for name in ('production.test.mjs','publication.test.mjs'):
 p=P/name;s=p.read_text().replace('registerHooks, stripTypeScriptTypes, syncBuiltinESMExports','createRequire, registerHooks, stripTypeScriptTypes, syncBuiltinESMExports')
 s=s.replace("import cp from 'node:child_process';", "import cp from 'node:child_process';\nimport netPorts from 'node:net';")
 s=s.replace('const chromium = {','let chromium, originalLaunch;\nconst inertChromium = {')
 s=s.replace('// Private references avoid importing a real launcher, bundler, server or codec.','// Actual installed Playwright is imported; only launch, Vite and network ports are inert.')
 s=s.replace('globalThis.__viewmodelInertPorts = { chromium, vite, net };','globalThis.__viewmodelInertPorts = { vite, net };')
 s=s.replace("if (spec === '@playwright/test') return { url: 'inert:pw', shortCircuit: true };", "if (spec === '@playwright/test') return { url: pathToFileURL(ready.bindings.playwright.replace(/index\\.js$/, 'index.mjs')).href, shortCircuit: true };")
 s=s.replace("    if (url === 'inert:pw' || url === pathToFileURL(ready.bindings.playwright).href)\n      return { format: 'module', source: 'export const chromium=globalThis.__viewmodelInertPorts.chromium;', shortCircuit: true };\n",'')
 marker='  const rows = [];\n  try {\n'
 assert marker in s
 s=s.replace(marker,'''  const network = [netPorts.Socket.prototype.connect, netPorts.Server.prototype.listen];
  netPorts.Socket.prototype.connect = netPorts.Server.prototype.listen = () => assert.fail('NO_NETWORK');
  const rows = [];
  try {
    const imported = await import(pathToFileURL(ready.bindings.playwright).href);
    const required = createRequire(import.meta.url)(ready.bindings.playwright);
    const esm = await import(pathToFileURL(ready.bindings.playwright.replace(/index\\.js$/, 'index.mjs')).href);
    assert.equal(imported.default, required);
    assert.equal(required.chromium, esm.chromium);
    assert.equal(typeof required.chromium.launch, 'function');
    chromium = required.chromium;
    originalLaunch = chromium.launch;
    chromium.launch = inertChromium.launch;
''')
 s=s.replace('  } finally {\n    for (const [name, original] of saved)', '''  } finally {
    if (chromium) chromium.launch = originalLaunch;
    [netPorts.Socket.prototype.connect, netPorts.Server.prototype.listen] = network;
    for (const [name, original] of saved)''')
 # Publication uses `value`, not `original`, in its existing restoration loop.
 if 'if (chromium) chromium.launch = originalLaunch' not in s:
  s=s.replace('  } finally {\n', '''  } finally {
    if (chromium) chromium.launch = originalLaunch;
    [netPorts.Socket.prototype.connect, netPorts.Server.prototype.listen] = network;
''')
 p.write_text(s)
