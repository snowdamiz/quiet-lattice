import hashlib,json,os,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;P=Path('/private/tmp/vm-r4-fix-rdtnxbus/red/repo/packages/tools/src/capture/viewmodel_packet')
root=next((E/'tmp').glob('vm-protocol-*/entry-admission.mjs')).parent
ready=json.loads((root/'ready.json').read_text());paths=ready['paths']['review-thalune'];raw=Path(paths['consumption']).read_bytes();c=json.loads(raw)
env={**os.environ,'VIEWMODEL_READY':str(root/'ready.json'),'VIEWMODEL_CONSUMPTION':paths['consumption'],'VIEWMODEL_CONSUMPTION_SHA256':hashlib.sha256(raw).hexdigest(),'VIEWMODEL_ENTRY_TOKEN':c['entryToken'],'VIEWMODEL_SOURCE_HEAD':c['sourceHead'],'VIEWMODEL_UNIT':c['unit']}
argv=[ready['bindings']['node'],'--import',str(E/'fs-guard.mjs'),'--import',str(E/'no-native.mjs'),str(P/'entry.mjs')]
child=subprocess.run(argv,env=env,capture_output=True,timeout=10);(E/'entry-actual.stdout').write_bytes(child.stdout);(E/'entry-actual.stderr').write_bytes(child.stderr)
result=json.loads((Path(paths['evidence'])/'entry-result.json').read_text())
report={'argv':argv,'cwd':str(Path.cwd()),'env':{k:v for k,v in env.items() if k.startswith('VIEWMODEL_')},'exit':child.returncode,'scratchRoot':str(root),'result':result,'limits':'Scratch authorization only; all process ports except git blocked; no native process or real grant'}
(E/'entry-actual.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
assert child.returncode==1
assert result['checksPassed'] is False and result['primaryFailure']['message']=="Cannot read properties of undefined (reading 'launch')"
assert result['resources']==[] and result['writes']==[]
