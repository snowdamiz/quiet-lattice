const controls = [];
for (const people of ['thalune', 'ixari', 'ulgani']) {
  for (const positiveSteps of [0, 1, 120]) {
    const c = setup(people); initial(c); c.api.pose('sway-down');
    const before = facts(c);
    for (let i = 1; i < positiveSteps; i++) c.api.step();
    c.game.player.headUnderwater = true; c.api.step(positiveSteps ? 1 / 60 : 0);
    const hidden = facts(c);
    c.game.player.headUnderwater = false; c.api.state.raiseSeconds = 0; c.api.step(0);
    const after = facts(c);
    assert.equal(hidden.raise, 0); assert.equal(hidden.visible, false);
    assert.equal(after.raise, 0); assert.equal(after.visible, true);
    assert.equal(after.frame - before.frame, Math.max(2, positiveSteps + 1));
    assert.ok(Math.abs(after.elapsed - before.elapsed - positiveSteps / 60) < 1e-10);
    controls.push({ people, positiveSteps, before, hidden, after });
  }
  const c = setup(people); initial(c); c.api.pose('sway-down');
  const before = facts(c);
  c.game.player.headUnderwater = true; c.api.step(0);
  c.game.player.headUnderwater = false; c.api.step();
  const after = facts(c);
  assert.equal(after.raise, 2.6 / 60); assert.equal(after.visible, true);
  controls.push({ people, kind: 'positive-visible-step-cannot-observe-zero', before, after });
}
const timelines = [];
for (const spec of specs) {
  for (const variant of spec.kind === 'view' ? ['positive-reset-1', 'positive-reset-120', 'initial-extra-240'] : ['initial-extra-240']) {
    const c = setup(spec.fromPeople ?? spec.people); initial(c);
    const incoming = facts(c, 'incoming'); const frames = [];
    if (variant === 'initial-extra-240') for (let i = 0; i < 240; i++) c.api.step();
    if (spec.fromPeople) {
      switchGap(c, spec.people); frames.push(facts(c, '16x9-switch-gap.png'));
      attach(c, spec.people); for (let i = 0; i < 24; i++) c.api.step();
      frames.push(facts(c, '16x9-switch-settled.png'));
    }
    for (const file of spec.files.filter(n => n.endsWith('.png') && n !== 'sheet.png' && !n.includes('switch-'))) {
      for (const camera of [c.game.engine.camera, c.game.engine.viewCamera]) {
        camera.aspect = file.startsWith('21x9') ? 21 / 9 : 16 / 9; camera.updateProjectionMatrix();
      }
      const pose = file.replace(/^(16x9|21x9)-|\.png$/g, '');
      if (variant.startsWith('positive-reset') && pose === 'raise-0') {
        const steps = Number(variant.split('-').at(-1));
        for (let i = 1; i < steps; i++) c.api.step();
        c.game.player.headUnderwater = true; c.api.step();
        c.game.player.headUnderwater = false; c.api.state.raiseSeconds = 0; c.api.step(0);
      } else c.api.pose(pose);
      frames.push(facts(c, file));
    }
    if (variant === 'initial-extra-240') {
      const first = frames[0];
      assert.equal(first.frame, spec.fromPeople ? 266 : 385);
      assert.ok(Math.abs(first.elapsed * 60 - (spec.fromPeople ? 264 : 384)) < 1e-8);
    }
    timelines.push({ unit: spec.id, variant, incoming, frames });
  }
}
const sourceHashes = Object.fromEntries([runtimePath, fixturePath, threePath, `${root}/packages/client/node_modules/three/build/three.core.js`, meterPath, process.execPath].map(p => {
  const raw = fs.readFileSync(p); return [p, { bytes: raw.length, sha256: crypto.createHash('sha256').update(raw).digest('hex') }];
}));
const report = { controls, timelines, sourceHashes };
fs.writeFileSync(`${scratch}/runtime-extra-facts.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ controls: controls.length, timelines: timelines.length, endpoints: timelines.reduce((n, t) => n + t.frames.length, 0), sourceHashes }));
delete globalThis.window;
