import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire, syncBuiltinESMExports} from 'node:module';
import {pathToFileURL} from 'node:url';
import cp from 'node:child_process';
const P='/private/tmp/vm-r4-fix-rdtnxbus/red/repo/packages/tools/src/capture/viewmodel_packet';
const ready=JSON.parse(fs.readFileSync(P+'/readiness.json','utf8'));
const launches=[];
for(const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) cp[name]=(...args)=>{launches.push({name,argv:args.slice(0,2)});throw Error('PROCESS_EXECUTION_FORBIDDEN');};
syncBuiltinESMExports();
const require=createRequire(pathToFileURL(P+'/entry.mjs'));
const cjs=require(ready.bindings.playwright);
const imported=await import(pathToFileURL(ready.bindings.playwright).href);
const facts={node:process.version,path:ready.bindings.playwright,esmKeys:Object.keys(imported),namedChromium:typeof imported.chromium,defaultChromium:typeof imported.default?.chromium,cjsChromium:typeof cjs.chromium,sameObject:imported.default?.chromium===cjs.chromium,cjsLaunch:typeof cjs.chromium?.launch};
const {productionCapture}=await import(pathToFileURL(P+'/entry.mjs'));
const cleanups=[], record={writes:[],resources:[]};
const inventory=JSON.parse(fs.readFileSync(P+'/inventory.json','utf8'));
try { await productionCapture({ready,spec:inventory.units[0],paths:{output:'/private/tmp/vm-r4-fix-rdtnxbus/red/never-output'}},record,cleanups);facts.productionReturned=true; }
catch(error){ facts.productionError={name:error.name,message:error.message,stack:error.stack}; }
finally { for(const cleanup of cleanups.reverse()) await cleanup(); }
facts.launchAttempts=launches;facts.resources=record.resources;facts.outputExists=fs.existsSync('/private/tmp/vm-r4-fix-rdtnxbus/red/never-output');
console.log(JSON.stringify(facts,null,2));
assert.equal(facts.namedChromium,'undefined');
assert.equal(facts.cjsLaunch,'function');
assert.match(facts.productionError.message,/Cannot read properties of undefined \(reading 'launch'\)/);
assert.equal(launches.length,0);assert.equal(facts.outputExists,false);
