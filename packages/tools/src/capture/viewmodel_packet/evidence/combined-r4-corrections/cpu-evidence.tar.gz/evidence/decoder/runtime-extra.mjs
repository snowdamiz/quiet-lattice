import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import vm from 'node:vm';
import { pathToFileURL } from 'node:url';
import { registerHooks } from 'node:module';
import ts from '/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8/node_modules/typescript/lib/typescript.js';
registerHooks({load(url,context,next){
  if(url.startsWith('file:')&&url.endsWith('.ts'))return {format:'module',shortCircuit:true,source:ts.transpileModule(fs.readFileSync(new URL(url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText};
  return next(url,context);
}});
const root='/Users/andreyyurlov/.t3/worktrees/space/t3-8301ecc8';
const scratch='/private/tmp/vm-r4-fix-rdtnxbus/decoder';
const runtimePath=`${root}/packages/client/src/entities/Multitool.js`;
const fixturePath=`${root}/packages/tools/src/capture/viewmodel_packet/fixture.mjs`;
const threePath=`${root}/packages/client/node_modules/three/build/three.module.js`;
const meterPath=`${root}/packages/shared/src/meters/rules.ts`;
const THREE=await import(pathToFileURL(threePath));
const meters=await import(pathToFileURL(meterPath));
const { installPageFixture }=await import(pathToFileURL(fixturePath));
const specs=JSON.parse(fs.readFileSync(`${root}/packages/tools/src/capture/viewmodel_packet/inventory.json`)).units.filter(s=>s.kind!=='review');
let load;
const context=vm.createContext({console});
const sources={three:THREE,'@astra/shared/meters':meters,
  '../core/Engine.js':{gltfLoader:()=>({load:(url,success)=>{assert.equal(load,undefined);load={url,success};}})},
  '../core/dispose.js':{disposeTree:()=>{}},
  './Ship.js':{characterMeterEnvironment:g=>({world:null,hazards:[],time:null,underwater:g.player.headUnderwater,sunlight:false,habitableBand:false,deepSpace:false,nearStar:false,nearBodies:false,footHazard:0})}};
const module=new vm.SourceTextModule(fs.readFileSync(runtimePath,'utf8'),{context,identifier:runtimePath});
await module.link(specifier=>{const exports=sources[specifier];assert.ok(exports,`Unexpected import ${specifier}`);return new vm.SyntheticModule(Object.keys(exports),function(){for(const [k,v] of Object.entries(exports))this.setExport(k,v);},{context});});
await module.evaluate();
const { Multitool }=module.namespace;
function scene(people){
  const root=new THREE.Group();
  for(const name of ['Skin',`VM_${people}_Tool`,...(people==='ulgani'?[]:['Bio'])]){
    const material=new THREE.MeshStandardMaterial({name});
    for(const slot of ['map','normalMap','roughnessMap','metalnessMap','aoMap',...(name==='Skin'?[]:['emissiveMap'])]){
      const t=new THREE.Texture({width:2048,height:2048});
      t.mipmaps=Array.from({length:12},(_,i)=>({width:2048>>i,height:2048>>i,data:new Uint8Array(1)}));
      material[slot]=t;
    }
    root.add(new THREE.Mesh(new THREE.BufferGeometry(),material));
  }
  for(const name of ['Muzzle','vm_hand_R','vm_hand_L']){const o=new THREE.Object3D();o.name=name;root.add(o);}
  root.getObjectByName('Muzzle').position.set(.1,-.2,-.4);
  return root;
}
function setup(people){
  const game={net:null,mode:'foot',director:{},build:{people},time:0,
    player:{headUnderwater:false,grounded:false,hSpeed:0,landShake:0},ship:{meterProfile:meters.meterProfile({ship:null})},
    cam:{frame:null,pos:new THREE.Vector3(),quat:new THREE.Quaternion()},camWorld:new THREE.Vector3(),camWorldQuat:new THREE.Quaternion(),
    engine:{camera:new THREE.PerspectiveCamera(70,16/9,.1,10000),viewCamera:new THREE.PerspectiveCamera(55,16/9,.01,10)},
    flora:{raycast:()=>null}};
  // Only constructor resource allocation is bypassed; every invoked method is
  // the full frozen module's real implementation. Synthetic model resources
  // satisfy its actual loader callback without loading assets or rendering.
  const tool=Object.create(Multitool.prototype);
  Object.assign(tool,{game,meterNet:null,viewModelPeople:people,viewModel:scene(people),viewModelRequest:0,
    view:new THREE.Group(),basePos:new THREE.Vector3(),swayX:0,swayY:0,stride:0,raise:1,
    beamMat:{uniforms:{uTime:{value:0},uColor:{value:new THREE.Color()}}},meter:{heat:0,charge:0,overheated:false},
    kick:0,muzzle:null,beam:new THREE.Group(),spark:new THREE.Group(),hitLight:new THREE.PointLight(),vmLight:new THREE.PointLight(),viewModelGlow:[]});
  tool.view.add(tool.viewModel);tool.muzzle=tool.viewModel.getObjectByName('Muzzle');
  game.multitool=tool;globalThis.window={game};installPageFixture();const api=window.__viewmodelPacket;
  assert.equal(tool.update,Multitool.prototype.update);assert.equal(api.state.frame,0);assert.equal(api.state.elapsed,0);
  return {game,tool,api};
}
function facts(c,file){return {file,frame:c.api.state.frame,elapsed:c.api.state.elapsed,dt:c.api.state.dt,raise:c.tool.raise,sway:[c.tool.swayX,c.tool.swayY],visible:c.tool.view.visible,modelAttached:!!c.tool.viewModel&&c.tool.viewModel.parent===c.tool.view,loaderPending:c.api.state.loaderPending,underwater:c.game.player.headUnderwater,heat:c.tool.heat,overheated:c.tool.overheated,firing:c.tool.firing,beamVisible:c.tool.beam.visible,input:c.api.state.input,raiseSeconds:c.api.state.raiseSeconds??null};}
function initial(c){c.api.step(0);for(let i=0;i<24;i++)c.api.step();assert.equal(c.api.state.frame,25);}
function switchGap(c,people){c.api.state.loaderPending=true;c.game.build.people=people;c.api.step(0);assert.ok(load);assert.equal(c.tool.raise,0);assert.equal(c.tool.viewModel,null);}
function attach(c,people){assert.ok(load.url.endsWith(`fp_${people}.glb`));const request=load;load=undefined;request.success({scene:scene(people)});c.api.state.loaderPending=false;assert.equal(c.tool.raise,0);}
const controls = [];
for (const people of ['thalune', 'ixari', 'ulgani']) {
  for (const positiveSteps of [0, 1, 120]) {
    const c = setup(people); initial(c); c.api.pose('sway-down');
    const before = facts(c);
    for (let i = 1; i < positiveSteps; i++) c.api.step();
    c.game.player.headUnderwater = true; c.api.step(positiveSteps ? 1 / 60 : 0);
    const hidden = facts(c);
    c.game.player.headUnderwater = false; c.api.state.raiseSeconds = 0; c.api.step(0);
    const after = facts(c);
    assert.equal(hidden.raise, 0); assert.equal(hidden.visible, false);
    assert.equal(after.raise, 0); assert.equal(after.visible, true);
    assert.equal(after.frame - before.frame, Math.max(2, positiveSteps + 1));
    assert.ok(Math.abs(after.elapsed - before.elapsed - positiveSteps / 60) < 1e-10);
    controls.push({ people, positiveSteps, before, hidden, after });
  }
  const c = setup(people); initial(c); c.api.pose('sway-down');
  const before = facts(c);
  c.game.player.headUnderwater = true; c.api.step(0);
  c.game.player.headUnderwater = false; c.api.step();
  const after = facts(c);
  assert.equal(after.raise, 2.6 / 60); assert.equal(after.visible, true);
  controls.push({ people, kind: 'positive-visible-step-cannot-observe-zero', before, after });
}
const timelines = [];
for (const spec of specs) {
  for (const variant of spec.kind === 'view' ? ['positive-reset-1', 'positive-reset-120', 'initial-extra-240'] : ['initial-extra-240']) {
    const c = setup(spec.fromPeople ?? spec.people); initial(c);
    const incoming = facts(c, 'incoming'); const frames = [];
    if (variant === 'initial-extra-240') for (let i = 0; i < 240; i++) c.api.step();
    if (spec.fromPeople) {
      switchGap(c, spec.people); frames.push(facts(c, '16x9-switch-gap.png'));
      attach(c, spec.people); for (let i = 0; i < 24; i++) c.api.step();
      frames.push(facts(c, '16x9-switch-settled.png'));
    }
    for (const file of spec.files.filter(n => n.endsWith('.png') && n !== 'sheet.png' && !n.includes('switch-'))) {
      for (const camera of [c.game.engine.camera, c.game.engine.viewCamera]) {
        camera.aspect = file.startsWith('21x9') ? 21 / 9 : 16 / 9; camera.updateProjectionMatrix();
      }
      const pose = file.replace(/^(16x9|21x9)-|\.png$/g, '');
      if (variant.startsWith('positive-reset') && pose === 'raise-0') {
        const steps = Number(variant.split('-').at(-1));
        for (let i = 1; i < steps; i++) c.api.step();
        c.game.player.headUnderwater = true; c.api.step();
        c.game.player.headUnderwater = false; c.api.state.raiseSeconds = 0; c.api.step(0);
      } else c.api.pose(pose);
      frames.push(facts(c, file));
    }
    if (variant === 'initial-extra-240') {
      const first = frames[0];
      assert.equal(first.frame, spec.fromPeople ? 266 : 385);
      assert.ok(Math.abs(first.elapsed * 60 - (spec.fromPeople ? 264 : 384)) < 1e-8);
    }
    timelines.push({ unit: spec.id, variant, incoming, frames });
  }
}
const sourceHashes = Object.fromEntries([runtimePath, fixturePath, threePath, `${root}/packages/client/node_modules/three/build/three.core.js`, meterPath, process.execPath].map(p => {
  const raw = fs.readFileSync(p); return [p, { bytes: raw.length, sha256: crypto.createHash('sha256').update(raw).digest('hex') }];
}));
const report = { controls, timelines, sourceHashes };
fs.writeFileSync(`${scratch}/runtime-extra-facts.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ controls: controls.length, timelines: timelines.length, endpoints: timelines.reduce((n, t) => n + t.frames.length, 0), sourceHashes }));
delete globalThis.window;
