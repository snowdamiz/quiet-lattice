import hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent; P=Path.cwd()/'packages/tools/src/capture/viewmodel_packet'; ready=json.loads((P/'readiness.json').read_text()); plan=json.loads((P/'inventory.json').read_text()); rows=[]
env={**os.environ,'PATH':ready['bindings']['path']}
for spec in plan['units']:
 for kind,argv,want in [('caller',[sys.executable,'-B',str(P/'caller.py'),'--ready',str(P/'readiness.json'),'--unit',spec['id']],'Missing parent grant'),('entry',[ready['bindings']['node'],str(P/'entry.mjs')],'Missing consumed parent grant')]:
  childenv={k:v for k,v in env.items() if not k.startswith('VIEWMODEL_')};childenv['VIEWMODEL_UNIT']=spec['id']
  child=subprocess.run(argv,env=childenv,capture_output=True,timeout=5)
  assert child.returncode==1 and want.encode() in child.stderr,(argv,child.returncode,child.stdout,child.stderr)
  name=kind+'-'+spec['id'];(E/(name+'.stdout')).write_bytes(child.stdout);(E/(name+'.stderr')).write_bytes(child.stderr)
  rows.append({'kind':kind,'unit':spec['id'],'argv':argv,'exit':child.returncode,'expectedRefusal':want,'stdoutSha256':hashlib.sha256(child.stdout).hexdigest(),'stderrSha256':hashlib.sha256(child.stderr).hexdigest()})
for row in ready['paths'].values():
 for path in row.values():assert not Path(path).exists() and not Path(path).is_symlink(),path
for path in ready['containers'].values():assert not Path(path).exists(),path
(E/'enabled-cli-results.json').write_text(json.dumps({'status':'ENABLED_MISSING_AUTH_REFUSED','runtimeEnabled':ready['runtimeEnabled'],'entryEnabled':ready['entryEnabled'],'rows':rows,'prospectivePathsAbsent':True},indent=2)+'\n')
print(json.dumps({'expectedRefusals':len(rows),'flags':'enabled','prospectivePathsAbsent':True}))
