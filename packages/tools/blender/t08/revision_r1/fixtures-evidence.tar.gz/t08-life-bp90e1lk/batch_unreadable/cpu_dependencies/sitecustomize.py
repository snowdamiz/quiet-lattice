"""CPU test dependencies only, copied as sitecustomize.py into private fixtures."""

import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(os.environ["T08_FIXTURE_ROOT"])
real_popen = subprocess.Popen


class CpuPopen(real_popen):
    def __init__(self, args, *pos, **kw):
        requested = list(args) if isinstance(args, (list, tuple)) else args
        if isinstance(requested, list) and requested[0] == "/Applications/Blender.app/Contents/MacOS/Blender":
            args = [sys.executable, "-B", str(root / "fixture_blender.py"), *requested[1:]]
            with (root / "substitution.jsonl").open("a") as f:
                f.write(json.dumps({"requested": requested, "actual": args}) + "\n")
        super().__init__(args, *pos, **kw)
        if isinstance(requested, list) and any(str(x).endswith("/t08/run.py") for x in requested):
            (root / "runner.pid").write_text(str(self.pid))


subprocess.Popen = CpuPopen
if os.environ.get("T08_DENY_KILL"):
    def denied(*args):
        raise PermissionError(1, "controlled killpg EPERM")
    os.killpg = denied

# Never acquire or touch the real task's host-wide lock from a fixture.
import builtins
real_open = builtins.open


def private_open(file, *args, **kwargs):
    if str(file) == "/tmp/space-t08-cpu.lock":
        file = root.parent / "fixture-cpu.lock"
    return real_open(file, *args, **kwargs)


builtins.open = private_open
