import os,time
from pathlib import Path
r=Path(__file__).parent
(r/'producer.pid').write_text(str(os.getpid()))
(r/'ready').write_text('ready')
end=time.monotonic()+30
while not (r/'release').exists():
 if time.monotonic()>end: raise TimeoutError('barrier')
 time.sleep(.02)
(r/'done').write_text('done')
